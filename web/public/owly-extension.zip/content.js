(()=>{var be,xe;if(window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__)return;window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__=!0;try{document.documentElement.dataset.owlyExtension="installed",window.__OWLY_EXTENSION_INSTALLED__=!0}catch{}if(document.addEventListener("click",e=>{var c,n;const o=e.target;if((c=o==null?void 0:o.closest)==null?void 0:c.call(o,"[data-owly-action='open-sidepanel'], #owly-access-btn"))try{typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}},!0),window.addEventListener("message",e=>{var o,i,c;if(((o=e.data)==null?void 0:o.type)==="OWLY_PING"&&window.postMessage({type:"OWLY_PONG",version:"1.0.0",installed:!0},"*"),((i=e.data)==null?void 0:i.type)==="OWLY_OPEN_SIDEPANEL")try{typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}}),window.__SAVVY_OBSERVER__)try{window.__SAVVY_OBSERVER__.disconnect()}catch{}const Ce={PERCEPTION:{bg:"#398CF5",color:"#FFFFFF",icon:"👁️"},ACTION:{bg:"#F59E0B",color:"#000000",icon:"⚡"}};function de(e,o,i){var s;const c=new Date().toLocaleTimeString(),n=Ce[e]||{bg:"#398CF5",color:"#FFFFFF",icon:"🤖"},u=`background: ${n.bg}; color: ${n.color}; font-weight: bold; border-radius: 4px; padding: 2px 6px; font-size: 11px;`,g="color: #64748B; font-size: 10px; margin-left: 4px;",t="color: #0F172A; font-weight: 600; font-size: 12px;";i!==void 0?console.log(`%c${n.icon} [Owly Agent: ${e}]%c ${c}%c ${o}`,u,g,t,i):console.log(`%c${n.icon} [Owly Agent: ${e}]%c ${c}%c ${o}`,u,g,t);try{typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"AGENT_LOG_EVENT",event:{timestamp:c,domain:e,message:o,data:i?JSON.parse(JSON.stringify(i)):null}}).catch(()=>{})}catch{}}const C={perception:(e,o)=>de("PERCEPTION",e,o),action:(e,o)=>de("ACTION",e,o)},ue={en:{scannerTitle:"This Page is being scanned by Owly.AI",scannerSubtitle:"Please wait until finish...",snipTitle:"Owly Snip",snipInstruction:"Drag cursor over text or section to snip • ESC to cancel",snipExplainBtn:"Explain with Owly.AI",snipCopyBtn:"Copy Text",snipCopied:"Copied!",snipCancelTitle:"Cancel (ESC)",snipCapturing:"✓ Capturing screenshot..."},id:{scannerTitle:"Halaman ini sedang dipindai oleh Owly.AI",scannerSubtitle:"Mohon tunggu hingga selesai...",snipTitle:"Owly Snip",snipInstruction:"Seret kursor untuk memotong area teks • ESC untuk batal",snipExplainBtn:"Jelaskan dengan Owly.AI",snipCopyBtn:"Salin Teks",snipCopied:"Tersalin!",snipCancelTitle:"Batal (ESC)",snipCapturing:"✓ Mengambil tangkapan layar..."}};let te="en";typeof chrome<"u"&&((be=chrome.storage)!=null&&be.local)&&(chrome.storage.local.get(["owly_preferred_lang","preferred_language"],e=>{const o=e.owly_preferred_lang||e.preferred_language;(o==="id"||o==="en")&&(te=o)}),chrome.storage.onChanged.addListener((e,o)=>{var i,c;if(o==="local"){const n=((i=e.owly_preferred_lang)==null?void 0:i.newValue)||((c=e.preferred_language)==null?void 0:c.newValue);(n==="id"||n==="en")&&(te=n)}}));function J(){return ue[te]||ue.en}C.perception("Content Script activated. Closed Shadow DOM host initialized on page.");let F,L=null;try{const e=document.getElementById("savvy-root");if(e)try{e.remove()}catch{}L=document.createElement("div"),L.id="savvy-root",L.style.position="absolute",L.style.top="0",L.style.left="0",L.style.width="100%",L.style.height="100%",L.style.pointerEvents="none",L.style.zIndex="2147483647",(document.body||document.documentElement).appendChild(L),F=L.attachShadow({mode:"open"}),window.__SAVVY_SHADOW_ROOT__=F}catch(e){console.warn("[Owly.AI] Shadow root attachment fallback:",e),F=window.__SAVVY_SHADOW_ROOT__||document.body}const pe=document.createElement("style");pe.textContent=`
    .savvy-spotlight {
      position: absolute;
      pointer-events: none;
      border: 2px solid #2563EB;
      background-color: rgba(37, 99, 235, 0.08);
      border-radius: 8px;
      transition: all 0.2s ease-out;
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
      z-index: 10;
    }
    .savvy-spotlight-beacon {
      position: absolute;
      top: -10px;
      right: -10px;
      width: 20px;
      height: 20px;
      background: #2563EB;
      color: white;
      font-size: 11px;
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    /* Virtual AI Ghost Cursor Pointer (Show Me Agent) */
    .savvy-ghost-cursor {
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 2147483647;
      transition: transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease;
      will-change: transform, opacity;
      display: none;
      opacity: 0;
    }
    .savvy-ghost-cursor.visible {
      display: block;
      opacity: 1;
    }
    .savvy-ghost-cursor svg {
      filter: drop-shadow(0 3px 8px rgba(0, 0, 0, 0.45));
      transform: rotate(-10deg);
      transition: transform 0.2s ease;
    }
    .savvy-ghost-cursor.clicking svg {
      transform: rotate(-10deg) scale(0.85);
    }
    .savvy-ghost-label {
      position: absolute;
      left: 22px;
      top: 14px;
      background: linear-gradient(135deg, #1e1b4b 0%, #2563eb 100%);
      color: #ffffff;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 999px;
      border: 1px solid rgba(255, 255, 255, 0.35);
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
      white-space: nowrap;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .savvy-ghost-pulse {
      position: absolute;
      top: 0px;
      left: 0px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(37, 99, 235, 0.45);
      border: 2px solid #60a5fa;
      transform: translate(-30%, -30%) scale(0);
      pointer-events: none;
      opacity: 0;
    }
    @keyframes savvy-ghost-ripple {
      0% { transform: translate(-30%, -30%) scale(0.3); opacity: 0.9; }
      50% { transform: translate(-30%, -30%) scale(2.8); opacity: 0.5; }
      100% { transform: translate(-30%, -30%) scale(4.8); opacity: 0; }
    }
    .savvy-ghost-pulse.active-pulse {
      animation: savvy-ghost-ripple 0.9s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
    }
    .savvy-reading-guide {
      position: fixed;
      left: 0;
      width: 100%;
      height: 48px;
      background: rgba(37, 99, 235, 0.12);
      border-top: 2px solid #2563EB;
      border-bottom: 2px solid #2563EB;
      pointer-events: none;
      z-index: 2147483646;
      display: none;
    }

    /* Scanner Laser Beam Animation */
    .savvy-scanner-overlay {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 2147483646;
      overflow: hidden;
      transition: opacity 0.3s ease;
    }
    .savvy-scanner-overlay.fade-out {
      opacity: 0;
    }
    .savvy-scanner-backdrop {
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at center, rgba(15, 23, 42, 0.18) 0%, rgba(15, 23, 42, 0.45) 100%);
    }
    .savvy-laser-beam {
      position: absolute;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, transparent 0%, rgba(56, 189, 248, 0.8) 15%, #2563EB 50%, rgba(56, 189, 248, 0.8) 85%, transparent 100%);
      box-shadow: 0 0 16px #38BDF8, 0 0 32px #2563EB, 0 0 4px #FFFFFF;
      animation: savvyLaserSweep 2.6s ease-in-out infinite alternate;
    }
    .savvy-laser-trail {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 90px;
      background: linear-gradient(to top, rgba(37, 99, 235, 0.18), transparent);
      pointer-events: none;
    }
    @keyframes savvyLaserSweep {
      0% {
        top: 2%;
      }
      100% {
        top: 98%;
      }
    }
    .savvy-scanner-card {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(15, 23, 42, 0.94);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(56, 189, 248, 0.35);
      border-radius: 18px;
      padding: 20px 32px;
      box-shadow: 0 20px 45px rgba(0, 0, 0, 0.5), 0 0 35px rgba(37, 99, 235, 0.25);
      text-align: center;
      color: #FFFFFF;
      z-index: 2147483647;
      pointer-events: auto;
      animation: savvyCardPop 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes savvyCardPop {
      0% { transform: translate(-50%, -46%) scale(0.95); opacity: 0; }
      100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
    }
    .savvy-scanner-card-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-bottom: 6px;
    }
    .savvy-scanner-spinner {
      width: 18px;
      height: 18px;
      border: 2.5px solid rgba(56, 189, 248, 0.25);
      border-top-color: #38BDF8;
      border-radius: 50%;
      animation: savvySpin 0.8s linear infinite;
    }
    @keyframes savvySpin {
      to { transform: rotate(360deg); }
    }
    .savvy-scanner-title {
      font-size: 15px;
      font-weight: 800;
      color: #FFFFFF;
      letter-spacing: -0.2px;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }
    .savvy-scanner-subtitle {
      font-size: 12px;
      color: #94A3B8;
      font-weight: 500;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }

    /* Numbered Field Badges */
    .savvy-field-number-badge {
      position: absolute;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: #2563EB;
      color: #FFFFFF;
      font-size: 11px;
      font-weight: 800;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(37, 99, 235, 0.45), 0 0 0 2px #FFFFFF;
      cursor: pointer;
      pointer-events: auto;
      z-index: 2147483647;
      transition: transform 0.15s ease, background 0.15s ease;
      user-select: none;
    }
    .savvy-field-number-badge:hover {
      background: #1D4ED8;
      transform: scale(1.22);
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.55), 0 0 0 2px #FFFFFF;
    }
    .savvy-field-number-badge.active-badge {
      background: #10B981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.4), 0 0 0 2px #FFFFFF;
      transform: scale(1.22);
    }
  `,F.appendChild(pe);function _e(){ne();const e=J(),o=document.createElement("div");o.className="savvy-scanner-overlay",o.innerHTML=`
      <div class="savvy-scanner-backdrop"></div>
      <div class="savvy-laser-beam">
        <div class="savvy-laser-trail"></div>
      </div>
      <div class="savvy-scanner-card">
        <div class="savvy-scanner-card-header">
          <span class="savvy-scanner-spinner"></span>
          <span class="savvy-scanner-title">${e.scannerTitle}</span>
        </div>
        <div class="savvy-scanner-subtitle">${e.scannerSubtitle}</div>
      </div>
    `,F.appendChild(o),C.action("✨ Laser scanner animation activated on page.")}function ne(){const e=F.querySelector(".savvy-scanner-overlay");e&&(e.classList.add("fade-out"),setTimeout(()=>e.remove(),250),C.action("✨ Laser scanner animation stopped."))}function _(e){return e.replace(/[\n\r\t]+/g," ").replace(/\s+/g," ").replace(/[*:]+$/,"").trim()}function N(e){if(!e)return!1;const o=_(e);return!(o.length<2||o.length>70||/^(dd[\/\-\.]mm|yyyy[\/\-\.]mm|mm[\/\-\.]dd|hh:mm|08x|\+62|contoh|e\.g\.|example|\.\.\.|---)/i.test(o))}function D(e){var s;if(e.getAttribute("aria-label")&&N(e.getAttribute("aria-label")))return _(e.getAttribute("aria-label"));const o=e.getAttribute("aria-labelledby");if(o){const a=document.getElementById(o);if(a&&N(a.textContent))return _(a.textContent)}if(e.id){const a=document.querySelector(`label[for="${e.id}"]`);if(a&&N(a.textContent))return _(a.textContent)}const i=e.closest("label");if(i&&N(i.textContent))return _(i.textContent);let c=e.parentElement,n=0;for(;c&&n<5&&c.tagName!=="BODY"&&c.tagName!=="FORM";){const a=c.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(a&&!a.contains(e)&&N(a.textContent))return _(a.textContent);let p=c.previousElementSibling;for(;p;){const d=p.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(d&&N(d.textContent))return _(d.textContent);if(N(p.textContent))return _(p.textContent);p=p.previousElementSibling}if(c.tagName==="TR"){const d=c.querySelector("th, td:first-child");if(d&&!d.contains(e)&&N(d.textContent))return _(d.textContent)}c=c.parentElement,n++}let u=e.previousElementSibling;for(;u;){if(["LABEL","H3","H4","H5","H6","P","SPAN","STRONG","B","DIV"].includes(u.tagName)&&N(u.textContent))return _(u.textContent);u=u.previousElementSibling}try{const a=e.getBoundingClientRect();if(a.width>0&&a.height>0){const p=Array.from(document.querySelectorAll("label, .form-label, .col-form-label, dt, th, legend, h4, h5, h6, strong, b, [class*='label']"));let d=null,x=99999;for(const r of p){if(r.contains(e)||e.contains(r)||!N(r.textContent))continue;const m=r.getBoundingClientRect();if(m.width===0||m.height===0)continue;const E=m.right<=a.left+25&&m.left>=a.left-450&&Math.abs((m.top+m.bottom)/2-(a.top+a.bottom)/2)<28,h=m.bottom<=a.top+8&&m.bottom>=a.top-50&&m.left<a.right&&m.right>a.left-30;if(E){const y=a.left-m.right;y>=0&&y<x&&(x=y,d=r)}else if(h){const y=(a.top-m.bottom)*1.5;y>=0&&y<x&&(x=y,d=r)}}if(d&&d.textContent)return _(d.textContent)}}catch{}if(e.tagName==="BUTTON"||e.getAttribute("role")==="button"){const a=(s=e.textContent)==null?void 0:s.trim();if(a&&/^(upload|unggah|browse|pilih file|pilih berkas|choose file)$/i.test(a)){const p=e.closest(".card, .panel, .upload-container, .form-group, [class*='upload'], div");if(p){const d=p.querySelector("h3, h4, h5, h6, label, .title, strong");if(d&&N(d.textContent))return _(d.textContent)}}if(a)return _(a)}const g=e.getAttribute("placeholder");if(g&&N(g))return _(g);const t=e.getAttribute("name")||e.id||"";return t?t==="_username"||t==="username"?"Email":t==="_password"||t==="password"?"Password":_(t.replace(/[_\-]+/g," ")):"Kolom Form"}function X(e){var o,i,c;try{const n=e.closest("fieldset"),u=n==null?void 0:n.querySelector("legend");if((o=u==null?void 0:u.textContent)!=null&&o.trim())return u.textContent.trim().replace(/^[\d\.\-\s]+/,"").slice(0,45);let g=e.parentElement,t=0;for(;g&&t<6&&g!==document.body;){const a=g.querySelector("h1, h2, h3, h4, h5, .section-title, .card-title");if(a&&a!==e&&((i=a.textContent)!=null&&i.trim())){const p=a.textContent.trim().replace(/^[\d\.\-\s]+/,"").slice(0,45);if(p.length>2)return p}g=g.parentElement,t++}let s=e.previousElementSibling;for(;s;){if(/^H[1-5]$/i.test(s.tagName)&&((c=s.textContent)!=null&&c.trim()))return s.textContent.trim().replace(/^[\d\.\-\s]+/,"").slice(0,45);s=s.previousElementSibling}}catch{}return""}function G(){const e=[],o=new Set;return Array.from(document.querySelectorAll("input, select, textarea")).forEach(n=>{var t,s,a;if(n.type==="hidden"||n.type==="submit"||n.type==="reset")return;if(n.type==="file"){const p=n.getBoundingClientRect(),d=p.width>0&&p.height>0&&window.getComputedStyle(n).visibility!=="hidden";let x=n;if(!d){const r=n.id?document.querySelector(`label[for="${n.id}"]`):null,m=n.closest("label"),E=n.closest(".form-group, .upload-container, div"),h=E==null?void 0:E.querySelector("button, .btn, [role='button'], label"),y=[r,m,h].find(w=>{if(!w)return!1;const l=w.getBoundingClientRect();return l.width>0&&l.height>0&&window.getComputedStyle(w).visibility!=="hidden"});if(y)x=y;else return}o.add(n),o.add(x),e.push({targetEl:n,badgeTargetEl:x,id:n.id||n.name||"",name:n.name||"",label:D(x)||D(n)||"Upload File",placeholder:"",required:n.required,type:"file",section:X(x)||X(n)});return}const u=n.getBoundingClientRect();if(u.width>0&&u.height>0&&window.getComputedStyle(n).visibility,n.type==="radio"&&n.name){if(e.find(E=>E.type==="radio"&&E.name===n.name)){o.add(n);return}const d=n.closest(".p-4, .form-group, fieldset, [role='radiogroup'], div")||n.parentElement,x=(d==null?void 0:d.querySelector("label:not([class*='cursor-pointer'])"))||((t=n.closest("fieldset"))==null?void 0:t.querySelector("legend"));o.add(n);const r=((s=x==null?void 0:x.textContent)==null?void 0:s.trim())||D(n)||n.name,m=x||d||n;e.push({targetEl:n,badgeTargetEl:m,id:n.name,name:n.name,label:_(r),placeholder:"",required:n.required,type:"radio",section:X(m)});return}if(n.type==="checkbox"){const p=n.closest("label"),d=n.closest(".p-4, .form-group, fieldset, div")||n.parentElement;o.add(n);const x=((a=p==null?void 0:p.textContent)==null?void 0:a.trim())||D(n)||"Persetujuan",r=d||p||n;e.push({targetEl:n,badgeTargetEl:r,id:n.id||n.name||"checkbox",name:n.name||"",label:_(x),placeholder:"",required:n.required,type:"checkbox",section:X(r)});return}o.add(n);const g=D(n);e.push({targetEl:n,badgeTargetEl:n,id:n.id||n.name||"",name:n.name||"",label:g,placeholder:n.placeholder||"",required:n.required,type:n.type||n.tagName.toLowerCase(),section:X(n)})}),Array.from(document.querySelectorAll("button, [role='button'], a.btn, label.btn, .upload-btn")).forEach(n=>{var t;if(o.has(n))return;const u=(n.textContent||"").trim().toLowerCase();if(/^(upload|unggah|browse|pilih file|pilih berkas|choose file)/i.test(u)||((t=n.getAttribute("aria-label"))==null?void 0:t.toLowerCase().includes("upload"))){const s=n.getBoundingClientRect();if(!(s.width>0&&s.height>0&&window.getComputedStyle(n).visibility!=="hidden"))return;o.add(n),e.push({targetEl:n,badgeTargetEl:n,id:n.id||"",name:n.getAttribute("name")||"",label:D(n),placeholder:"",required:!1,type:"file"})}}),e.sort((n,u)=>{const g=n.badgeTargetEl.getBoundingClientRect(),t=u.badgeTargetEl.getBoundingClientRect();return Math.abs(g.top-t.top)>12?g.top-t.top:g.left-t.left}),e}function Se(){const o=G().map(g=>{var S,q,P;const t=g.targetEl;let s="";if(t)if(t.tagName==="SELECT"){const O=t;s=((S=O.options[O.selectedIndex])==null?void 0:S.text)||O.value||""}else if(t.type==="file")s=((P=(q=t.files)==null?void 0:q[0])==null?void 0:P.name)||"";else if(t.type==="checkbox"||t.type==="radio"){const O=t;s=O.checked?O.value||"checked":""}else s=t.value||"";const a=t.closest(".form-group, .mb-3, .form-row, tr, div")||t.parentElement,p=(a==null?void 0:a.textContent)||"",x=(g.label||"").includes("*")||p.includes("*")||t.getAttribute("aria-required")==="true",r=p.match(/\(([^)]+)\)/),m=r?r[0]:"",E="minLength"in t&&typeof t.minLength=="number"&&t.minLength>0?t.minLength:void 0,h="maxLength"in t&&typeof t.maxLength=="number"&&t.maxLength>0?t.maxLength:void 0,y=t.getAttribute("pattern")||void 0,w=t.getAttribute("data-mask")||t.getAttribute("data-inputmask")||void 0,l=t.getAttribute("accept")||void 0;return{fieldId:g.id||t.id||g.name,name:g.name||t.name||g.id,label:g.label,currentValue:s.trim(),surroundingContext:m,rules:{isRequired:t.required||x,placeholder:g.placeholder||t.placeholder||"",pattern:y,minLength:E,maxLength:h,type:g.type||t.type||"text",inputMaskDetected:w,accept:l}}}),i=[],c=Array.from(document.querySelectorAll("aside, .alert, .note, .keterangan, .sidebar, .info, footer, small, p, li")).map(g=>{var t;return((t=g.textContent)==null?void 0:t.trim())||""}).filter(g=>{const t=g.toLowerCase();return(t.includes("mb")||t.includes("kb")||t.includes("pdf")||t.includes("jpg")||t.includes("png"))&&(t.includes("maksimal")||t.includes("ukuran")||t.includes("file")||t.includes("berkas")||t.includes("format"))}).slice(0,5);i.push(...c);const n=[];return Array.from(document.querySelectorAll('input[type="file"]')).forEach(g=>{var t;if(g.files&&g.files.length>0){const s=g.files[0],a=s.name.includes(".")&&((t=s.name.split(".").pop())==null?void 0:t.toLowerCase())||"";n.push({fieldName:g.name||g.id||"file",fileName:s.name,fileSizeKb:Math.round(s.size/1024),fileExtension:a})}}),{fields:o,pageUploadContext:{pageWideFileInstructions:i,attachedFilesMetadata:n},meta:{url:window.location.href,domain:window.location.hostname,title:document.title}}}let T=[];function ge(e,o,i){const c=e.getBoundingClientRect();return e.tagName==="INPUT"&&(e.type==="radio"||e.type==="checkbox")?{top:`${c.top+o-4}px`,left:`${c.left+i-26}px`}:{top:`${c.top+o-10}px`,left:`${c.right+i-12}px`}}function Q(){const e=window.scrollY||document.documentElement.scrollTop,o=window.scrollX||document.documentElement.scrollLeft;T.forEach(({badgeEl:i,badgeTargetEl:c,targetEl:n})=>{const u=c||n;if(!document.body.contains(u)){i.style.display="none";return}const g=u.getBoundingClientRect();if(g.width===0&&g.height===0){i.style.display="none";return}i.style.display="flex";const t=ge(u,e,o);i.style.top=t.top,i.style.left=t.left})}function Te(){ie();const e=G(),o=window.scrollY||document.documentElement.scrollTop,i=window.scrollX||document.documentElement.scrollLeft;e.forEach((c,n)=>{const u=n+1,g=ge(c.badgeTargetEl,o,i),t=document.createElement("div");t.className="savvy-field-number-badge",t.textContent=`${u}`,t.title=`Kolom #${u}: ${c.label} (Klik untuk panduan)`,t.style.top=g.top,t.style.left=g.left,t.addEventListener("click",s=>{s.stopPropagation(),s.preventDefault(),c.targetEl.focus(),c.badgeTargetEl.scrollIntoView({behavior:"smooth",block:"center"}),Y(c.badgeTargetEl),T.forEach((a,p)=>{p===n?a.badgeEl.classList.add("active-badge"):a.badgeEl.classList.remove("active-badge")});try{chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:n,fieldId:c.id||"",fieldName:c.name||"",label:c.label}).catch(()=>{})}catch{}}),F.appendChild(t),T.push({badgeEl:t,targetEl:c.targetEl,badgeTargetEl:c.badgeTargetEl,index:n})}),window.addEventListener("scroll",Q,{passive:!0}),window.addEventListener("resize",Q,{passive:!0}),C.action(`🔢 Rendered numbered badges for ${e.length} interactive fields.`)}function ie(){T.forEach(({badgeEl:e})=>e.remove()),T=[],window.removeEventListener("scroll",Q),window.removeEventListener("resize",Q)}const M=document.createElement("div");M.className="savvy-spotlight",M.style.display="none",M.innerHTML='<div class="savvy-spotlight-beacon">O</div>',F.appendChild(M);const I=document.createElement("div");I.className="savvy-ghost-cursor",I.innerHTML=`
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
      <path d="M4 3L11 20L14 13L21 10L4 3Z" fill="#2563EB" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <div class="savvy-ghost-pulse"></div>
    <div class="savvy-ghost-label">
      <span>✨</span> Owly
    </div>
  `,F.appendChild(I);let oe={x:window.innerWidth*.7,y:window.innerHeight*.3};window.addEventListener("mousemove",e=>{oe={x:e.clientX,y:e.clientY}},{passive:!0});let Z=null;function ae(e){Z&&clearTimeout(Z),e.scrollIntoView({behavior:"smooth",block:"center"}),setTimeout(()=>{const o=e.getBoundingClientRect(),i=o.left+Math.min(Math.max(o.width*.5,12),o.width-8),c=o.top+Math.min(Math.max(o.height*.5,12),o.height-8);I.style.transition="none",I.style.transform=`translate(${oe.x}px, ${oe.y}px)`,I.classList.remove("clicking");const n=I.querySelector(".savvy-ghost-pulse");n&&n.classList.remove("active-pulse"),I.classList.add("visible"),requestAnimationFrame(()=>{I.style.transition="transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease",I.style.transform=`translate(${i}px, ${c}px)`,Z=setTimeout(()=>{I.classList.add("clicking"),n&&n.classList.add("active-pulse"),Y(e),Z=setTimeout(()=>{I.classList.remove("visible"),I.classList.remove("clicking"),n&&n.classList.remove("active-pulse")},1800)},850)})},150)}let z=null;function fe(){M&&(M.style.display="none"),z&&(clearTimeout(z),z=null)}function Y(e){const o=e.getBoundingClientRect(),i=window.scrollY||document.documentElement.scrollTop,c=window.scrollX||document.documentElement.scrollLeft;M.style.display="block",M.style.top=`${o.top+i-4}px`,M.style.left=`${o.left+c-4}px`,M.style.width=`${o.width+8}px`,M.style.height=`${o.height+8}px`,z&&clearTimeout(z),z=setTimeout(()=>{M.style.display="none"},4e3)}const V=document.createElement("div");V.className="savvy-reading-guide",F.appendChild(V),window.addEventListener("mousemove",e=>{V.style.display==="block"&&(V.style.top=`${e.clientY-24}px`)}),document.addEventListener("focusin",e=>{var i;const o=e.target;if(o&&(o.tagName==="INPUT"||o.tagName==="SELECT"||o.tagName==="TEXTAREA"||o.tagName==="BUTTON")){const c=D(o);C.perception(`🎯 Field focused: '${o.id||o.getAttribute("name")||o.tagName.toLowerCase()}' (${c})`,{fieldId:o.id||"",tagName:o.tagName,inputType:o.type||"text",hasValue:!!o.value});try{if(typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.sendMessage)&&(chrome.runtime.sendMessage({type:"FIELD_FOCUSED",fieldId:o.id||"",fieldName:o.getAttribute("name")||"",label:c,tagName:o.tagName,inputType:o.type||"text",value:o.value||""}).catch(()=>{}),T.length>0)){const n=T.findIndex(u=>u.targetEl===o||u.badgeTargetEl===o);n!==-1&&(T.forEach((u,g)=>{g===n?u.badgeEl.classList.add("active-badge"):u.badgeEl.classList.remove("active-badge")}),chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:n,fieldId:o.id||"",fieldName:o.getAttribute("name")||"",label:c}).catch(()=>{}))}}catch{}}}),document.addEventListener("focusout",()=>{fe()});let he=null,me="";function ke(){return Array.from(document.querySelectorAll("input, select, textarea")).filter(i=>i.type!=="hidden"&&i.type!=="submit"&&i.offsetParent!==null).map(i=>{const c="placeholder"in i?i.placeholder:"";return`${i.name||i.id||c}:${i.type||i.tagName.toLowerCase()}`}).join("|")}function se(){clearTimeout(he),he=setTimeout(()=>{const e=ke();if(e!==me){me=e;const o=e?e.split("|").length:0;C.perception(`🕵️ Dynamic DOM Mutation detected (${o} visible fields)`,{fieldCount:o,signature:e.substring(0,80)+(e.length>80?"...":"")}),chrome.runtime.sendMessage({type:"FORM_DOM_MUTATED",signature:e,fieldCount:o}).catch(()=>{})}},400)}const ye=new MutationObserver(e=>{e.some(i=>L?i.target!==L&&!L.contains(i.target):!0)&&se()});window.__SAVVY_OBSERVER__=ye,ye.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["hidden","disabled","aria-hidden","style","class"]}),window.addEventListener("popstate",se),window.addEventListener("hashchange",se);const Ae={register:["sign up","signup","register","create account","join","apply","daftar","registrasi","buat akun"],"sign up":["register","signup","create account","join","daftar","buat akun"],signup:["sign up","register","create account","join","daftar"],"sign in":["login","log in","signin","enter","masuk"],login:["log in","sign in","signin","enter","masuk"],upload:["attach","browse","choose file","select file","add file","unggah","pilih berkas"],attach:["upload","browse","choose file","select file","add document","unggah"],download:["save as","export","get file","unduh","ambil file"],requirements:["eligibility","criteria","terms","qualifications","prerequisites","syarat","persyaratan"],eligibility:["requirements","criteria","terms","qualifications","syarat"],help:["support","faq","guide","contact","documentation","bantuan"],payment:["fee","cost","checkout","pay","billing","biaya","tarif"],submit:["send","apply","finish","complete","proceed","kirim","ajukan"],next:["continue","proceed","forward","lanjut","berikutnya"],cancel:["abort","close","dismiss","reset","batal"],"bikin akun":["sign up","signup","register","daftar","registrasi","buat akun","create account","join"],"buat akun":["sign up","signup","register","daftar","registrasi","create account","join"],daftar:["sign up","signup","register","registrasi","buat akun","apply","pendaftaran"],masuk:["login","log in","sign in","signin","masuk"],keluar:["logout","log out","sign out","keluar"],unggah:["upload","unggah","pilih berkas","pilih file","choose file","browse"],unduh:["download","unduh","unduh berkas","ambil file"],syarat:["persyaratan","kriteria","ketentuan","eligibility","terms","requirement"],persyaratan:["syarat","kriteria","ketentuan","eligibility","terms","requirement"],bantuan:["help","bantuan","faq","panduan","hubungi kami","contact","support"],biaya:["tarif","harga","biaya","fee","cost","pembayaran","payment"],kirim:["submit","kirim","send","ajukan","lanjut","next"],simpan:["save","simpan","submit"],batal:["cancel","batal","reset"]};function Le(e){var m,E;const o=e.toLowerCase().trim();if(!o)return{success:!1};const i=o.replace(/\b(tombol|button|bagian|seksi|kolom|field|link|halaman|menu)\b/gi,"").trim(),c=i.length>=2?i:o,u=Array.from(document.querySelectorAll("button, a, input, select, textarea, [role='button'], [role='link'], [role='tab'], h1, h2, h3, h4, h5, h6, section, [id], label, dt, th")),g=[];for(const h of u){if(h.id==="savvy-root"||h.closest("#savvy-root"))continue;const y=h.getBoundingClientRect();if(y.width<=4||y.height<=4)continue;const w=window.getComputedStyle(h);w.visibility==="hidden"||w.display==="none"||w.opacity==="0"||g.push(h)}const t=h=>{var P;const y=h.getAttribute("aria-label")||"",w=h.placeholder||"",l=((P=h.textContent)==null?void 0:P.trim())||"",S=h.getAttribute("title")||"",q=h.value||"";return`${l} ${y} ${w} ${S} ${q}`.toLowerCase().replace(/\s+/g," ").trim()};let s=null,a=0;for(const h of g){const y=t(h);if(!y)continue;const w=/^(button|a|input|select|textarea)$/i.test(h.tagName)||h.getAttribute("role")==="button"||h.getAttribute("role")==="link";let l=0;y===c||y===o?l=w?100:85:y.includes(c)&&(l=w?80:65),l>a&&(a=l,s=h)}if(s&&a>=65)return ae(s),C.action(`🎯 [Show Me Level 1] Found exact/substring match for "${e}" -> <${s.tagName.toLowerCase()}>`,{score:a}),{success:!0,level:1,matchedText:((m=s.textContent)==null?void 0:m.trim().slice(0,50))||s.getAttribute("aria-label")||s.tagName,tag:s.tagName.toLowerCase()};for(const[h,y]of Object.entries(Ae))if(c.includes(h)||h.includes(c)){for(const w of y)for(const l of g)if(t(l).includes(w))return ae(l),C.action(`⚡ [Show Me Level 2] Found synonym match ("${h}" -> "${w}") for "${e}" -> <${l.tagName.toLowerCase()}>`),{success:!0,level:2,matchedText:((E=l.textContent)==null?void 0:E.trim().slice(0,50))||w,tag:l.tagName.toLowerCase()}}const p=g.filter(h=>{const y=h.tagName.toLowerCase();return y==="button"||y==="a"||y==="input"||h.getAttribute("role")==="button"||h.getAttribute("role")==="link"}),x=(p.length>=5?p:g).slice(0,20);return window.__SAVVY_SHOW_ME_CANDIDATES__=x,{success:!1,candidates:x.map((h,y)=>({domIndex:y,tag:h.tagName.toLowerCase(),text:(h.textContent||"").trim().replace(/\s+/g," ").slice(0,60),aria:h.getAttribute("aria-label")||"",placeholder:h.placeholder||""})).filter(h=>h.text.length>0||h.aria.length>0||h.placeholder.length>0)}}chrome.runtime.onMessage.addListener((e,o,i)=>{var c,n,u,g;if(e.type==="FIND_AND_HIGHLIGHT_ELEMENT"){const t=Le(e.query||"");i(t);return}if(e.type==="HIGHLIGHT_DOM_ELEMENT_BY_INDEX"){const t=e.domIndex,s=window.__SAVVY_SHOW_ME_CANDIDATES__;if(s&&s[t]){const a=s[t];ae(a),i({success:!0,text:(c=a.textContent)==null?void 0:c.trim().slice(0,50)});return}i({success:!1,reason:"Element index not found in cache"});return}if(e.type==="INJECT_VALUE"){const{fieldId:t,fieldName:s,fieldIndex:a,value:p}=e;let d=null;if(typeof a=="number"&&T[a]&&(d=T[a].targetEl),!d&&t&&(d=document.getElementById(t)),!d&&s&&(d=document.querySelector(`[name="${s}"]`)),d&&"value"in d){d.value=p,d.dispatchEvent(new Event("input",{bubbles:!0})),d.dispatchEvent(new Event("change",{bubbles:!0})),d.dispatchEvent(new Event("blur",{bubbles:!0})),C.action(`⚡ Injected value into field '${t||s||a}'`,{targetTag:d.tagName}),i({success:!0});return}i({success:!1,reason:"Element not found"})}if(e.type==="SET_A11Y_FEATURE"){const{feature:t,enabled:s,value:a,level:p}=e;re(t,s,a),C.action(`👓 A11y feature '${t}' set to: ${a||(s?"ON":"OFF")}`),i({success:!0,feature:t,enabled:s,value:a})}if(e.type==="APPLY_ALL_A11Y_SETTINGS"){const t=e.settings||{};Object.entries(t).forEach(([s,a])=>{a&&re(s,a.enabled,a.value,a.level)}),i({success:!0,count:Object.keys(t).length})}if(e.type==="CLEAR_ALL_A11Y"){Ie(),i({success:!0});return}if(e.type==="SCAN_PAGE_FIELDS"||e.type==="QUERY_PAGE_FIELDS"){const s=G().map(p=>({id:p.id,name:p.name,label:p.label,placeholder:p.placeholder,required:p.required,type:p.type,section:p.section||""})),a={url:window.location.href,domain:window.location.hostname,title:document.title,description:((n=document.querySelector('meta[name="description"]'))==null?void 0:n.getAttribute("content"))||"",keywords:((g=(u=document.querySelector('meta[name="keywords"]'))==null?void 0:u.getAttribute("content"))==null?void 0:g.split(",").map(p=>p.trim()))||[]};C.perception(`🔍 Scanning DOM: Discovered ${s.length} synchronized form fields on ${a.domain}`,{count:s.length,title:a.title,fieldKeys:s.map(p=>p.name||p.id||p.label).slice(0,8)}),i({success:!0,fields:s,count:s.length,meta:a})}if(e.type==="EXTRACT_FORM_AUDIT_DATA"){const t=Se();C.action(`🔍 EXTRACT_FORM_AUDIT_DATA: Scraped ${t.fields.length} active inputs and ${t.pageUploadContext.attachedFilesMetadata.length} attached files for audit.`),i({success:!0,...t});return}if(e.type==="HIGHLIGHT_AUDIT_FIELD"){let t=null,s=null;if(e.fieldId&&(t=document.getElementById(e.fieldId)),!t&&e.fieldName&&(t=document.querySelector(`[name="${e.fieldName}"]`)),!t&&typeof e.fieldIndex=="number"){const p=G();p[e.fieldIndex]&&(t=p[e.fieldIndex].targetEl,s=p[e.fieldIndex].badgeTargetEl)}const a=s||t;if(a){t==null||t.focus(),a.scrollIntoView({behavior:"smooth",block:"center"}),Y(a),C.action(`🎯 Audit Spotlight highlighted field '${e.fieldLabel||e.fieldName||e.fieldId}'`),i({success:!0});return}i({success:!1,reason:"Field not found"});return}if(e.type==="APPLY_FIELD_VALUE"){let t=null;if(e.fieldId&&(t=document.getElementById(e.fieldId)),!t&&e.fieldName&&(t=document.querySelector(`[name="${e.fieldName}"]`)),t&&typeof e.value=="string"){t.value=e.value,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.focus(),Y(t),C.action(`⚡ Applied Vault value to field '${e.fieldName||e.fieldId}': "${e.value}"`),i({success:!0});return}i({success:!1,reason:"Field or value invalid"});return}if(e.type==="START_SCAN_ANIMATION"){_e(),i({success:!0});return}if(e.type==="STOP_SCAN_ANIMATION"){ne(),i({success:!0});return}if(e.type==="SHOW_FIELD_NUMBERS"){Te(),i({success:!0,count:T.length});return}if(e.type==="HIDE_FIELD_NUMBERS"){ie(),i({success:!0});return}if(e.type==="NAVIGATE_TO_FIELD"){let t=null,s=null;const a=typeof e.fieldIndex=="number"?e.fieldIndex:-1;if(a>=0&&T[a]&&(t=T[a].targetEl,s=T[a].badgeTargetEl,T.forEach((d,x)=>{x===a?d.badgeEl.classList.add("active-badge"):d.badgeEl.classList.remove("active-badge")})),!t&&e.fieldId&&(t=document.getElementById(e.fieldId)),!t&&e.fieldName&&(t=document.querySelector(`[name="${e.fieldName}"]`)),!t&&a>=0){const d=G();d[a]&&(t=d[a].targetEl,s=d[a].badgeTargetEl)}const p=s||t;if(p){t==null||t.focus(),p.scrollIntoView({behavior:"smooth",block:"center"}),Y(p),i({success:!0,fieldIndex:a});return}i({success:!1,reason:"Field not found"});return}if(e.type==="START_SNIP_SELECTION"&&(C.action("✂️ Starting Visual Snip selection mode on screen for 'Explain This'"),Fe(),i({success:!0,mode:"active"})),e.type==="SHOW_FIELD_SPOTLIGHT"){let s=document.activeElement;if((!s||s.tagName==="BODY")&&(s=document.querySelector("input:not([type=hidden]), textarea, select")),s){s.focus(),s.scrollIntoView({behavior:"smooth",block:"center"}),Y(s),C.action(`💡 Spotlight Beacon navigated to field '${s.id||s.getAttribute("name")||"input"}'`),i({success:!0});return}i({success:!1,reason:"No target field found"})}if(e.type==="BATCH_AUTOFILL"){const t=e.payload||{},s=Array.isArray(e.items)?e.items:Array.isArray(t.items)?t.items:[],a=Array.from(document.querySelectorAll("input, textarea, select"));window.__SAVVY_UNDO_BACKUP__=a.map(d=>({el:d,prevVal:d.value}));let p=0;return a.forEach(d=>{if(d.type==="hidden"||d.type==="submit"||d.type==="button")return;const r=(D(d)||d.name||d.id||d.placeholder||"").toLowerCase().trim();let m="";if(s.length>0){const E=r.includes("mother")||r.includes("ibu");for(const h of s){const y=h.name.toLowerCase().trim();if(E&&(y.includes("nama lengkap")||y==="nama"||y==="full name")||!E&&y.includes("ibu"))continue;let w=r.length>1&&y.length>1&&(r===y||r.includes(y)||y.includes(r));if(!w&&Array.isArray(h.aliases)&&(w=h.aliases.some(l=>{const S=l.toLowerCase().trim();return S.length>1&&(r===S||r.includes(S)||S.includes(r))})),w&&h.value){m=h.value;break}}}m||(r.includes("nik")||r.includes("ktp")||r.includes("national id")?m=t.nik||t.NIK||"":r.includes("mother")||r.includes("ibu")?m=t["Nama Ibu Kandung"]||t.nama_ibu||"":r.includes("nama")||r.includes("name")||r.includes("fullname")?m=t.nama||t["Nama Lengkap"]||"":r.includes("place")||r.includes("tempat")||r.includes("pob")?m=t.tempat_lahir||t["Tempat Lahir"]||"":d.type==="date"||r.includes("tanggal_lahir")||r.includes("tgl_lahir")||r.includes("dob")||r.includes("birth")&&(r.includes("date")||r.includes("day"))||r.includes("lahir")&&r.includes("tgl")?m=t.tanggal_lahir||t["Tanggal Lahir"]||"":r.includes("alamat")||r.includes("address")||r.includes("domisili")?m=t.alamat||t["Alamat KTP"]||"":d.type==="email"||r.includes("email")||r.includes("mail")||r.includes("surel")?m=t.email||t.Email||"":(d.type==="tel"||r.includes("hp")||r.includes("phone")||r.includes("telp")||r.includes("whatsapp"))&&(m=t.no_hp||t["No. Handphone"]||"")),m&&(d.value=m,d.dispatchEvent(new Event("input",{bubbles:!0})),d.dispatchEvent(new Event("change",{bubbles:!0})),p++)}),C.action(`⚡ Batch Autofill executed: ${p} fields populated safely with reversibility snapshot.`,{injectedCount:p,keys:Object.keys(t)}),i({success:!0,count:p}),!0}if(e.type==="UNDO_AUTOFILL"){const t=window.__SAVVY_UNDO_BACKUP__;if(t&&Array.isArray(t)){t.forEach(({el:a,prevVal:p})=>{a&&(a.value=p,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})))});const s=t.length;return delete window.__SAVVY_UNDO_BACKUP__,C.action(`↩️ Undo Autofill executed: Restored previous values across ${s} fields.`),i({success:!0,undone:!0}),!0}i({success:!1,reason:"No backup state found"})}return!0});function Fe(){const e=F.querySelector(".savvy-lightshot-container");e&&e.remove(),C.action("✂️ Activating Lightshot-style visual crop mode on screen.");const o=document.createElement("div");o.className="savvy-lightshot-container",o.style.cssText=`
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483647;
      cursor: crosshair;
      user-select: none;
      -webkit-user-select: none;
      background: rgba(15, 23, 42, 0.45);
      transition: background 0.15s ease-out;
      pointer-events: auto;
    `;const i=document.createElement("div");i.style.cssText=`
      position: fixed;
      top: 18px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(15, 23, 42, 0.92);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #FFFFFF;
      padding: 8px 18px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 2147483647;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const c=J();i.innerHTML=`
      <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; color: #60A5FA;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>
        </svg>
        <span>${c.snipTitle}</span>
      </div>
      <div style="width: 1px; height: 14px; background: rgba(255, 255, 255, 0.2);"></div>
      <span style="color: #E2E8F0; font-size: 12px;">${c.snipInstruction}</span>
    `,o.appendChild(i);const n=document.createElement("div");n.style.cssText=`
      position: fixed;
      display: none;
      border: 2px solid #398CF5;
      box-shadow: 0 0 0 99999px rgba(15, 23, 42, 0.65);
      background: transparent;
      pointer-events: auto;
      z-index: 2147483647;
      box-sizing: border-box;
    `;const u=document.createElement("div");u.style.cssText=`
      position: absolute;
      top: -26px;
      left: -2px;
      background: #0F172A;
      color: #93C5FD;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 4px;
      pointer-events: none;
      white-space: nowrap;
      font-family: monospace, system-ui, sans-serif;
      border: 1px solid rgba(59, 130, 246, 0.4);
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    `,n.appendChild(u),["nw","n","ne","e","se","s","sw","w"].forEach(f=>{const b=document.createElement("div");b.dataset.handle=f;let v="default";f==="nw"||f==="se"?v="nwse-resize":f==="ne"||f==="sw"?v="nesw-resize":f==="n"||f==="s"?v="ns-resize":(f==="e"||f==="w")&&(v="ew-resize"),b.style.cssText=`
        position: absolute;
        width: 8px;
        height: 8px;
        background: #FFFFFF;
        border: 2px solid #398CF5;
        border-radius: 1px;
        z-index: 10;
        cursor: ${v};
        box-sizing: border-box;
      `,f.includes("n")&&(b.style.top="-5px"),f.includes("s")&&(b.style.bottom="-5px"),f.includes("w")&&(b.style.left="-5px"),f.includes("e")&&(b.style.right="-5px"),(f==="n"||f==="s")&&(b.style.left="50%",b.style.transform="translateX(-50%)"),(f==="w"||f==="e")&&(b.style.top="50%",b.style.transform="translateY(-50%)"),n.appendChild(b)});const t=document.createElement("div");t.style.cssText=`
      position: absolute;
      display: none;
      align-items: center;
      gap: 6px;
      padding: 5px 6px;
      background: #0F172A;
      border-radius: 8px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6);
      z-index: 25;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const s=document.createElement("button");s.style.cssText=`
      background: linear-gradient(135deg, #398CF5 0%, #7045ED 100%);
      color: #FFFFFF;
      font-weight: 600;
      font-size: 12px;
      padding: 6px 14px;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      white-space: nowrap;
      transition: all 0.15s ease;
      box-shadow: 0 2px 8px rgba(57, 140, 245, 0.35);
    `,s.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
      </svg>
      <span>${c.snipExplainBtn}</span>
    `;const a=document.createElement("button");a.style.cssText=`
      background: #1E293B;
      color: #CBD5E1;
      font-weight: 500;
      font-size: 12px;
      padding: 6px 11px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      white-space: nowrap;
      transition: all 0.15s ease;
    `,a.innerHTML=`
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
      <span>${c.snipCopyBtn}</span>
    `;const p=document.createElement("button");p.style.cssText=`
      background: #1E293B;
      color: #EF4444;
      font-weight: 700;
      font-size: 13px;
      padding: 6px 10px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      transition: all 0.15s ease;
    `,p.innerHTML="✕",p.title=c.snipCancelTitle,t.appendChild(s),t.appendChild(a),t.appendChild(p),n.appendChild(t),o.appendChild(n),F.appendChild(o);let d=!1,x=!1,r=!1,m="",E=0,h=0,y=0,w=0;const l={left:0,top:0,width:0,height:0};function S(){const f=Math.max(0,l.left),b=Math.max(0,l.top),v=Math.max(0,l.width),k=Math.max(0,l.height);n.style.left=`${f}px`,n.style.top=`${b}px`,n.style.width=`${v}px`,n.style.height=`${k}px`,u.textContent=`${Math.round(v)} × ${Math.round(k)} px`,b+k+50>window.innerHeight?t.style.bottom="8px":t.style.bottom="-48px",f+v<280?(t.style.right="auto",t.style.left="0px"):(t.style.left="auto",t.style.right="0px")}function q(){o.remove(),document.removeEventListener("keydown",P),window.removeEventListener("mousemove",we),window.removeEventListener("mouseup",Ee)}function P(f){f.key==="Escape"?q():f.key==="Enter"&&n.style.display!=="none"&&l.width>20&&l.height>20&&ve()}document.addEventListener("keydown",P);function O(){var K;const f=[],b=l.left,v=l.top,k=l.left+l.width,W=l.top+l.height,ee=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(A){if(!A.nodeValue||!A.nodeValue.trim())return NodeFilter.FILTER_REJECT;const B=A.parentElement;if(!B||B.closest("#savvy-root"))return NodeFilter.FILTER_REJECT;const H=window.getComputedStyle(B);return H.display==="none"||H.visibility==="hidden"||H.opacity==="0"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let R;for(;R=ee.nextNode();)try{const A=document.createRange();A.selectNode(R);const B=A.getClientRects();for(let H=0;H<B.length;H++){const $=B[H];if(!($.right<b||$.left>k||$.bottom<v||$.top>W)){const j=(K=R.nodeValue)==null?void 0:K.trim();j&&!f.includes(j)&&f.push(j);break}}}catch{}document.querySelectorAll("input, textarea, select").forEach(A=>{const B=A.getBoundingClientRect();if(!(B.right<b||B.left>k||B.bottom<v||B.top>W)){const $=A,ce=$.value||$.placeholder||"",j=$.getAttribute("aria-label")||$.name||$.id||"";(ce||j)&&f.push(`[Field ${j}: ${ce}]`)}});let U=f.join(" ").trim();return U=U.replace(/\b[1-9][0-9]{15}\b/g,"[REDACTED_NIK]"),U}function ve(){var v,k,W,ee,R,le,U,K;const f=O();C.action("⚡ Visual crop snip confirmed by user.",{rect:l,extractedLength:f.length,preview:f.slice(0,100)});const b={description:((v=document.querySelector('meta[name="description"]'))==null?void 0:v.getAttribute("content"))||((k=document.querySelector('meta[property="og:description"]'))==null?void 0:k.getAttribute("content"))||"",keywords:((W=document.querySelector('meta[name="keywords"]'))==null?void 0:W.getAttribute("content"))||"",ogTitle:((ee=document.querySelector('meta[property="og:title"]'))==null?void 0:ee.getAttribute("content"))||"",ogDescription:((R=document.querySelector('meta[property="og:description"]'))==null?void 0:R.getAttribute("content"))||"",ogType:((le=document.querySelector('meta[property="og:type"]'))==null?void 0:le.getAttribute("content"))||"",lang:document.documentElement.lang||navigator.language||"id-ID",author:((U=document.querySelector('meta[name="author"]'))==null?void 0:U.getAttribute("content"))||"",canonicalUrl:((K=document.querySelector('link[rel="canonical"]'))==null?void 0:K.getAttribute("href"))||window.location.href};n.style.borderColor="#10B981",n.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65), 0 0 25px rgba(16, 185, 129, 0.6)",u.textContent=J().snipCapturing,u.style.color="#34D399",s.disabled=!0,s.style.opacity="0.7",o.style.visibility="hidden",setTimeout(()=>{chrome.runtime.sendMessage({type:"CAPTURE_VISIBLE_TAB"},A=>{q(),chrome.runtime.sendMessage({type:"SNIP_EXPLAIN_RESULT",fullScreenshot:A!=null&&A.success?A.dataUrl:null,text:f,rect:{left:Math.round(l.left),top:Math.round(l.top),width:Math.round(l.width),height:Math.round(l.height),viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,devicePixelRatio:window.devicePixelRatio||1},portalUrl:window.location.href,portalDomain:window.location.hostname,pageTitle:document.title,meta:b})})},60)}s.addEventListener("click",f=>{f.stopPropagation(),ve()}),a.addEventListener("click",f=>{f.stopPropagation();const b=O();if(b){navigator.clipboard.writeText(b);const v=J();a.innerHTML=`✓ ${v.snipCopied}`,setTimeout(()=>{a.innerHTML=`
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            <span>${v.snipCopyBtn}</span>
          `},1500)}}),p.addEventListener("click",f=>{f.stopPropagation(),q()}),o.addEventListener("mousedown",f=>{var v;const b=f.target;if(!t.contains(b)){if((v=b.dataset)!=null&&v.handle){f.preventDefault(),f.stopPropagation(),r=!0,m=b.dataset.handle,E=f.clientX,h=f.clientY,t.style.display="none";return}if(n.contains(b)&&b!==o){f.preventDefault(),f.stopPropagation(),x=!0,y=f.clientX-l.left,w=f.clientY-l.top,n.style.cursor="move",t.style.display="none";return}f.preventDefault(),d=!0,E=f.clientX,h=f.clientY,l.left=E,l.top=h,l.width=0,l.height=0,o.style.background="transparent",n.style.display="block",n.style.borderColor="#398CF5",n.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65)",n.style.cursor="crosshair",t.style.display="none",S()}});function we(f){if(d){const b=f.clientX,v=f.clientY;l.left=Math.min(E,b),l.top=Math.min(h,v),l.width=Math.abs(b-E),l.height=Math.abs(v-h),S()}else if(x)l.left=Math.max(0,Math.min(window.innerWidth-l.width,f.clientX-y)),l.top=Math.max(0,Math.min(window.innerHeight-l.height,f.clientY-w)),S();else if(r){const b=f.clientX,v=f.clientY;if(m.includes("e")&&(l.width=Math.max(20,b-l.left)),m.includes("s")&&(l.height=Math.max(20,v-l.top)),m.includes("w")){const k=l.left+l.width;l.left=Math.min(k-20,b),l.width=k-l.left}if(m.includes("n")){const k=l.top+l.height;l.top=Math.min(k-20,v),l.height=k-l.top}S()}}window.addEventListener("mousemove",we);function Ee(f){if(d){if(d=!1,l.width<15&&l.height<15){o.style.display="none";const b=document.elementFromPoint(f.clientX,f.clientY);if(o.style.display="block",b&&!b.closest("#savvy-root")){const v=b.getBoundingClientRect();l.left=Math.max(0,v.left-4),l.top=Math.max(0,v.top-4),l.width=v.width+8,l.height=v.height+8}else l.left=Math.max(10,f.clientX-160),l.top=Math.max(10,f.clientY-60),l.width=320,l.height=120;S()}n.style.cursor="move",t.style.display="flex"}x&&(x=!1,n.style.cursor="move",t.style.display="flex"),r&&(r=!1,t.style.display="flex")}window.addEventListener("mouseup",Ee)}function Ie(){var i,c,n,u;const e=document.documentElement,o=document.body;ne(),ie(),fe(),V&&(V.style.display="none"),e.style.filter="",e.style.fontSize="",o.style.letterSpacing="",o.style.wordSpacing="",o.style.lineHeight="",o.style.textAlign="",o.style.fontFamily="",(i=document.getElementById("savvy-pause-anim"))==null||i.remove(),(c=document.getElementById("savvy-hide-img"))==null||c.remove(),(n=document.getElementById("savvy-highlight-links"))==null||n.remove(),(u=document.getElementById("savvy-big-cursor"))==null||u.remove();try{window.speechSynthesis&&window.speechSynthesis.cancel()}catch{}try{const g=F.querySelector(".savvy-lightshot-container");g&&g.remove()}catch{}C.action("🧹 All accessibility features and spotlights cleared.")}function re(e,o,i,c){var g,t,s,a,p,d,x;const n=document.documentElement,u=document.body;switch(e){case"spotlight":case"reading_spotlight":V.style.display=o&&i!=="Off"?"block":"none";break;case"contrast":case"high_contrast":!o||i==="Normal"?n.style.filter="":i==="High"?n.style.filter="contrast(180%) brightness(105%)":i==="Invert"?n.style.filter="invert(100%) hue-rotate(180deg)":i==="Monochrome"?n.style.filter="grayscale(100%) contrast(120%)":n.style.filter="contrast(180%) brightness(105%)";break;case"textSize":case"bigger_text":!o||i==="Normal"?n.style.fontSize="":i==="+25%"?n.style.fontSize="125%":i==="+50%"?n.style.fontSize="150%":i==="+75%"?n.style.fontSize="175%":i==="+100%"?n.style.fontSize="200%":n.style.fontSize="125%";break;case"textSpacing":case"text_spacing":!o||i==="Normal"?(u.style.letterSpacing="",u.style.wordSpacing=""):i!=null&&i.includes("+10%")?(u.style.letterSpacing="0.08em",u.style.wordSpacing="0.12em"):i!=null&&i.includes("+25%")?(u.style.letterSpacing="0.16em",u.style.wordSpacing="0.24em"):i!=null&&i.includes("+50%")?(u.style.letterSpacing="0.24em",u.style.wordSpacing="0.36em"):(u.style.letterSpacing="0.14em",u.style.wordSpacing="0.2em");break;case"pauseAnim":case"pause_animations":if(o&&i!=="Normal"){let r=document.getElementById("savvy-pause-anim");r||(r=document.createElement("style"),r.id="savvy-pause-anim",document.head.appendChild(r)),r.textContent="* { animation-play-state: paused !important; transition: none !important; }"}else(g=document.getElementById("savvy-pause-anim"))==null||g.remove();break;case"hideImages":case"hide_images":if(!o||i==="Normal")(t=document.getElementById("savvy-hide-img"))==null||t.remove();else{let r=document.getElementById("savvy-hide-img");r||(r=document.createElement("style"),r.id="savvy-hide-img",document.head.appendChild(r)),i==="Grayscale"?r.textContent="img, svg:not(.savvy-icon), video { filter: grayscale(100%) !important; opacity: 0.65 !important; }":r.textContent="img, svg:not(.savvy-icon), video { visibility: hidden !important; }"}break;case"links":case"highlight_links":if(!o||i==="Off")(s=document.getElementById("savvy-highlight-links"))==null||s.remove();else{let r=document.getElementById("savvy-highlight-links");r||(r=document.createElement("style"),r.id="savvy-highlight-links",document.head.appendChild(r)),i==="Underline"?r.textContent="a { text-decoration: underline 3px solid #2563EB !important; text-underline-offset: 4px !important; }":i==="High Contrast"?r.textContent="a { outline: 3px solid #2563EB !important; background-color: #EFF6FF !important; color: #1D4ED8 !important; text-decoration: underline !important; }":r.textContent="a { background-color: #FEF08A !important; color: #1E3A8A !important; text-decoration: underline !important; }"}break;case"dyslexiaFont":case"dyslexia_font":o&&i!=="Off"?u.style.fontFamily="Comic Sans MS, OpenDyslexic, sans-serif":u.style.fontFamily="";break;case"tts":case"text_to_speech":if(o&&i!=="Off"){(a=window.speechSynthesis)==null||a.cancel();const r=document.title+". "+(document.body.innerText||"").slice(0,400),m=new SpeechSynthesisUtterance(r);m.lang=document.documentElement.lang||"id-ID",(p=window.speechSynthesis)==null||p.speak(m)}else(d=window.speechSynthesis)==null||d.cancel();break;case"bigCursor":case"big_cursor":if(!o||i==="Normal")(x=document.getElementById("savvy-big-cursor"))==null||x.remove();else{let r=document.getElementById("savvy-big-cursor");if(r||(r=document.createElement("style"),r.id="savvy-big-cursor",document.head.appendChild(r)),i==="Large (White)"){const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='white' stroke='black' stroke-width='1.5'/%3E%3C/svg%3E";r.textContent=`* { cursor: url("${m}") 0 0, auto !important; }`}else if(i==="Highlighter"){const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Ccircle cx='24' cy='24' r='20' fill='rgba(254,240,138,0.65)' stroke='%23F59E0B' stroke-width='2.5'/%3E%3Ccircle cx='24' cy='24' r='3' fill='%23D97706'/%3E%3C/svg%3E";r.textContent=`* { cursor: url("${m}") 24 24, auto !important; }`}else{const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='black' stroke='white' stroke-width='1.5'/%3E%3C/svg%3E";r.textContent=`* { cursor: url("${m}") 0 0, auto !important; }`}}break;case"lineHeight":case"line_height":!o||i==="Normal"?u.style.lineHeight="":i==="1.5x"?u.style.lineHeight="1.5":i==="1.8x"?u.style.lineHeight="1.8":i==="2.2x"?u.style.lineHeight="2.2":u.style.lineHeight="1.8";break;case"textAlign":case"text_align":!o||i==="Normal"?u.style.textAlign="":i==="Left"?u.style.textAlign="left":i==="Center"?u.style.textAlign="center":i==="Justify"?u.style.textAlign="justify":u.style.textAlign="left";break;case"colorSat":case"color_saturation":!o||i==="Normal"?n.style.filter="":i!=null&&i.includes("High")?n.style.filter="saturate(200%)":i!=null&&i.includes("Low")?n.style.filter="saturate(40%)":i!=null&&i.includes("Monochrome")?n.style.filter="grayscale(100%)":n.style.filter="saturate(200%)";break;case"liveTooltips":case"live_tooltips":break;default:console.log("[Owly.AI Content] Toggled feature:",e,o,i)}}try{typeof chrome<"u"&&((xe=chrome.storage)!=null&&xe.local)&&chrome.storage.local.get(["savvy_sidepanel_open","savvy_a11y_settings"],e=>{e&&e.savvy_sidepanel_open&&e.savvy_a11y_settings&&Object.entries(e.savvy_a11y_settings).forEach(([o,i])=>{i&&i.enabled&&re(o,i.enabled,i.value,i.level)})})}catch{}})();
