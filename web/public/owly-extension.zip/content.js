(()=>{var fe;if(window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__)return;window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__=!0;try{document.documentElement.dataset.owlyExtension="installed",window.__OWLY_EXTENSION_INSTALLED__=!0}catch{}if(window.addEventListener("message",t=>{var i,n,d;if(((i=t.data)==null?void 0:i.type)==="OWLY_PING"&&window.postMessage({type:"OWLY_PONG",version:"1.0.0",installed:!0},"*"),((n=t.data)==null?void 0:n.type)==="OWLY_OPEN_SIDEPANEL")try{typeof chrome<"u"&&((d=chrome.runtime)!=null&&d.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}}),window.__SAVVY_OBSERVER__)try{window.__SAVVY_OBSERVER__.disconnect()}catch{}const me={PERCEPTION:{bg:"#398CF5",color:"#FFFFFF",icon:"👁️"},ACTION:{bg:"#F59E0B",color:"#000000",icon:"⚡"}};function re(t,i,n){var r;const d=new Date().toLocaleTimeString(),o=me[t]||{bg:"#398CF5",color:"#FFFFFF",icon:"🤖"},g=`background: ${o.bg}; color: ${o.color}; font-weight: bold; border-radius: 4px; padding: 2px 6px; font-size: 11px;`,l="color: #64748B; font-size: 10px; margin-left: 4px;",e="color: #0F172A; font-weight: 600; font-size: 12px;";n!==void 0?console.log(`%c${o.icon} [Savvy Agent: ${t}]%c ${d}%c ${i}`,g,l,e,n):console.log(`%c${o.icon} [Savvy Agent: ${t}]%c ${d}%c ${i}`,g,l,e);try{typeof chrome<"u"&&((r=chrome.runtime)!=null&&r.sendMessage)&&chrome.runtime.sendMessage({type:"AGENT_LOG_EVENT",event:{timestamp:d,domain:t,message:i,data:n?JSON.parse(JSON.stringify(n)):null}}).catch(()=>{})}catch{}}const E={perception:(t,i)=>re("PERCEPTION",t,i),action:(t,i)=>re("ACTION",t,i)};E.perception("Content Script activated. Closed Shadow DOM host initialized on page.");let F,T=null;try{const t=document.getElementById("savvy-root");if(t)try{t.remove()}catch{}T=document.createElement("div"),T.id="savvy-root",T.style.position="absolute",T.style.top="0",T.style.left="0",T.style.width="100%",T.style.height="100%",T.style.pointerEvents="none",T.style.zIndex="2147483647",(document.body||document.documentElement).appendChild(T),F=T.attachShadow({mode:"open"}),window.__SAVVY_SHADOW_ROOT__=F}catch(t){console.warn("[Savvy.AI] Shadow root attachment fallback:",t),F=window.__SAVVY_SHADOW_ROOT__||document.body}const le=document.createElement("style");le.textContent=`
    .savvy-spotlight {
      position: absolute;
      pointer-events: none;
      border: 2px solid #2563EB;
      background-color: rgba(37, 99, 235, 0.08);
      border-radius: 8px;
      transition: all 0.2s ease-out;
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
      z-index: 10;
    }
    .savvy-spotlight-beacon {
      position: absolute;
      top: -10px;
      right: -10px;
      width: 20px;
      height: 20px;
      background: #2563EB;
      color: white;
      font-size: 11px;
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    /* Virtual AI Ghost Cursor Pointer (Show Me Agent) */
    .savvy-ghost-cursor {
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 2147483647;
      transition: transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease;
      will-change: transform, opacity;
      display: none;
      opacity: 0;
    }
    .savvy-ghost-cursor.visible {
      display: block;
      opacity: 1;
    }
    .savvy-ghost-cursor svg {
      filter: drop-shadow(0 3px 8px rgba(0, 0, 0, 0.45));
      transform: rotate(-10deg);
      transition: transform 0.2s ease;
    }
    .savvy-ghost-cursor.clicking svg {
      transform: rotate(-10deg) scale(0.85);
    }
    .savvy-ghost-label {
      position: absolute;
      left: 22px;
      top: 14px;
      background: linear-gradient(135deg, #1e1b4b 0%, #2563eb 100%);
      color: #ffffff;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 999px;
      border: 1px solid rgba(255, 255, 255, 0.35);
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
      white-space: nowrap;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .savvy-ghost-pulse {
      position: absolute;
      top: 0px;
      left: 0px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(37, 99, 235, 0.45);
      border: 2px solid #60a5fa;
      transform: translate(-30%, -30%) scale(0);
      pointer-events: none;
      opacity: 0;
    }
    @keyframes savvy-ghost-ripple {
      0% { transform: translate(-30%, -30%) scale(0.3); opacity: 0.9; }
      50% { transform: translate(-30%, -30%) scale(2.8); opacity: 0.5; }
      100% { transform: translate(-30%, -30%) scale(4.8); opacity: 0; }
    }
    .savvy-ghost-pulse.active-pulse {
      animation: savvy-ghost-ripple 0.9s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
    }
    .savvy-reading-guide {
      position: fixed;
      left: 0;
      width: 100%;
      height: 48px;
      background: rgba(37, 99, 235, 0.12);
      border-top: 2px solid #2563EB;
      border-bottom: 2px solid #2563EB;
      pointer-events: none;
      z-index: 2147483646;
      display: none;
    }

    /* Scanner Laser Beam Animation */
    .savvy-scanner-overlay {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 2147483646;
      overflow: hidden;
      transition: opacity 0.3s ease;
    }
    .savvy-scanner-overlay.fade-out {
      opacity: 0;
    }
    .savvy-scanner-backdrop {
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at center, rgba(15, 23, 42, 0.18) 0%, rgba(15, 23, 42, 0.45) 100%);
    }
    .savvy-laser-beam {
      position: absolute;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, transparent 0%, rgba(56, 189, 248, 0.8) 15%, #2563EB 50%, rgba(56, 189, 248, 0.8) 85%, transparent 100%);
      box-shadow: 0 0 16px #38BDF8, 0 0 32px #2563EB, 0 0 4px #FFFFFF;
      animation: savvyLaserSweep 2.6s ease-in-out infinite alternate;
    }
    .savvy-laser-trail {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 90px;
      background: linear-gradient(to top, rgba(37, 99, 235, 0.18), transparent);
      pointer-events: none;
    }
    @keyframes savvyLaserSweep {
      0% {
        top: 2%;
      }
      100% {
        top: 98%;
      }
    }
    .savvy-scanner-card {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(15, 23, 42, 0.94);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(56, 189, 248, 0.35);
      border-radius: 18px;
      padding: 20px 32px;
      box-shadow: 0 20px 45px rgba(0, 0, 0, 0.5), 0 0 35px rgba(37, 99, 235, 0.25);
      text-align: center;
      color: #FFFFFF;
      z-index: 2147483647;
      pointer-events: auto;
      animation: savvyCardPop 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes savvyCardPop {
      0% { transform: translate(-50%, -46%) scale(0.95); opacity: 0; }
      100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
    }
    .savvy-scanner-card-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-bottom: 6px;
    }
    .savvy-scanner-spinner {
      width: 18px;
      height: 18px;
      border: 2.5px solid rgba(56, 189, 248, 0.25);
      border-top-color: #38BDF8;
      border-radius: 50%;
      animation: savvySpin 0.8s linear infinite;
    }
    @keyframes savvySpin {
      to { transform: rotate(360deg); }
    }
    .savvy-scanner-title {
      font-size: 15px;
      font-weight: 800;
      color: #FFFFFF;
      letter-spacing: -0.2px;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }
    .savvy-scanner-subtitle {
      font-size: 12px;
      color: #94A3B8;
      font-weight: 500;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }

    /* Numbered Field Badges */
    .savvy-field-number-badge {
      position: absolute;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: #2563EB;
      color: #FFFFFF;
      font-size: 11px;
      font-weight: 800;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(37, 99, 235, 0.45), 0 0 0 2px #FFFFFF;
      cursor: pointer;
      pointer-events: auto;
      z-index: 2147483647;
      transition: transform 0.15s ease, background 0.15s ease;
      user-select: none;
    }
    .savvy-field-number-badge:hover {
      background: #1D4ED8;
      transform: scale(1.22);
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.55), 0 0 0 2px #FFFFFF;
    }
    .savvy-field-number-badge.active-badge {
      background: #10B981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.4), 0 0 0 2px #FFFFFF;
      transform: scale(1.22);
    }
  `,F.appendChild(le);function ye(){Q();const t=document.createElement("div");t.className="savvy-scanner-overlay",t.innerHTML=`
      <div class="savvy-scanner-backdrop"></div>
      <div class="savvy-laser-beam">
        <div class="savvy-laser-trail"></div>
      </div>
      <div class="savvy-scanner-card">
        <div class="savvy-scanner-card-header">
          <span class="savvy-scanner-spinner"></span>
          <span class="savvy-scanner-title">This Page is being scanned by Owly.AI</span>
        </div>
        <div class="savvy-scanner-subtitle">Please wait until finish...</div>
      </div>
    `,F.appendChild(t),E.action("✨ Laser scanner animation activated on page.")}function Q(){const t=F.querySelector(".savvy-scanner-overlay");t&&(t.classList.add("fade-out"),setTimeout(()=>t.remove(),250),E.action("✨ Laser scanner animation stopped."))}function C(t){return t.replace(/[\n\r\t]+/g," ").replace(/\s+/g," ").replace(/[*:]+$/,"").trim()}function N(t){if(!t)return!1;const i=C(t);return!(i.length<2||i.length>70||/^(dd[\/\-\.]mm|yyyy[\/\-\.]mm|mm[\/\-\.]dd|hh:mm|08x|\+62|contoh|e\.g\.|example|\.\.\.|---)/i.test(i))}function q(t){var r;if(t.getAttribute("aria-label")&&N(t.getAttribute("aria-label")))return C(t.getAttribute("aria-label"));const i=t.getAttribute("aria-labelledby");if(i){const a=document.getElementById(i);if(a&&N(a.textContent))return C(a.textContent)}if(t.id){const a=document.querySelector(`label[for="${t.id}"]`);if(a&&N(a.textContent))return C(a.textContent)}const n=t.closest("label");if(n&&N(n.textContent))return C(n.textContent);let d=t.parentElement,o=0;for(;d&&o<5&&d.tagName!=="BODY"&&d.tagName!=="FORM";){let a=d.previousElementSibling;for(;a;){const u=a.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(u&&N(u.textContent))return C(u.textContent);if(N(a.textContent))return C(a.textContent);a=a.previousElementSibling}const p=d.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(p&&!p.contains(t)&&N(p.textContent))return C(p.textContent);if(d.tagName==="TR"){const u=d.querySelector("th, td:first-child");if(u&&!u.contains(t)&&N(u.textContent))return C(u.textContent)}d=d.parentElement,o++}let g=t.previousElementSibling;for(;g;){if(["LABEL","H3","H4","H5","H6","P","SPAN","STRONG","B","DIV"].includes(g.tagName)&&N(g.textContent))return C(g.textContent);g=g.previousElementSibling}try{const a=t.getBoundingClientRect();if(a.width>0&&a.height>0){const p=Array.from(document.querySelectorAll("label, .form-label, .col-form-label, dt, th, legend, h4, h5, h6, strong, b, [class*='label']"));let u=null,x=99999;for(const s of p){if(s.contains(t)||t.contains(s)||!N(s.textContent))continue;const m=s.getBoundingClientRect();if(m.width===0||m.height===0)continue;const _=m.right<=a.left+25&&m.left>=a.left-450&&Math.abs((m.top+m.bottom)/2-(a.top+a.bottom)/2)<28,h=m.bottom<=a.top+8&&m.bottom>=a.top-50&&m.left<a.right&&m.right>a.left-30;if(_){const y=a.left-m.right;y>=0&&y<x&&(x=y,u=s)}else if(h){const y=(a.top-m.bottom)*1.5;y>=0&&y<x&&(x=y,u=s)}}if(u&&u.textContent)return C(u.textContent)}}catch{}if(t.tagName==="BUTTON"||t.getAttribute("role")==="button"){const a=(r=t.textContent)==null?void 0:r.trim();if(a&&/^(upload|unggah|browse|pilih file|pilih berkas|choose file)$/i.test(a)){const p=t.closest(".card, .panel, .upload-container, .form-group, [class*='upload'], div");if(p){const u=p.querySelector("h3, h4, h5, h6, label, .title, strong");if(u&&N(u.textContent))return C(u.textContent)}}if(a)return C(a)}const l=t.getAttribute("placeholder");if(l&&N(l))return C(l);const e=t.getAttribute("name")||t.id||"";return e?e==="_username"||e==="username"?"Email":e==="_password"||e==="password"?"Password":C(e.replace(/[_\-]+/g," ")):"Kolom Form"}function j(){const t=[],i=new Set;return Array.from(document.querySelectorAll("input, select, textarea")).forEach(o=>{var r,a;if(o.type==="hidden"||o.type==="submit"||o.type==="reset")return;if(o.type==="file"){const p=o.getBoundingClientRect(),u=p.width>0&&p.height>0&&window.getComputedStyle(o).visibility!=="hidden";let x=o;if(!u){const s=o.id?document.querySelector(`label[for="${o.id}"]`):null,m=o.closest("label"),_=o.closest(".form-group, .upload-container, div"),h=_==null?void 0:_.querySelector("button, .btn, [role='button'], label"),y=[s,m,h].find(c=>{if(!c)return!1;const w=c.getBoundingClientRect();return w.width>0&&w.height>0&&window.getComputedStyle(c).visibility!=="hidden"});if(y)x=y;else return}i.add(o),i.add(x),t.push({targetEl:o,badgeTargetEl:x,id:o.id||o.name||"",name:o.name||"",label:q(x)||q(o)||"Upload File",placeholder:"",required:o.required,type:"file"});return}const g=o.getBoundingClientRect();if(!(g.width>0&&g.height>0&&window.getComputedStyle(o).visibility!=="hidden"))return;i.add(o);let e=q(o);if(o.type==="radio"||o.type==="checkbox"){const p=(a=(r=o.closest("label"))==null?void 0:r.textContent)==null?void 0:a.trim(),u=o.value;p&&!e.includes(p)?e=`${e} (${p})`:u&&u!=="on"&&!e.includes(u)&&(e=`${e} (${u})`)}t.push({targetEl:o,badgeTargetEl:o,id:o.id||o.name||"",name:o.name||"",label:e,placeholder:o.placeholder||"",required:o.required,type:o.type||o.tagName.toLowerCase()})}),Array.from(document.querySelectorAll("button, [role='button'], a.btn, label.btn, .upload-btn")).forEach(o=>{var e;if(i.has(o))return;const g=(o.textContent||"").trim().toLowerCase();if(/^(upload|unggah|browse|pilih file|pilih berkas|choose file)/i.test(g)||((e=o.getAttribute("aria-label"))==null?void 0:e.toLowerCase().includes("upload"))){const r=o.getBoundingClientRect();if(!(r.width>0&&r.height>0&&window.getComputedStyle(o).visibility!=="hidden"))return;i.add(o),t.push({targetEl:o,badgeTargetEl:o,id:o.id||"",name:o.getAttribute("name")||"",label:q(o),placeholder:"",required:!1,type:"file"})}}),t.sort((o,g)=>{const l=o.badgeTargetEl.getBoundingClientRect(),e=g.badgeTargetEl.getBoundingClientRect();return Math.abs(l.top-e.top)>12?l.top-e.top:l.left-e.left}),t}function be(){const i=j().map(l=>{var L,V,$;const e=l.targetEl;let r="";if(e)if(e.tagName==="SELECT"){const O=e;r=((L=O.options[O.selectedIndex])==null?void 0:L.text)||O.value||""}else if(e.type==="file")r=(($=(V=e.files)==null?void 0:V[0])==null?void 0:$.name)||"";else if(e.type==="checkbox"||e.type==="radio"){const O=e;r=O.checked?O.value||"checked":""}else r=e.value||"";const a=e.closest(".form-group, .mb-3, .form-row, tr, div")||e.parentElement,p=(a==null?void 0:a.textContent)||"",x=(l.label||"").includes("*")||p.includes("*")||e.getAttribute("aria-required")==="true",s=p.match(/\(([^)]+)\)/),m=s?s[0]:"",_="minLength"in e&&typeof e.minLength=="number"&&e.minLength>0?e.minLength:void 0,h="maxLength"in e&&typeof e.maxLength=="number"&&e.maxLength>0?e.maxLength:void 0,y=e.getAttribute("pattern")||void 0,c=e.getAttribute("data-mask")||e.getAttribute("data-inputmask")||void 0,w=e.getAttribute("accept")||void 0;return{fieldId:l.id||e.id||l.name,name:l.name||e.name||l.id,label:l.label,currentValue:r.trim(),surroundingContext:m,rules:{isRequired:e.required||x,placeholder:l.placeholder||e.placeholder||"",pattern:y,minLength:_,maxLength:h,type:l.type||e.type||"text",inputMaskDetected:c,accept:w}}}),n=[],d=Array.from(document.querySelectorAll("aside, .alert, .note, .keterangan, .sidebar, .info, footer, small, p, li")).map(l=>{var e;return((e=l.textContent)==null?void 0:e.trim())||""}).filter(l=>{const e=l.toLowerCase();return(e.includes("mb")||e.includes("kb")||e.includes("pdf")||e.includes("jpg")||e.includes("png"))&&(e.includes("maksimal")||e.includes("ukuran")||e.includes("file")||e.includes("berkas")||e.includes("format"))}).slice(0,5);n.push(...d);const o=[];return Array.from(document.querySelectorAll('input[type="file"]')).forEach(l=>{var e;if(l.files&&l.files.length>0){const r=l.files[0],a=r.name.includes(".")&&((e=r.name.split(".").pop())==null?void 0:e.toLowerCase())||"";o.push({fieldName:l.name||l.id||"file",fileName:r.name,fileSizeKb:Math.round(r.size/1024),fileExtension:a})}}),{fields:i,pageUploadContext:{pageWideFileInstructions:n,attachedFilesMetadata:o},meta:{url:window.location.href,domain:window.location.hostname,title:document.title}}}let S=[];function K(){const t=window.scrollY||document.documentElement.scrollTop,i=window.scrollX||document.documentElement.scrollLeft;S.forEach(({badgeEl:n,badgeTargetEl:d,targetEl:o})=>{const g=d||o;if(!document.body.contains(g)){n.style.display="none";return}const l=g.getBoundingClientRect();if(l.width===0&&l.height===0){n.style.display="none";return}n.style.display="flex",n.style.top=`${l.top+t-10}px`,n.style.left=`${l.right+i-12}px`})}function ve(){ee();const t=j(),i=window.scrollY||document.documentElement.scrollTop,n=window.scrollX||document.documentElement.scrollLeft;t.forEach((d,o)=>{const g=o+1,l=d.badgeTargetEl.getBoundingClientRect(),e=document.createElement("div");e.className="savvy-field-number-badge",e.textContent=`${g}`,e.title=`Kolom #${g}: ${d.label} (Klik untuk panduan)`,e.style.top=`${l.top+i-10}px`,e.style.left=`${l.right+n-12}px`,e.addEventListener("click",r=>{r.stopPropagation(),r.preventDefault(),d.targetEl.focus(),d.badgeTargetEl.scrollIntoView({behavior:"smooth",block:"center"}),Y(d.badgeTargetEl),S.forEach((a,p)=>{p===o?a.badgeEl.classList.add("active-badge"):a.badgeEl.classList.remove("active-badge")});try{chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:o,fieldId:d.id||"",fieldName:d.name||"",label:d.label}).catch(()=>{})}catch{}}),F.appendChild(e),S.push({badgeEl:e,targetEl:d.targetEl,badgeTargetEl:d.badgeTargetEl,index:o})}),window.addEventListener("scroll",K,{passive:!0}),window.addEventListener("resize",K,{passive:!0}),E.action(`🔢 Rendered numbered badges for ${t.length} interactive fields.`)}function ee(){S.forEach(({badgeEl:t})=>t.remove()),S=[],window.removeEventListener("scroll",K),window.removeEventListener("resize",K)}const M=document.createElement("div");M.className="savvy-spotlight",M.style.display="none",M.innerHTML='<div class="savvy-spotlight-beacon">S</div>',F.appendChild(M);const I=document.createElement("div");I.className="savvy-ghost-cursor",I.innerHTML=`
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
      <path d="M4 3L11 20L14 13L21 10L4 3Z" fill="#2563EB" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <div class="savvy-ghost-pulse"></div>
    <div class="savvy-ghost-label">
      <span>✨</span> Owly
    </div>
  `,F.appendChild(I);let te={x:window.innerWidth*.7,y:window.innerHeight*.3};window.addEventListener("mousemove",t=>{te={x:t.clientX,y:t.clientY}},{passive:!0});let J=null;function ne(t){J&&clearTimeout(J),t.scrollIntoView({behavior:"smooth",block:"center"}),setTimeout(()=>{const i=t.getBoundingClientRect(),n=i.left+Math.min(Math.max(i.width*.5,12),i.width-8),d=i.top+Math.min(Math.max(i.height*.5,12),i.height-8);I.style.transition="none",I.style.transform=`translate(${te.x}px, ${te.y}px)`,I.classList.remove("clicking");const o=I.querySelector(".savvy-ghost-pulse");o&&o.classList.remove("active-pulse"),I.classList.add("visible"),requestAnimationFrame(()=>{I.style.transition="transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease",I.style.transform=`translate(${n}px, ${d}px)`,J=setTimeout(()=>{I.classList.add("clicking"),o&&o.classList.add("active-pulse"),Y(t),J=setTimeout(()=>{I.classList.remove("visible"),I.classList.remove("clicking"),o&&o.classList.remove("active-pulse")},1800)},850)})},150)}let z=null;function ce(){M&&(M.style.display="none"),z&&(clearTimeout(z),z=null)}function Y(t){const i=t.getBoundingClientRect(),n=window.scrollY||document.documentElement.scrollTop,d=window.scrollX||document.documentElement.scrollLeft;M.style.display="block",M.style.top=`${i.top+n-4}px`,M.style.left=`${i.left+d-4}px`,M.style.width=`${i.width+8}px`,M.style.height=`${i.height+8}px`,z&&clearTimeout(z),z=setTimeout(()=>{M.style.display="none"},4e3)}const H=document.createElement("div");H.className="savvy-reading-guide",F.appendChild(H),window.addEventListener("mousemove",t=>{H.style.display==="block"&&(H.style.top=`${t.clientY-24}px`)}),document.addEventListener("focusin",t=>{var n;const i=t.target;if(i&&(i.tagName==="INPUT"||i.tagName==="SELECT"||i.tagName==="TEXTAREA"||i.tagName==="BUTTON")){const d=q(i);E.perception(`🎯 Field focused: '${i.id||i.getAttribute("name")||i.tagName.toLowerCase()}' (${d})`,{fieldId:i.id||"",tagName:i.tagName,inputType:i.type||"text",hasValue:!!i.value});try{if(typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&(chrome.runtime.sendMessage({type:"FIELD_FOCUSED",fieldId:i.id||"",fieldName:i.getAttribute("name")||"",label:d,tagName:i.tagName,inputType:i.type||"text",value:i.value||""}).catch(()=>{}),S.length>0)){const o=S.findIndex(g=>g.targetEl===i||g.badgeTargetEl===i);o!==-1&&(S.forEach((g,l)=>{l===o?g.badgeEl.classList.add("active-badge"):g.badgeEl.classList.remove("active-badge")}),chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:o,fieldId:i.id||"",fieldName:i.getAttribute("name")||"",label:d}).catch(()=>{}))}}catch{}}}),document.addEventListener("focusout",()=>{ce()});let de=null,ue="";function xe(){return Array.from(document.querySelectorAll("input, select, textarea")).filter(n=>n.type!=="hidden"&&n.type!=="submit"&&n.offsetParent!==null).map(n=>{const d="placeholder"in n?n.placeholder:"";return`${n.name||n.id||d}:${n.type||n.tagName.toLowerCase()}`}).join("|")}function ie(){clearTimeout(de),de=setTimeout(()=>{const t=xe();if(t!==ue){ue=t;const i=t?t.split("|").length:0;E.perception(`🕵️ Dynamic DOM Mutation detected (${i} visible fields)`,{fieldCount:i,signature:t.substring(0,80)+(t.length>80?"...":"")}),chrome.runtime.sendMessage({type:"FORM_DOM_MUTATED",signature:t,fieldCount:i}).catch(()=>{})}},400)}const pe=new MutationObserver(t=>{t.some(n=>T?n.target!==T&&!T.contains(n.target):!0)&&ie()});window.__SAVVY_OBSERVER__=pe,pe.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["hidden","disabled","aria-hidden","style","class"]}),window.addEventListener("popstate",ie),window.addEventListener("hashchange",ie);const we={"bikin akun":["sign up","signup","register","daftar","registrasi","buat akun","create account","join"],"buat akun":["sign up","signup","register","daftar","registrasi","create account","join"],daftar:["sign up","signup","register","registrasi","buat akun","apply","pendaftaran"],masuk:["login","log in","sign in","signin","masuk"],login:["log in","sign in","signin","masuk"],signup:["sign up","register","daftar","registrasi","buat akun"],keluar:["logout","log out","sign out","keluar"],unggah:["upload","unggah","pilih berkas","pilih file","choose file","browse"],upload:["unggah","pilih berkas","pilih file","choose file","browse"],unduh:["download","unduh","unduh berkas","ambil file"],download:["unduh","unduh berkas","ambil file"],syarat:["persyaratan","kriteria","ketentuan","eligibility","terms","requirement"],persyaratan:["syarat","kriteria","ketentuan","eligibility","terms","requirement"],bantuan:["help","bantuan","faq","panduan","hubungi kami","contact","support"],biaya:["tarif","harga","biaya","fee","cost","pembayaran","payment"],kirim:["submit","kirim","send","ajukan","lanjut","next"],submit:["kirim","send","ajukan","simpan","save"],simpan:["save","simpan","submit"],batal:["cancel","batal","reset"]};function Ee(t){var m,_;const i=t.toLowerCase().trim();if(!i)return{success:!1};const n=i.replace(/\b(tombol|button|bagian|seksi|kolom|field|link|halaman|menu)\b/gi,"").trim(),d=n.length>=2?n:i,g=Array.from(document.querySelectorAll("button, a, input, select, textarea, [role='button'], [role='link'], [role='tab'], h1, h2, h3, h4, h5, h6, section, [id], label, dt, th")),l=[];for(const h of g){if(h.id==="savvy-root"||h.closest("#savvy-root"))continue;const y=h.getBoundingClientRect();if(y.width<=4||y.height<=4)continue;const c=window.getComputedStyle(h);c.visibility==="hidden"||c.display==="none"||c.opacity==="0"||l.push(h)}const e=h=>{var $;const y=h.getAttribute("aria-label")||"",c=h.placeholder||"",w=(($=h.textContent)==null?void 0:$.trim())||"",L=h.getAttribute("title")||"",V=h.value||"";return`${w} ${y} ${c} ${L} ${V}`.toLowerCase().replace(/\s+/g," ").trim()};let r=null,a=0;for(const h of l){const y=e(h);if(!y)continue;const c=/^(button|a|input|select|textarea)$/i.test(h.tagName)||h.getAttribute("role")==="button"||h.getAttribute("role")==="link";let w=0;y===d||y===i?w=c?100:85:y.includes(d)&&(w=c?80:65),w>a&&(a=w,r=h)}if(r&&a>=65)return ne(r),E.action(`🎯 [Show Me Level 1] Found exact/substring match for "${t}" -> <${r.tagName.toLowerCase()}>`,{score:a}),{success:!0,level:1,matchedText:((m=r.textContent)==null?void 0:m.trim().slice(0,50))||r.getAttribute("aria-label")||r.tagName,tag:r.tagName.toLowerCase()};for(const[h,y]of Object.entries(we))if(d.includes(h)||h.includes(d)){for(const c of y)for(const w of l)if(e(w).includes(c))return ne(w),E.action(`⚡ [Show Me Level 2] Found synonym match ("${h}" -> "${c}") for "${t}" -> <${w.tagName.toLowerCase()}>`),{success:!0,level:2,matchedText:((_=w.textContent)==null?void 0:_.trim().slice(0,50))||c,tag:w.tagName.toLowerCase()}}const p=l.filter(h=>{const y=h.tagName.toLowerCase();return y==="button"||y==="a"||y==="input"||h.getAttribute("role")==="button"||h.getAttribute("role")==="link"}),x=(p.length>=5?p:l).slice(0,20);return window.__SAVVY_SHOW_ME_CANDIDATES__=x,{success:!1,candidates:x.map((h,y)=>({domIndex:y,tag:h.tagName.toLowerCase(),text:(h.textContent||"").trim().replace(/\s+/g," ").slice(0,60),aria:h.getAttribute("aria-label")||"",placeholder:h.placeholder||""})).filter(h=>h.text.length>0||h.aria.length>0||h.placeholder.length>0)}}chrome.runtime.onMessage.addListener((t,i,n)=>{var d,o,g,l;if(t.type==="FIND_AND_HIGHLIGHT_ELEMENT"){const e=Ee(t.query||"");n(e);return}if(t.type==="HIGHLIGHT_DOM_ELEMENT_BY_INDEX"){const e=t.domIndex,r=window.__SAVVY_SHOW_ME_CANDIDATES__;if(r&&r[e]){const a=r[e];ne(a),n({success:!0,text:(d=a.textContent)==null?void 0:d.trim().slice(0,50)});return}n({success:!1,reason:"Element index not found in cache"});return}if(t.type==="INJECT_VALUE"){const{fieldId:e,fieldName:r,fieldIndex:a,value:p}=t;let u=null;if(typeof a=="number"&&S[a]&&(u=S[a].targetEl),!u&&e&&(u=document.getElementById(e)),!u&&r&&(u=document.querySelector(`[name="${r}"]`)),u&&"value"in u){u.value=p,u.dispatchEvent(new Event("input",{bubbles:!0})),u.dispatchEvent(new Event("change",{bubbles:!0})),u.dispatchEvent(new Event("blur",{bubbles:!0})),E.action(`⚡ Injected value into field '${e||r||a}'`,{targetTag:u.tagName}),n({success:!0});return}n({success:!1,reason:"Element not found"})}if(t.type==="SET_A11Y_FEATURE"){const{feature:e,enabled:r,value:a,level:p}=t;oe(e,r,a),E.action(`👓 A11y feature '${e}' set to: ${a||(r?"ON":"OFF")}`),n({success:!0,feature:e,enabled:r,value:a})}if(t.type==="APPLY_ALL_A11Y_SETTINGS"){const e=t.settings||{};Object.entries(e).forEach(([r,a])=>{a&&oe(r,a.enabled,a.value,a.level)}),n({success:!0,count:Object.keys(e).length})}if(t.type==="CLEAR_ALL_A11Y"){Ce(),n({success:!0});return}if(t.type==="SCAN_PAGE_FIELDS"||t.type==="QUERY_PAGE_FIELDS"){const r=j().map(p=>({id:p.id,name:p.name,label:p.label,placeholder:p.placeholder,required:p.required,type:p.type})),a={url:window.location.href,domain:window.location.hostname,title:document.title,description:((o=document.querySelector('meta[name="description"]'))==null?void 0:o.getAttribute("content"))||"",keywords:((l=(g=document.querySelector('meta[name="keywords"]'))==null?void 0:g.getAttribute("content"))==null?void 0:l.split(",").map(p=>p.trim()))||[]};E.perception(`🔍 Scanning DOM: Discovered ${r.length} synchronized form fields on ${a.domain}`,{count:r.length,title:a.title,fieldKeys:r.map(p=>p.name||p.id||p.label).slice(0,8)}),n({success:!0,fields:r,count:r.length,meta:a})}if(t.type==="EXTRACT_FORM_AUDIT_DATA"){const e=be();E.action(`🔍 EXTRACT_FORM_AUDIT_DATA: Scraped ${e.fields.length} active inputs and ${e.pageUploadContext.attachedFilesMetadata.length} attached files for audit.`),n({success:!0,data:e});return}if(t.type==="HIGHLIGHT_AUDIT_FIELD"){let e=null,r=null;if(t.fieldId&&(e=document.getElementById(t.fieldId)),!e&&t.fieldName&&(e=document.querySelector(`[name="${t.fieldName}"]`)),!e&&typeof t.fieldIndex=="number"){const p=j();p[t.fieldIndex]&&(e=p[t.fieldIndex].targetEl,r=p[t.fieldIndex].badgeTargetEl)}const a=r||e;if(a){e==null||e.focus(),a.scrollIntoView({behavior:"smooth",block:"center"}),Y(a),E.action(`🎯 Audit Spotlight highlighted field '${t.fieldLabel||t.fieldName||t.fieldId}'`),n({success:!0});return}n({success:!1,reason:"Field not found"});return}if(t.type==="APPLY_FIELD_VALUE"){let e=null;if(t.fieldId&&(e=document.getElementById(t.fieldId)),!e&&t.fieldName&&(e=document.querySelector(`[name="${t.fieldName}"]`)),e&&typeof t.value=="string"){e.value=t.value,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus(),Y(e),E.action(`⚡ Applied Vault value to field '${t.fieldName||t.fieldId}': "${t.value}"`),n({success:!0});return}n({success:!1,reason:"Field or value invalid"});return}if(t.type==="START_SCAN_ANIMATION"){ye(),n({success:!0});return}if(t.type==="STOP_SCAN_ANIMATION"){Q(),n({success:!0});return}if(t.type==="SHOW_FIELD_NUMBERS"){ve(),n({success:!0,count:S.length});return}if(t.type==="HIDE_FIELD_NUMBERS"){ee(),n({success:!0});return}if(t.type==="NAVIGATE_TO_FIELD"){let e=null,r=null;const a=typeof t.fieldIndex=="number"?t.fieldIndex:-1;if(a>=0&&S[a]&&(e=S[a].targetEl,r=S[a].badgeTargetEl,S.forEach((u,x)=>{x===a?u.badgeEl.classList.add("active-badge"):u.badgeEl.classList.remove("active-badge")})),!e&&t.fieldId&&(e=document.getElementById(t.fieldId)),!e&&t.fieldName&&(e=document.querySelector(`[name="${t.fieldName}"]`)),!e&&a>=0){const u=j();u[a]&&(e=u[a].targetEl,r=u[a].badgeTargetEl)}const p=r||e;if(p){e==null||e.focus(),p.scrollIntoView({behavior:"smooth",block:"center"}),Y(p),n({success:!0,fieldIndex:a});return}n({success:!1,reason:"Field not found"});return}if(t.type==="START_SNIP_SELECTION"&&(E.action("✂️ Starting Visual Snip selection mode on screen for 'Explain This'"),_e(),n({success:!0,mode:"active"})),t.type==="SHOW_FIELD_SPOTLIGHT"){let r=document.activeElement;if((!r||r.tagName==="BODY")&&(r=document.querySelector("input:not([type=hidden]), textarea, select")),r){r.focus(),r.scrollIntoView({behavior:"smooth",block:"center"}),Y(r),E.action(`💡 Spotlight Beacon navigated to field '${r.id||r.getAttribute("name")||"input"}'`),n({success:!0});return}n({success:!1,reason:"No target field found"})}if(t.type==="BATCH_AUTOFILL"){const e=t.payload||{},r=Array.isArray(t.items)?t.items:Array.isArray(e.items)?e.items:[],a=Array.from(document.querySelectorAll("input, textarea, select"));window.__SAVVY_UNDO_BACKUP__=a.map(u=>({el:u,prevVal:u.value}));let p=0;return a.forEach(u=>{if(u.type==="hidden"||u.type==="submit"||u.type==="button")return;const s=(q(u)||u.name||u.id||u.placeholder||"").toLowerCase().trim();let m="";if(r.length>0){const _=s.includes("mother")||s.includes("ibu");for(const h of r){const y=h.name.toLowerCase().trim();if(_&&(y.includes("nama lengkap")||y==="nama"||y==="full name")||!_&&y.includes("ibu"))continue;let c=s.length>1&&y.length>1&&(s===y||s.includes(y)||y.includes(s));if(!c&&Array.isArray(h.aliases)&&(c=h.aliases.some(w=>{const L=w.toLowerCase().trim();return L.length>1&&(s===L||s.includes(L)||L.includes(s))})),c&&h.value){m=h.value;break}}}m||(s.includes("nik")||s.includes("ktp")||s.includes("national id")?m=e.nik||e.NIK||"":s.includes("mother")||s.includes("ibu")?m=e["Nama Ibu Kandung"]||e.nama_ibu||"":s.includes("nama")||s.includes("name")||s.includes("fullname")?m=e.nama||e["Nama Lengkap"]||"":s.includes("place")||s.includes("tempat")||s.includes("pob")?m=e.tempat_lahir||e["Tempat Lahir"]||"":u.type==="date"||s.includes("tanggal_lahir")||s.includes("tgl_lahir")||s.includes("dob")||s.includes("birth")&&(s.includes("date")||s.includes("day"))||s.includes("lahir")&&s.includes("tgl")?m=e.tanggal_lahir||e["Tanggal Lahir"]||"":s.includes("alamat")||s.includes("address")||s.includes("domisili")?m=e.alamat||e["Alamat KTP"]||"":u.type==="email"||s.includes("email")||s.includes("mail")||s.includes("surel")?m=e.email||e.Email||"":(u.type==="tel"||s.includes("hp")||s.includes("phone")||s.includes("telp")||s.includes("whatsapp"))&&(m=e.no_hp||e["No. Handphone"]||"")),m&&(u.value=m,u.dispatchEvent(new Event("input",{bubbles:!0})),u.dispatchEvent(new Event("change",{bubbles:!0})),p++)}),E.action(`⚡ Batch Autofill executed: ${p} fields populated safely with reversibility snapshot.`,{injectedCount:p,keys:Object.keys(e)}),n({success:!0,count:p}),!0}if(t.type==="UNDO_AUTOFILL"){const e=window.__SAVVY_UNDO_BACKUP__;if(e&&Array.isArray(e)){e.forEach(({el:a,prevVal:p})=>{a&&(a.value=p,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})))});const r=e.length;return delete window.__SAVVY_UNDO_BACKUP__,E.action(`↩️ Undo Autofill executed: Restored previous values across ${r} fields.`),n({success:!0,undone:!0}),!0}n({success:!1,reason:"No backup state found"})}return!0});function _e(){const t=F.querySelector(".savvy-lightshot-container");t&&t.remove(),E.action("✂️ Activating Lightshot-style visual crop mode on screen.");const i=document.createElement("div");i.className="savvy-lightshot-container",i.style.cssText=`
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483647;
      cursor: crosshair;
      user-select: none;
      -webkit-user-select: none;
      background: rgba(15, 23, 42, 0.45);
      transition: background 0.15s ease-out;
      pointer-events: auto;
    `;const n=document.createElement("div");n.style.cssText=`
      position: fixed;
      top: 18px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(15, 23, 42, 0.92);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #FFFFFF;
      padding: 8px 18px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 2147483647;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `,n.innerHTML=`
      <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; color: #60A5FA;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>
        </svg>
        <span>Savvy Snip</span>
      </div>
      <div style="width: 1px; height: 14px; background: rgba(255, 255, 255, 0.2);"></div>
      <span style="color: #E2E8F0; font-size: 12px;">Seret kursor untuk memotong area teks • <strong>ESC</strong> untuk batal</span>
    `,i.appendChild(n);const d=document.createElement("div");d.style.cssText=`
      position: fixed;
      display: none;
      border: 2px solid #398CF5;
      box-shadow: 0 0 0 99999px rgba(15, 23, 42, 0.65);
      background: transparent;
      pointer-events: auto;
      z-index: 2147483647;
      box-sizing: border-box;
    `;const o=document.createElement("div");o.style.cssText=`
      position: absolute;
      top: -26px;
      left: -2px;
      background: #0F172A;
      color: #93C5FD;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 4px;
      pointer-events: none;
      white-space: nowrap;
      font-family: monospace, system-ui, sans-serif;
      border: 1px solid rgba(59, 130, 246, 0.4);
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    `,d.appendChild(o),["nw","n","ne","e","se","s","sw","w"].forEach(f=>{const b=document.createElement("div");b.dataset.handle=f;let v="default";f==="nw"||f==="se"?v="nwse-resize":f==="ne"||f==="sw"?v="nesw-resize":f==="n"||f==="s"?v="ns-resize":(f==="e"||f==="w")&&(v="ew-resize"),b.style.cssText=`
        position: absolute;
        width: 8px;
        height: 8px;
        background: #FFFFFF;
        border: 2px solid #398CF5;
        border-radius: 1px;
        z-index: 10;
        cursor: ${v};
        box-sizing: border-box;
      `,f.includes("n")&&(b.style.top="-5px"),f.includes("s")&&(b.style.bottom="-5px"),f.includes("w")&&(b.style.left="-5px"),f.includes("e")&&(b.style.right="-5px"),(f==="n"||f==="s")&&(b.style.left="50%",b.style.transform="translateX(-50%)"),(f==="w"||f==="e")&&(b.style.top="50%",b.style.transform="translateY(-50%)"),d.appendChild(b)});const l=document.createElement("div");l.style.cssText=`
      position: absolute;
      display: none;
      align-items: center;
      gap: 6px;
      padding: 5px 6px;
      background: #0F172A;
      border-radius: 8px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6);
      z-index: 25;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const e=document.createElement("button");e.style.cssText=`
      background: linear-gradient(135deg, #398CF5 0%, #7045ED 100%);
      color: #FFFFFF;
      font-weight: 600;
      font-size: 12px;
      padding: 6px 14px;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      white-space: nowrap;
      transition: all 0.15s ease;
      box-shadow: 0 2px 8px rgba(57, 140, 245, 0.35);
    `,e.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
      </svg>
      <span>Jelaskan dengan Savvy AI</span>
    `;const r=document.createElement("button");r.style.cssText=`
      background: #1E293B;
      color: #CBD5E1;
      font-weight: 500;
      font-size: 12px;
      padding: 6px 11px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      white-space: nowrap;
      transition: all 0.15s ease;
    `,r.innerHTML=`
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
      <span>Salin Teks</span>
    `;const a=document.createElement("button");a.style.cssText=`
      background: #1E293B;
      color: #EF4444;
      font-weight: 700;
      font-size: 13px;
      padding: 6px 10px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      transition: all 0.15s ease;
    `,a.innerHTML="✕",a.title="Batal (ESC)",l.appendChild(e),l.appendChild(r),l.appendChild(a),d.appendChild(l),i.appendChild(d),F.appendChild(i);let p=!1,u=!1,x=!1,s="",m=0,_=0,h=0,y=0;const c={left:0,top:0,width:0,height:0};function w(){const f=Math.max(0,c.left),b=Math.max(0,c.top),v=Math.max(0,c.width),k=Math.max(0,c.height);d.style.left=`${f}px`,d.style.top=`${b}px`,d.style.width=`${v}px`,d.style.height=`${k}px`,o.textContent=`${Math.round(v)} × ${Math.round(k)} px`,b+k+50>window.innerHeight?l.style.bottom="8px":l.style.bottom="-48px",f+v<280?(l.style.right="auto",l.style.left="0px"):(l.style.left="auto",l.style.right="0px")}function L(){i.remove(),document.removeEventListener("keydown",V),window.removeEventListener("mousemove",ge),window.removeEventListener("mouseup",he)}function V(f){f.key==="Escape"?L():f.key==="Enter"&&d.style.display!=="none"&&c.width>20&&c.height>20&&O()}document.addEventListener("keydown",V);function $(){var W;const f=[],b=c.left,v=c.top,k=c.left+c.width,G=c.top+c.height,Z=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(A){if(!A.nodeValue||!A.nodeValue.trim())return NodeFilter.FILTER_REJECT;const B=A.parentElement;if(!B||B.closest("#savvy-root"))return NodeFilter.FILTER_REJECT;const P=window.getComputedStyle(B);return P.display==="none"||P.visibility==="hidden"||P.opacity==="0"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let R;for(;R=Z.nextNode();)try{const A=document.createRange();A.selectNode(R);const B=A.getClientRects();for(let P=0;P<B.length;P++){const D=B[P];if(!(D.right<b||D.left>k||D.bottom<v||D.top>G)){const X=(W=R.nodeValue)==null?void 0:W.trim();X&&!f.includes(X)&&f.push(X);break}}}catch{}document.querySelectorAll("input, textarea, select").forEach(A=>{const B=A.getBoundingClientRect();if(!(B.right<b||B.left>k||B.bottom<v||B.top>G)){const D=A,se=D.value||D.placeholder||"",X=D.getAttribute("aria-label")||D.name||D.id||"";(se||X)&&f.push(`[Field ${X}: ${se}]`)}});let U=f.join(" ").trim();return U=U.replace(/\b[1-9][0-9]{15}\b/g,"[REDACTED_NIK]"),U}function O(){var v,k,G,Z,R,ae,U,W;const f=$();E.action("⚡ Visual crop snip confirmed by user.",{rect:c,extractedLength:f.length,preview:f.slice(0,100)});const b={description:((v=document.querySelector('meta[name="description"]'))==null?void 0:v.getAttribute("content"))||((k=document.querySelector('meta[property="og:description"]'))==null?void 0:k.getAttribute("content"))||"",keywords:((G=document.querySelector('meta[name="keywords"]'))==null?void 0:G.getAttribute("content"))||"",ogTitle:((Z=document.querySelector('meta[property="og:title"]'))==null?void 0:Z.getAttribute("content"))||"",ogDescription:((R=document.querySelector('meta[property="og:description"]'))==null?void 0:R.getAttribute("content"))||"",ogType:((ae=document.querySelector('meta[property="og:type"]'))==null?void 0:ae.getAttribute("content"))||"",lang:document.documentElement.lang||navigator.language||"id-ID",author:((U=document.querySelector('meta[name="author"]'))==null?void 0:U.getAttribute("content"))||"",canonicalUrl:((W=document.querySelector('link[rel="canonical"]'))==null?void 0:W.getAttribute("href"))||window.location.href};d.style.borderColor="#10B981",d.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65), 0 0 25px rgba(16, 185, 129, 0.6)",o.textContent="✓ Mengambil tangkapan layar...",o.style.color="#34D399",e.disabled=!0,e.style.opacity="0.7",i.style.visibility="hidden",setTimeout(()=>{chrome.runtime.sendMessage({type:"CAPTURE_VISIBLE_TAB"},A=>{L(),chrome.runtime.sendMessage({type:"SNIP_EXPLAIN_RESULT",fullScreenshot:A!=null&&A.success?A.dataUrl:null,text:f,rect:{left:Math.round(c.left),top:Math.round(c.top),width:Math.round(c.width),height:Math.round(c.height),viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,devicePixelRatio:window.devicePixelRatio||1},portalUrl:window.location.href,portalDomain:window.location.hostname,pageTitle:document.title,meta:b})})},60)}e.addEventListener("click",f=>{f.stopPropagation(),O()}),r.addEventListener("click",f=>{f.stopPropagation();const b=$();b&&(navigator.clipboard.writeText(b),r.innerHTML="✓ Tersalin!",setTimeout(()=>{r.innerHTML=`
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            <span>Salin Teks</span>
          `},1500))}),a.addEventListener("click",f=>{f.stopPropagation(),L()}),i.addEventListener("mousedown",f=>{var v;const b=f.target;if(!l.contains(b)){if((v=b.dataset)!=null&&v.handle){f.preventDefault(),f.stopPropagation(),x=!0,s=b.dataset.handle,m=f.clientX,_=f.clientY,l.style.display="none";return}if(d.contains(b)&&b!==i){f.preventDefault(),f.stopPropagation(),u=!0,h=f.clientX-c.left,y=f.clientY-c.top,d.style.cursor="move",l.style.display="none";return}f.preventDefault(),p=!0,m=f.clientX,_=f.clientY,c.left=m,c.top=_,c.width=0,c.height=0,i.style.background="transparent",d.style.display="block",d.style.borderColor="#398CF5",d.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65)",d.style.cursor="crosshair",l.style.display="none",w()}});function ge(f){if(p){const b=f.clientX,v=f.clientY;c.left=Math.min(m,b),c.top=Math.min(_,v),c.width=Math.abs(b-m),c.height=Math.abs(v-_),w()}else if(u)c.left=Math.max(0,Math.min(window.innerWidth-c.width,f.clientX-h)),c.top=Math.max(0,Math.min(window.innerHeight-c.height,f.clientY-y)),w();else if(x){const b=f.clientX,v=f.clientY;if(s.includes("e")&&(c.width=Math.max(20,b-c.left)),s.includes("s")&&(c.height=Math.max(20,v-c.top)),s.includes("w")){const k=c.left+c.width;c.left=Math.min(k-20,b),c.width=k-c.left}if(s.includes("n")){const k=c.top+c.height;c.top=Math.min(k-20,v),c.height=k-c.top}w()}}window.addEventListener("mousemove",ge);function he(f){if(p){if(p=!1,c.width<15&&c.height<15){i.style.display="none";const b=document.elementFromPoint(f.clientX,f.clientY);if(i.style.display="block",b&&!b.closest("#savvy-root")){const v=b.getBoundingClientRect();c.left=Math.max(0,v.left-4),c.top=Math.max(0,v.top-4),c.width=v.width+8,c.height=v.height+8}else c.left=Math.max(10,f.clientX-160),c.top=Math.max(10,f.clientY-60),c.width=320,c.height=120;w()}d.style.cursor="move",l.style.display="flex"}u&&(u=!1,d.style.cursor="move",l.style.display="flex"),x&&(x=!1,l.style.display="flex")}window.addEventListener("mouseup",he)}function Ce(){var n,d,o,g;const t=document.documentElement,i=document.body;Q(),ee(),ce(),H&&(H.style.display="none"),t.style.filter="",t.style.fontSize="",i.style.letterSpacing="",i.style.wordSpacing="",i.style.lineHeight="",i.style.textAlign="",i.style.fontFamily="",(n=document.getElementById("savvy-pause-anim"))==null||n.remove(),(d=document.getElementById("savvy-hide-img"))==null||d.remove(),(o=document.getElementById("savvy-highlight-links"))==null||o.remove(),(g=document.getElementById("savvy-big-cursor"))==null||g.remove();try{window.speechSynthesis&&window.speechSynthesis.cancel()}catch{}try{const l=F.querySelector(".savvy-lightshot-container");l&&l.remove()}catch{}E.action("🧹 All accessibility features and spotlights cleared.")}function oe(t,i,n,d){var l,e,r,a,p,u,x;const o=document.documentElement,g=document.body;switch(t){case"spotlight":case"reading_spotlight":H.style.display=i&&n!=="Off"?"block":"none";break;case"contrast":case"high_contrast":!i||n==="Normal"?o.style.filter="":n==="High"?o.style.filter="contrast(180%) brightness(105%)":n==="Invert"?o.style.filter="invert(100%) hue-rotate(180deg)":n==="Monochrome"?o.style.filter="grayscale(100%) contrast(120%)":o.style.filter="contrast(180%) brightness(105%)";break;case"textSize":case"bigger_text":!i||n==="Normal"?o.style.fontSize="":n==="+25%"?o.style.fontSize="125%":n==="+50%"?o.style.fontSize="150%":n==="+75%"?o.style.fontSize="175%":n==="+100%"?o.style.fontSize="200%":o.style.fontSize="125%";break;case"textSpacing":case"text_spacing":!i||n==="Normal"?(g.style.letterSpacing="",g.style.wordSpacing=""):n!=null&&n.includes("+10%")?(g.style.letterSpacing="0.08em",g.style.wordSpacing="0.12em"):n!=null&&n.includes("+25%")?(g.style.letterSpacing="0.16em",g.style.wordSpacing="0.24em"):n!=null&&n.includes("+50%")?(g.style.letterSpacing="0.24em",g.style.wordSpacing="0.36em"):(g.style.letterSpacing="0.14em",g.style.wordSpacing="0.2em");break;case"pauseAnim":case"pause_animations":if(i&&n!=="Normal"){let s=document.getElementById("savvy-pause-anim");s||(s=document.createElement("style"),s.id="savvy-pause-anim",document.head.appendChild(s)),s.textContent="* { animation-play-state: paused !important; transition: none !important; }"}else(l=document.getElementById("savvy-pause-anim"))==null||l.remove();break;case"hideImages":case"hide_images":if(!i||n==="Normal")(e=document.getElementById("savvy-hide-img"))==null||e.remove();else{let s=document.getElementById("savvy-hide-img");s||(s=document.createElement("style"),s.id="savvy-hide-img",document.head.appendChild(s)),n==="Grayscale"?s.textContent="img, svg:not(.savvy-icon), video { filter: grayscale(100%) !important; opacity: 0.65 !important; }":s.textContent="img, svg:not(.savvy-icon), video { visibility: hidden !important; }"}break;case"links":case"highlight_links":if(!i||n==="Off")(r=document.getElementById("savvy-highlight-links"))==null||r.remove();else{let s=document.getElementById("savvy-highlight-links");s||(s=document.createElement("style"),s.id="savvy-highlight-links",document.head.appendChild(s)),n==="Underline"?s.textContent="a { text-decoration: underline 3px solid #2563EB !important; text-underline-offset: 4px !important; }":n==="High Contrast"?s.textContent="a { outline: 3px solid #2563EB !important; background-color: #EFF6FF !important; color: #1D4ED8 !important; text-decoration: underline !important; }":s.textContent="a { background-color: #FEF08A !important; color: #1E3A8A !important; text-decoration: underline !important; }"}break;case"dyslexiaFont":case"dyslexia_font":i&&n!=="Off"?g.style.fontFamily="Comic Sans MS, OpenDyslexic, sans-serif":g.style.fontFamily="";break;case"tts":case"text_to_speech":if(i&&n!=="Off"){(a=window.speechSynthesis)==null||a.cancel();const s=document.title+". "+(document.body.innerText||"").slice(0,400),m=new SpeechSynthesisUtterance(s);m.lang=document.documentElement.lang||"id-ID",(p=window.speechSynthesis)==null||p.speak(m)}else(u=window.speechSynthesis)==null||u.cancel();break;case"bigCursor":case"big_cursor":if(!i||n==="Normal")(x=document.getElementById("savvy-big-cursor"))==null||x.remove();else{let s=document.getElementById("savvy-big-cursor");if(s||(s=document.createElement("style"),s.id="savvy-big-cursor",document.head.appendChild(s)),n==="Large (White)"){const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='white' stroke='black' stroke-width='1.5'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${m}") 0 0, auto !important; }`}else if(n==="Highlighter"){const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Ccircle cx='24' cy='24' r='20' fill='rgba(254,240,138,0.65)' stroke='%23F59E0B' stroke-width='2.5'/%3E%3Ccircle cx='24' cy='24' r='3' fill='%23D97706'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${m}") 24 24, auto !important; }`}else{const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='black' stroke='white' stroke-width='1.5'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${m}") 0 0, auto !important; }`}}break;case"lineHeight":case"line_height":!i||n==="Normal"?g.style.lineHeight="":n==="1.5x"?g.style.lineHeight="1.5":n==="1.8x"?g.style.lineHeight="1.8":n==="2.2x"?g.style.lineHeight="2.2":g.style.lineHeight="1.8";break;case"textAlign":case"text_align":!i||n==="Normal"?g.style.textAlign="":n==="Left"?g.style.textAlign="left":n==="Center"?g.style.textAlign="center":n==="Justify"?g.style.textAlign="justify":g.style.textAlign="left";break;case"colorSat":case"color_saturation":!i||n==="Normal"?o.style.filter="":n!=null&&n.includes("High")?o.style.filter="saturate(200%)":n!=null&&n.includes("Low")?o.style.filter="saturate(40%)":n!=null&&n.includes("Monochrome")?o.style.filter="grayscale(100%)":o.style.filter="saturate(200%)";break;case"liveTooltips":case"live_tooltips":break;default:console.log("[Savvy.AI Content] Toggled feature:",t,i,n)}}try{typeof chrome<"u"&&((fe=chrome.storage)!=null&&fe.local)&&chrome.storage.local.get(["savvy_sidepanel_open","savvy_a11y_settings"],t=>{t&&t.savvy_sidepanel_open&&t.savvy_a11y_settings&&Object.entries(t.savvy_a11y_settings).forEach(([i,n])=>{n&&n.enabled&&oe(i,n.enabled,n.value,n.level)})})}catch{}})();
