function Ge(W){if(!W||typeof W!="string")return null;const L=W.trim(),k=L.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);if(k){const[,B,A,N]=k;return{year:B,month:A.padStart(2,"0"),day:N.padStart(2,"0")}}const F=L.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);if(F){const[,B,A,N]=F,J=parseInt(B,10),ue=parseInt(A,10);let Q=B,S=A;return J>12&&ue<=12?(Q=B,S=A):ue>12&&J<=12?(Q=A,S=B):(Q=B,S=A),{year:N,month:S.padStart(2,"0"),day:Q.padStart(2,"0")}}const H={januari:"01",feb:"02",februari:"02",mar:"03",maret:"03",apr:"04",april:"04",mei:"05",jun:"06",juni:"06",jul:"07",juli:"07",agu:"08",agustus:"08",sep:"09",september:"09",okt:"10",oktober:"10",nov:"11",november:"11",des:"12",desember:"12",january:"01",february:"02",march:"03",may:"05",june:"06",july:"07",august:"08",october:"10",december:"12"},I=L.toLowerCase().match(/^(\d{1,2})\s+([a-z]+)\s+(\d{4})$/);if(I){const[,B,A,N]=I,J=H[A];if(J)return{year:N,month:J,day:B.padStart(2,"0")}}return null}function De(W,L,k){const F=Ge(W);if(!F)return W;if((L==null?void 0:L.type)==="date")return`${F.year}-${F.month}-${F.day}`;const H=` ${(L==null?void 0:L.placeholder)||""} ${(L==null?void 0:L.getAttribute("pattern"))||""} ${(L==null?void 0:L.name)||""} ${(L==null?void 0:L.id)||""}`.toLowerCase();if(H.includes("mm/dd")||H.includes("mm-dd")||H.includes("m/d/y")){const I=H.includes("mm-dd")?"-":"/";return`${F.month}${I}${F.day}${I}${F.year}`}if(H.includes("yyyy-mm")||H.includes("yyyy/mm")){const I=H.includes("yyyy/")?"/":"-";return`${F.year}${I}${F.month}${I}${F.day}`}return H.includes("dd/mm")||H.includes("d/m/y")?`${F.day}/${F.month}/${F.year}`:`${F.day}-${F.month}-${F.year}`}(()=>{var Be,Oe;if(window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__)return;window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__=!0;try{document.documentElement.dataset.owlyExtension="installed",window.__OWLY_EXTENSION_INSTALLED__=!0}catch{}if(document.addEventListener("click",e=>{var c,o;const n=e.target;if((c=n==null?void 0:n.closest)==null?void 0:c.call(n,"[data-owly-action='open-sidepanel'], #owly-access-btn"))try{typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}},!0),window.addEventListener("message",e=>{var n,i,c;if(((n=e.data)==null?void 0:n.type)==="OWLY_PING"&&window.postMessage({type:"OWLY_PONG",version:"1.0.0",installed:!0},"*"),((i=e.data)==null?void 0:i.type)==="OWLY_OPEN_SIDEPANEL")try{typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}}),window.__SAVVY_OBSERVER__)try{window.__SAVVY_OBSERVER__.disconnect()}catch{}const W={PERCEPTION:{bg:"#398CF5",color:"#FFFFFF",icon:"👁️"},ACTION:{bg:"#F59E0B",color:"#000000",icon:"⚡"}};function L(e,n,i){var r;const c=new Date().toLocaleTimeString(),o=W[e]||{bg:"#398CF5",color:"#FFFFFF",icon:"🤖"},d=`background: ${o.bg}; color: ${o.color}; font-weight: bold; border-radius: 4px; padding: 2px 6px; font-size: 11px;`,u="color: #64748B; font-size: 10px; margin-left: 4px;",t="color: #0F172A; font-weight: 600; font-size: 12px;";i!==void 0?console.log(`%c${o.icon} [Owly Agent: ${e}]%c ${c}%c ${n}`,d,u,t,i):console.log(`%c${o.icon} [Owly Agent: ${e}]%c ${c}%c ${n}`,d,u,t);try{typeof chrome<"u"&&((r=chrome.runtime)!=null&&r.sendMessage)&&chrome.runtime.sendMessage({type:"AGENT_LOG_EVENT",event:{timestamp:c,domain:e,message:n,data:i?JSON.parse(JSON.stringify(i)):null}}).catch(()=>{})}catch{}}const k={perception:(e,n)=>L("PERCEPTION",e,n),action:(e,n)=>L("ACTION",e,n)},F={en:{scannerTitle:"This Page is being scanned by Owly.AI",scannerSubtitle:"Please wait until finish...",snipTitle:"Owly Snip",snipInstruction:"Drag cursor over text or section to snip • ESC to cancel",snipExplainBtn:"Explain with Owly.AI",snipCopyBtn:"Copy Text",snipCopied:"Copied!",snipCancelTitle:"Cancel (ESC)",snipCapturing:"✓ Capturing screenshot...",defaultFieldLabel:"Form Field",defaultCheckboxLabel:"Consent / Agreement",badgeTitle:(e,n)=>`Field #${e}: ${n} (Click for guidance)`},id:{scannerTitle:"Halaman ini sedang dipindai oleh Owly.AI",scannerSubtitle:"Mohon tunggu hingga selesai...",snipTitle:"Owly Snip",snipInstruction:"Seret kursor untuk memotong area teks • ESC untuk batal",snipExplainBtn:"Jelaskan dengan Owly.AI",snipCopyBtn:"Salin Teks",snipCopied:"Tersalin!",snipCancelTitle:"Batal (ESC)",snipCapturing:"✓ Mengambil tangkapan layar...",defaultFieldLabel:"Kolom Formulir",defaultCheckboxLabel:"Persetujuan",badgeTitle:(e,n)=>`Kolom #${e}: ${n} (Klik untuk panduan)`}},H={en:"en-US",id:"id-ID",es:"es-ES",zh:"zh-CN",ar:"ar-SA",ja:"ja-JP",fr:"fr-FR",de:"de-DE",pt:"pt-BR",hi:"hi-IN",ko:"ko-KR",ms:"ms-MY",vi:"vi-VN",th:"th-TH"};let I="en";typeof chrome<"u"&&((Be=chrome.storage)!=null&&Be.local)&&(chrome.storage.local.get(["owly_preferred_lang","preferred_language"],e=>{const n=e.owly_preferred_lang||e.preferred_language;typeof n=="string"&&(I=n)}),chrome.storage.onChanged.addListener((e,n)=>{var i,c;if(n==="local"){const o=((i=e.owly_preferred_lang)==null?void 0:i.newValue)||((c=e.preferred_language)==null?void 0:c.newValue);typeof o=="string"&&(I=o)}}));function B(){return F[I]||F.en}k.perception("Content Script activated. Closed Shadow DOM host initialized on page.");let A,N=null;try{const e=document.getElementById("savvy-root");if(e)try{e.remove()}catch{}N=document.createElement("div"),N.id="savvy-root",N.style.position="absolute",N.style.top="0",N.style.left="0",N.style.width="100%",N.style.height="100%",N.style.pointerEvents="none",N.style.zIndex="2147483647",(document.body||document.documentElement).appendChild(N),A=N.attachShadow({mode:"open"}),window.__SAVVY_SHADOW_ROOT__=A}catch(e){console.warn("[Owly.AI] Shadow root attachment fallback:",e),A=window.__SAVVY_SHADOW_ROOT__||document.body}const J=document.createElement("style");J.textContent=`
    .savvy-spotlight {
      position: absolute;
      pointer-events: none;
      border: 2px solid #2563EB;
      background-color: rgba(37, 99, 235, 0.08);
      border-radius: 8px;
      transition: all 0.2s ease-out;
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
      z-index: 10;
    }
    .savvy-spotlight-beacon {
      position: absolute;
      top: -10px;
      right: -10px;
      width: 20px;
      height: 20px;
      background: #2563EB;
      color: white;
      font-size: 11px;
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    /* Virtual AI Ghost Cursor Pointer (Show Me Agent) */
    .savvy-ghost-cursor {
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 2147483647;
      transition: transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease;
      will-change: transform, opacity;
      display: none;
      opacity: 0;
    }
    .savvy-ghost-cursor.visible {
      display: block;
      opacity: 1;
    }
    .savvy-ghost-cursor svg {
      filter: drop-shadow(0 3px 8px rgba(0, 0, 0, 0.45));
      transform: rotate(-10deg);
      transition: transform 0.2s ease;
    }
    .savvy-ghost-cursor.clicking svg {
      transform: rotate(-10deg) scale(0.85);
    }
    .savvy-ghost-label {
      position: absolute;
      left: 22px;
      top: 14px;
      background: linear-gradient(135deg, #1e1b4b 0%, #2563eb 100%);
      color: #ffffff;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 999px;
      border: 1px solid rgba(255, 255, 255, 0.35);
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
      white-space: nowrap;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .savvy-ghost-pulse {
      position: absolute;
      top: 0px;
      left: 0px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(37, 99, 235, 0.45);
      border: 2px solid #60a5fa;
      transform: translate(-30%, -30%) scale(0);
      pointer-events: none;
      opacity: 0;
    }
    @keyframes savvy-ghost-ripple {
      0% { transform: translate(-30%, -30%) scale(0.3); opacity: 0.9; }
      50% { transform: translate(-30%, -30%) scale(2.8); opacity: 0.5; }
      100% { transform: translate(-30%, -30%) scale(4.8); opacity: 0; }
    }
    .savvy-ghost-pulse.active-pulse {
      animation: savvy-ghost-ripple 0.9s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
    }
    .savvy-reading-guide {
      position: fixed;
      left: 0;
      width: 100%;
      height: 48px;
      background: rgba(37, 99, 235, 0.12);
      border-top: 2px solid #2563EB;
      border-bottom: 2px solid #2563EB;
      pointer-events: none;
      z-index: 2147483646;
      display: none;
    }

    /* Scanner Laser Beam Animation */
    .savvy-scanner-overlay {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 2147483646;
      overflow: hidden;
      transition: opacity 0.3s ease;
    }
    .savvy-scanner-overlay.fade-out {
      opacity: 0;
    }
    .savvy-scanner-backdrop {
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at center, rgba(15, 23, 42, 0.18) 0%, rgba(15, 23, 42, 0.45) 100%);
    }
    .savvy-laser-beam {
      position: absolute;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, transparent 0%, rgba(56, 189, 248, 0.8) 15%, #2563EB 50%, rgba(56, 189, 248, 0.8) 85%, transparent 100%);
      box-shadow: 0 0 16px #38BDF8, 0 0 32px #2563EB, 0 0 4px #FFFFFF;
      animation: savvyLaserSweep 2.6s ease-in-out infinite alternate;
    }
    .savvy-laser-trail {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 90px;
      background: linear-gradient(to top, rgba(37, 99, 235, 0.18), transparent);
      pointer-events: none;
    }
    @keyframes savvyLaserSweep {
      0% {
        top: 2%;
      }
      100% {
        top: 98%;
      }
    }
    .savvy-scanner-card {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(15, 23, 42, 0.94);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(56, 189, 248, 0.35);
      border-radius: 18px;
      padding: 20px 32px;
      box-shadow: 0 20px 45px rgba(0, 0, 0, 0.5), 0 0 35px rgba(37, 99, 235, 0.25);
      text-align: center;
      color: #FFFFFF;
      z-index: 2147483647;
      pointer-events: auto;
      animation: savvyCardPop 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes savvyCardPop {
      0% { transform: translate(-50%, -46%) scale(0.95); opacity: 0; }
      100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
    }
    .savvy-scanner-card-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-bottom: 6px;
    }
    .savvy-scanner-spinner {
      width: 18px;
      height: 18px;
      border: 2.5px solid rgba(56, 189, 248, 0.25);
      border-top-color: #38BDF8;
      border-radius: 50%;
      animation: savvySpin 0.8s linear infinite;
    }
    @keyframes savvySpin {
      to { transform: rotate(360deg); }
    }
    .savvy-scanner-title {
      font-size: 15px;
      font-weight: 800;
      color: #FFFFFF;
      letter-spacing: -0.2px;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }
    .savvy-scanner-subtitle {
      font-size: 12px;
      color: #94A3B8;
      font-weight: 500;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }

    /* Numbered Field Badges */
    .savvy-field-number-badge {
      position: absolute;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: #2563EB;
      color: #FFFFFF;
      font-size: 11px;
      font-weight: 800;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(37, 99, 235, 0.45), 0 0 0 2px #FFFFFF;
      cursor: pointer;
      pointer-events: auto;
      z-index: 2147483647;
      transition: transform 0.15s ease, background 0.15s ease;
      user-select: none;
    }
    .savvy-field-number-badge:hover {
      background: #1D4ED8;
      transform: scale(1.22);
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.55), 0 0 0 2px #FFFFFF;
    }
    .savvy-field-number-badge.active-badge {
      background: #10B981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.4), 0 0 0 2px #FFFFFF;
      transform: scale(1.22);
    }
  `,A.appendChild(J);function ue(){Q();const e=B(),n=document.createElement("div");n.className="savvy-scanner-overlay",n.innerHTML=`
      <div class="savvy-scanner-backdrop"></div>
      <div class="savvy-laser-beam">
        <div class="savvy-laser-trail"></div>
      </div>
      <div class="savvy-scanner-card">
        <div class="savvy-scanner-card-header">
          <span class="savvy-scanner-spinner"></span>
          <span class="savvy-scanner-title">${e.scannerTitle}</span>
        </div>
        <div class="savvy-scanner-subtitle">${e.scannerSubtitle}</div>
      </div>
    `,A.appendChild(n),k.action("✨ Laser scanner animation activated on page.")}function Q(){const e=A.querySelector(".savvy-scanner-overlay");e&&(e.classList.add("fade-out"),setTimeout(()=>e.remove(),250),k.action("✨ Laser scanner animation stopped."))}function S(e){return e.replace(/[\n\r\t]+/g," ").replace(/\s+/g," ").replace(/[*:]+$/,"").trim()}function O(e){if(!e)return!1;const n=S(e);return!(n.length<2||n.length>70||/^(dd[\/\-\.]mm|yyyy[\/\-\.]mm|mm[\/\-\.]dd|hh:mm|08x|\+62|contoh|e\.g\.|example|\.\.\.|---)/i.test(n))}function G(e){var r;if(e.getAttribute("aria-label")&&O(e.getAttribute("aria-label")))return S(e.getAttribute("aria-label"));const n=e.getAttribute("aria-labelledby");if(n){const a=document.getElementById(n);if(a&&O(a.textContent))return S(a.textContent)}if(e.id){const a=document.querySelector(`label[for="${e.id}"]`);if(a&&O(a.textContent))return S(a.textContent)}const i=e.closest("label");if(i&&O(i.textContent))return S(i.textContent);let c=e.parentElement,o=0;for(;c&&o<5&&c.tagName!=="BODY"&&c.tagName!=="FORM";){const a=c.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(a&&!a.contains(e)&&O(a.textContent))return S(a.textContent);let s=c.previousElementSibling;for(;s;){const l=s.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(l&&O(l.textContent))return S(l.textContent);if(O(s.textContent))return S(s.textContent);s=s.previousElementSibling}if(c.tagName==="TR"){const l=c.querySelector("th, td:first-child");if(l&&!l.contains(e)&&O(l.textContent))return S(l.textContent)}c=c.parentElement,o++}let d=e.previousElementSibling;for(;d;){if(["LABEL","H3","H4","H5","H6","P","SPAN","STRONG","B","DIV"].includes(d.tagName)&&O(d.textContent))return S(d.textContent);d=d.previousElementSibling}try{const a=e.getBoundingClientRect();if(a.width>0&&a.height>0){const s=Array.from(document.querySelectorAll("label, .form-label, .col-form-label, dt, th, legend, h4, h5, h6, strong, b, [class*='label']"));let l=null,y=99999;for(const f of s){if(f.contains(e)||e.contains(f)||!O(f.textContent))continue;const h=f.getBoundingClientRect();if(h.width===0||h.height===0)continue;const T=h.right<=a.left+25&&h.left>=a.left-450&&Math.abs((h.top+h.bottom)/2-(a.top+a.bottom)/2)<28,$=h.bottom<=a.top+8&&h.bottom>=a.top-50&&h.left<a.right&&h.right>a.left-30;if(T){const g=a.left-h.right;g>=0&&g<y&&(y=g,l=f)}else if($){const g=(a.top-h.bottom)*1.5;g>=0&&g<y&&(y=g,l=f)}}if(l&&l.textContent)return S(l.textContent)}}catch{}if(e.tagName==="BUTTON"||e.getAttribute("role")==="button"){const a=(r=e.textContent)==null?void 0:r.trim();if(a&&/^(upload|unggah|browse|pilih file|pilih berkas|choose file)$/i.test(a)){const s=e.closest(".card, .panel, .upload-container, .form-group, [class*='upload'], div");if(s){const l=s.querySelector("h3, h4, h5, h6, label, .title, strong");if(l&&O(l.textContent))return S(l.textContent)}}if(a)return S(a)}const u=e.getAttribute("placeholder");if(u&&O(u))return S(u);const t=e.getAttribute("name")||e.id||"";return t?t==="_username"||t==="username"?"Email":t==="_password"||t==="password"?"Password":S(t.replace(/[_\-]+/g," ")):B().defaultFieldLabel||(I==="id"?"Kolom Formulir":"Form Field")}function re(e){var n,i,c;try{const o=e.closest("fieldset"),d=o==null?void 0:o.querySelector("legend");if((n=d==null?void 0:d.textContent)!=null&&n.trim())return d.textContent.trim().replace(/^[\d\.\-\s]+/,"").slice(0,45);let u=e.parentElement,t=0;for(;u&&t<6&&u!==document.body;){const a=u.querySelector("h1, h2, h3, h4, h5, .section-title, .card-title");if(a&&a!==e&&((i=a.textContent)!=null&&i.trim())){const s=a.textContent.trim().replace(/^[\d\.\-\s]+/,"").slice(0,45);if(s.length>2)return s}u=u.parentElement,t++}let r=e.previousElementSibling;for(;r;){if(/^H[1-5]$/i.test(r.tagName)&&((c=r.textContent)!=null&&c.trim()))return r.textContent.trim().replace(/^[\d\.\-\s]+/,"").slice(0,45);r=r.previousElementSibling}}catch{}return""}function Ee(e){var a;const n=e.name,i=n?Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape?CSS.escape(n):n}"]`)):[e],c=i.some(s=>s.required||s.getAttribute("aria-required")==="true"),o=e.closest("fieldset");if(o){const s=o.querySelector("legend");if(s&&O(s.textContent))return{title:S(s.textContent),badgeAnchor:s,isRequired:c}}let d=e.parentElement,u=0,t="",r=e;for(;d&&u<5&&d.tagName!=="BODY"&&d.tagName!=="FORM";){const s=Array.from(d.querySelectorAll("label, legend, .form-label, .col-form-label, h3, h4, h5, h6, strong, b, [class*='font-bold'], [class*='font-semibold']"));for(const y of s){if(y.querySelector("input"))continue;const f=y.getAttribute("for");if(f&&i.some(T=>T.id===f))continue;const h=(a=y.textContent)==null?void 0:a.trim();if(h&&O(h)){t=S(h),r=y;break}}if(t)break;let l=d.previousElementSibling;for(;l;){const y=l.matches("label, legend, h3, h4, h5, h6, strong, b")?l:l.querySelector("label, legend, h3, h4, h5, h6, strong, b");if(y&&!y.querySelector("input")&&O(y.textContent)){t=S(y.textContent),r=y;break}l=l.previousElementSibling}if(t)break;d=d.parentElement,u++}return t||(t=e.name?S(e.name.replace(/[_\-]+/g," ")):"Radio Group"),{title:t,badgeAnchor:r,isRequired:c}}function le(){const e=[],n=new Set;return Array.from(document.querySelectorAll("input, select, textarea")).forEach(o=>{var t;if(o.type==="hidden"||o.type==="submit"||o.type==="reset")return;if(o.type==="file"){const r=o.getBoundingClientRect(),a=r.width>0&&r.height>0&&window.getComputedStyle(o).visibility!=="hidden";let s=o;if(!a){const l=o.id?document.querySelector(`label[for="${o.id}"]`):null,y=o.closest("label"),f=o.closest(".form-group, .upload-container, div"),h=f==null?void 0:f.querySelector("button, .btn, [role='button'], label"),T=[l,y,h].find($=>{if(!$)return!1;const g=$.getBoundingClientRect();return g.width>0&&g.height>0&&window.getComputedStyle($).visibility!=="hidden"});if(T)s=T;else return}n.add(o),n.add(s),e.push({targetEl:o,badgeTargetEl:s,id:o.id||o.name||"",name:o.name||"",label:G(s)||G(o)||"Upload File",placeholder:"",required:o.required,type:"file",section:re(s)||re(o)});return}const d=o.getBoundingClientRect();if(d.width>0&&d.height>0&&window.getComputedStyle(o).visibility,o.type==="radio"&&o.name){if(e.find(s=>s.type==="radio"&&s.name===o.name)){n.add(o);return}const a=Ee(o);n.add(o),e.push({targetEl:o,badgeTargetEl:a.badgeAnchor,id:o.name,name:o.name,label:a.title,placeholder:"",required:a.isRequired,type:"radio",section:re(a.badgeAnchor)});return}if(o.type==="checkbox"){const r=o.closest("label"),a=o.closest(".p-4, .form-group, fieldset, div")||o.parentElement;n.add(o);const s=((t=r==null?void 0:r.textContent)==null?void 0:t.trim())||G(o)||B().defaultCheckboxLabel||(I==="id"?"Persetujuan":"Consent"),l=a||r||o;e.push({targetEl:o,badgeTargetEl:l,id:o.id||o.name||"checkbox",name:o.name||"",label:S(s),placeholder:"",required:o.required,type:"checkbox",section:re(l)});return}n.add(o);const u=G(o);e.push({targetEl:o,badgeTargetEl:o,id:o.id||o.name||"",name:o.name||"",label:u,placeholder:o.placeholder||"",required:o.required,type:o.type||o.tagName.toLowerCase(),section:re(o)})}),Array.from(document.querySelectorAll("button, [role='button'], a.btn, label.btn, .upload-btn")).forEach(o=>{var t;if(n.has(o))return;const d=(o.textContent||"").trim().toLowerCase();if(/^(upload|unggah|browse|pilih file|pilih berkas|choose file)/i.test(d)||((t=o.getAttribute("aria-label"))==null?void 0:t.toLowerCase().includes("upload"))){const r=o.getBoundingClientRect();if(!(r.width>0&&r.height>0&&window.getComputedStyle(o).visibility!=="hidden"))return;n.add(o),e.push({targetEl:o,badgeTargetEl:o,id:o.id||"",name:o.getAttribute("name")||"",label:G(o),placeholder:"",required:!1,type:"file"})}}),e.sort((o,d)=>{const u=o.badgeTargetEl.getBoundingClientRect(),t=d.badgeTargetEl.getBoundingClientRect();return Math.abs(u.top-t.top)>12?u.top-t.top:u.left-t.left}),e}function qe(){const n=le().filter(u=>{var a;const t=u.targetEl;if(!t)return!1;const r=t.tagName.toUpperCase();if(r==="BUTTON")return!1;if(r==="INPUT"){const s=(a=t.type)==null?void 0:a.toLowerCase();if(s==="hidden"||s==="submit"||s==="reset"||s==="button")return!1}return!0}).map(u=>{var C,_,M;const t=u.targetEl;let r="";if(t)if(t.tagName==="SELECT"){const w=t;r=((C=w.options[w.selectedIndex])==null?void 0:C.text)||w.value||""}else if(t.type==="file")r=((M=(_=t.files)==null?void 0:_[0])==null?void 0:M.name)||"";else if(t.type==="radio"||u.type==="radio"){const w=t.name||u.name,Y=(w?Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape?CSS.escape(w):w}"]`)):[t]).find(m=>m.checked);Y?r=G(Y)||Y.value||"checked":r=""}else if(t.type==="checkbox"){const w=t;r=w.checked?w.value||"checked":""}else r=t.value||"";const a=t.closest(".form-group, .mb-3, .form-row, tr, [class*='p-4'], [class*='p-5']")||t.parentElement,s=(a==null?void 0:a.textContent)||"",l=u.label||"",y=a?a.childElementCount<=6:!1;let f=l.includes("*")||y&&s.includes("*")||t.getAttribute("aria-required")==="true";if(t.type==="radio"||u.type==="radio"){const w=t.name||u.name;w&&Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape?CSS.escape(w):w}"]`)).some(m=>m.required||m.getAttribute("aria-required")==="true")&&(f=!0)}const h=s.match(/\(([^)]+)\)/),T=h?h[0]:"",$="minLength"in t&&typeof t.minLength=="number"&&t.minLength>0?t.minLength:void 0,g="maxLength"in t&&typeof t.maxLength=="number"&&t.maxLength>0?t.maxLength:void 0,x=t.getAttribute("pattern")||void 0,p=t.getAttribute("data-mask")||t.getAttribute("data-inputmask")||void 0,b=t.getAttribute("accept")||void 0;return{fieldId:u.id||t.id||u.name,name:u.name||t.name||u.id,label:u.label,currentValue:r.trim(),surroundingContext:T,rules:{isRequired:t.required||f,placeholder:u.placeholder||t.placeholder||"",pattern:x,minLength:$,maxLength:g,type:u.type||t.type||"text",inputMaskDetected:p,accept:b}}}),i=[],c=Array.from(document.querySelectorAll("aside, .alert, .note, .keterangan, .sidebar, .info, footer, small, p, li")).map(u=>{var t;return((t=u.textContent)==null?void 0:t.trim())||""}).filter(u=>{const t=u.toLowerCase();return(t.includes("mb")||t.includes("kb")||t.includes("pdf")||t.includes("jpg")||t.includes("png"))&&(t.includes("maksimal")||t.includes("ukuran")||t.includes("file")||t.includes("berkas")||t.includes("format"))}).slice(0,5);i.push(...c);const o=[];return Array.from(document.querySelectorAll('input[type="file"]')).forEach(u=>{var t;if(u.files&&u.files.length>0){const r=u.files[0],a=r.name.includes(".")&&((t=r.name.split(".").pop())==null?void 0:t.toLowerCase())||"";o.push({fieldName:u.name||u.id||"file",fileName:r.name,fileSizeKb:Math.round(r.size/1024),fileExtension:a})}}),{fields:n,pageUploadContext:{pageWideFileInstructions:i,attachedFilesMetadata:o},meta:{url:window.location.href,domain:window.location.hostname,title:document.title}}}let D=[];function ke(e,n,i){const c=e.getBoundingClientRect();return e.tagName==="INPUT"&&(e.type==="radio"||e.type==="checkbox")?{top:`${c.top+n-4}px`,left:`${c.left+i-26}px`}:{top:`${c.top+n-10}px`,left:`${c.right+i-12}px`}}function pe(){const e=window.scrollY||document.documentElement.scrollTop,n=window.scrollX||document.documentElement.scrollLeft;D.forEach(({badgeEl:i,badgeTargetEl:c,targetEl:o})=>{const d=c||o;if(!document.body.contains(d)){i.style.display="none";return}const u=d.getBoundingClientRect();if(u.width===0&&u.height===0){i.style.display="none";return}i.style.display="flex";const t=ke(d,e,n);i.style.top=t.top,i.style.left=t.left})}function Pe(){ge();const e=le(),n=window.scrollY||document.documentElement.scrollTop,i=window.scrollX||document.documentElement.scrollLeft;e.forEach((c,o)=>{const d=o+1,u=ke(c.badgeTargetEl,n,i),t=document.createElement("div");t.className="savvy-field-number-badge",t.textContent=`${d}`,t.title=B().badgeTitle?B().badgeTitle(d,c.label):I==="id"?`Kolom #${d}: ${c.label} (Klik untuk panduan)`:`Field #${d}: ${c.label} (Click for guidance)`,t.style.top=u.top,t.style.left=u.left,t.addEventListener("click",r=>{r.stopPropagation(),r.preventDefault(),c.targetEl.focus(),c.badgeTargetEl.scrollIntoView({behavior:"smooth",block:"center"}),ne(c.badgeTargetEl),D.forEach((a,s)=>{s===o?a.badgeEl.classList.add("active-badge"):a.badgeEl.classList.remove("active-badge")});try{chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:o,fieldId:c.id||"",fieldName:c.name||"",label:c.label}).catch(()=>{})}catch{}}),A.appendChild(t),D.push({badgeEl:t,targetEl:c.targetEl,badgeTargetEl:c.badgeTargetEl,index:o})}),window.addEventListener("scroll",pe,{passive:!0}),window.addEventListener("resize",pe,{passive:!0}),k.action(`🔢 Rendered numbered badges for ${e.length} interactive fields.`)}function ge(){D.forEach(({badgeEl:e})=>e.remove()),D=[],window.removeEventListener("scroll",pe),window.removeEventListener("resize",pe)}const R=document.createElement("div");R.className="savvy-spotlight",R.style.display="none",R.innerHTML='<div class="savvy-spotlight-beacon">O</div>',A.appendChild(R);const j=document.createElement("div");j.className="savvy-ghost-cursor",j.innerHTML=`
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
      <path d="M4 3L11 20L14 13L21 10L4 3Z" fill="#2563EB" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <div class="savvy-ghost-pulse"></div>
    <div class="savvy-ghost-label">
      <span>✨</span> Owly
    </div>
  `,A.appendChild(j);let he={x:window.innerWidth*.7,y:window.innerHeight*.3};window.addEventListener("mousemove",e=>{he={x:e.clientX,y:e.clientY}},{passive:!0});let fe=null;function ye(e){fe&&clearTimeout(fe),e.scrollIntoView({behavior:"smooth",block:"center"}),setTimeout(()=>{const n=e.getBoundingClientRect(),i=n.left+Math.min(Math.max(n.width*.5,12),n.width-8),c=n.top+Math.min(Math.max(n.height*.5,12),n.height-8);j.style.transition="none",j.style.transform=`translate(${he.x}px, ${he.y}px)`,j.classList.remove("clicking");const o=j.querySelector(".savvy-ghost-pulse");o&&o.classList.remove("active-pulse"),j.classList.add("visible"),requestAnimationFrame(()=>{j.style.transition="transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease",j.style.transform=`translate(${i}px, ${c}px)`,fe=setTimeout(()=>{j.classList.add("clicking"),o&&o.classList.add("active-pulse"),ne(e),fe=setTimeout(()=>{j.classList.remove("visible"),j.classList.remove("clicking"),o&&o.classList.remove("active-pulse")},1800)},850)})},150)}let te=null;function Ce(){R&&(R.style.display="none"),te&&(clearTimeout(te),te=null)}function ne(e){const n=e.getBoundingClientRect(),i=window.scrollY||document.documentElement.scrollTop,c=window.scrollX||document.documentElement.scrollLeft;R.style.display="block",R.style.top=`${n.top+i-4}px`,R.style.left=`${n.left+c-4}px`,R.style.width=`${n.width+8}px`,R.style.height=`${n.height+8}px`,te&&clearTimeout(te),te=setTimeout(()=>{R.style.display="none"},4e3)}const ee=document.createElement("div");ee.className="savvy-reading-guide",A.appendChild(ee),window.addEventListener("mousemove",e=>{ee.style.display==="block"&&(ee.style.top=`${e.clientY-24}px`)}),document.addEventListener("focusin",e=>{var i;const n=e.target;if(n&&(n.tagName==="INPUT"||n.tagName==="SELECT"||n.tagName==="TEXTAREA"||n.tagName==="BUTTON")){const c=G(n);k.perception(`🎯 Field focused: '${n.id||n.getAttribute("name")||n.tagName.toLowerCase()}' (${c})`,{fieldId:n.id||"",tagName:n.tagName,inputType:n.type||"text",hasValue:!!n.value});try{if(typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.sendMessage)&&(chrome.runtime.sendMessage({type:"FIELD_FOCUSED",fieldId:n.id||"",fieldName:n.getAttribute("name")||"",label:c,tagName:n.tagName,inputType:n.type||"text",value:n.value||""}).catch(()=>{}),D.length>0)){const o=D.findIndex(d=>d.targetEl===n||d.badgeTargetEl===n);o!==-1&&(D.forEach((d,u)=>{u===o?d.badgeEl.classList.add("active-badge"):d.badgeEl.classList.remove("active-badge")}),chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:o,fieldId:n.id||"",fieldName:n.getAttribute("name")||"",label:c}).catch(()=>{}))}}catch{}}}),document.addEventListener("focusout",()=>{Ce()});let Se=null,Te="";function He(){return Array.from(document.querySelectorAll("input, select, textarea")).filter(i=>i.type!=="hidden"&&i.type!=="submit"&&i.offsetParent!==null).map(i=>{const c="placeholder"in i?i.placeholder:"";return`${i.name||i.id||c}:${i.type||i.tagName.toLowerCase()}`}).join("|")}function be(){clearTimeout(Se),Se=setTimeout(()=>{const e=He();if(e!==Te){Te=e;const n=e?e.split("|").length:0;k.perception(`🕵️ Dynamic DOM Mutation detected (${n} visible fields)`,{fieldCount:n,signature:e.substring(0,80)+(e.length>80?"...":"")}),chrome.runtime.sendMessage({type:"FORM_DOM_MUTATED",signature:e,fieldCount:n}).catch(()=>{})}},400)}const Ae=new MutationObserver(e=>{e.some(i=>N?i.target!==N&&!N.contains(i.target):!0)&&be()});window.__SAVVY_OBSERVER__=Ae,Ae.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["hidden","disabled","aria-hidden","style","class"]}),window.addEventListener("popstate",be),window.addEventListener("hashchange",be);const je={register:["sign up","signup","register","create account","join","apply","daftar","registrasi","buat akun"],"sign up":["register","signup","create account","join","daftar","buat akun"],signup:["sign up","register","create account","join","daftar"],"sign in":["login","log in","signin","enter","masuk"],login:["log in","sign in","signin","enter","masuk"],upload:["attach","browse","choose file","select file","add file","unggah","pilih berkas"],attach:["upload","browse","choose file","select file","add document","unggah"],download:["download","save as","export","get file","unduh","ambil file","download now","unduh ekstensi"],requirements:["eligibility","criteria","terms","qualifications","prerequisites","syarat","persyaratan"],eligibility:["requirements","criteria","terms","qualifications","syarat"],help:["support","faq","guide","contact","documentation","bantuan"],payment:["fee","cost","checkout","pay","billing","biaya","tarif"],submit:["send","apply","finish","complete","kirim","ajukan"],next:["continue","proceed","forward","lanjut","lanjutkan","selanjutnya","berikutnya","step"],continue:["next","proceed","forward","lanjut","lanjutkan","selanjutnya","berikutnya"],proceed:["next","continue","lanjut","lanjutkan","selanjutnya"],back:["previous","prev","kembali","sebelumnya"],previous:["back","prev","kembali","sebelumnya"],cancel:["abort","close","dismiss","reset","batal"],"bikin akun":["sign up","signup","register","daftar","registrasi","buat akun","create account","join"],"buat akun":["sign up","signup","register","daftar","registrasi","create account","join"],daftar:["sign up","signup","register","registrasi","buat akun","apply","pendaftaran"],masuk:["login","log in","sign in","signin","masuk"],keluar:["logout","log out","sign out","keluar"],unggah:["upload","unggah","pilih berkas","pilih file","choose file","browse"],unduh:["download","unduh","unduh berkas","ambil file","download now"],syarat:["persyaratan","kriteria","ketentuan","eligibility","terms","requirement"],persyaratan:["syarat","kriteria","ketentuan","eligibility","terms","requirement"],bantuan:["help","bantuan","faq","panduan","hubungi kami","contact","support"],biaya:["tarif","harga","biaya","fee","cost","pembayaran","payment"],kirim:["submit","kirim","send","ajukan","selesai"],lanjut:["next","continue","proceed","lanjutkan","selanjutnya","berikutnya","step","forward"],lanjutkan:["next","continue","proceed","lanjut","selanjutnya","berikutnya"],selanjutnya:["next","continue","proceed","lanjut","lanjutkan","berikutnya"],berikutnya:["next","continue","proceed","lanjut","selanjutnya"],kembali:["back","previous","prev","sebelumnya"],sebelumnya:["back","previous","prev","kembali"],simpan:["save","simpan","submit","draf","draft"],foto:["photo","pasfoto","picture","image","avatar"],photo:["foto","pasfoto","picture","image","avatar"],batal:["cancel","batal","reset"]};function Re(e){var T,$;const n=e.toLowerCase().trim();if(!n)return{success:!1};const i=n.replace(/\b(the|a|an|please|pls|can you|could you|where is|where|which|find|show me|show|look for|tombol|button|bagian|seksi|kolom|field|link|halaman|menu|tolong|dong|mana|di mana|dimana|tunjukkan|tunjuk|lihat|cari)\b/gi,"").replace(/[^\w\s-]/g,"").replace(/\s+/g," ").trim(),c=i.length>=2?i:n,d=Array.from(document.querySelectorAll("button, a, input, select, textarea, [role='button'], [role='link'], [role='tab'], h1, h2, h3, h4, h5, h6, section, [id], label, dt, th")),u=[];for(const g of d){if(g.id==="savvy-root"||g.closest("#savvy-root"))continue;const x=g.getBoundingClientRect();if(x.width<=4||x.height<=4)continue;const p=window.getComputedStyle(g);p.visibility==="hidden"||p.display==="none"||p.opacity==="0"||u.push(g)}const t=g=>{var Y;const x=g.getAttribute("aria-label")||"",p=g.placeholder||"",b=((Y=g.textContent)==null?void 0:Y.trim())||"",C=g.getAttribute("title")||"",_=g.value||"",M=g.getAttribute("href")||"",w=g.id||"",z=g.getAttribute("name")||"";return`${b} ${x} ${p} ${C} ${_} ${M} ${w} ${z}`.toLowerCase().replace(/\s+/g," ").trim()};let r=null,a=0;for(const g of u){const x=t(g);if(!x)continue;const p=/^(button|a|input|select|textarea)$/i.test(g.tagName)||g.getAttribute("role")==="button"||g.getAttribute("role")==="link";let b=0;if(x===c||x===n)b=p?100:85;else if(x.includes(c)||c.length>=3&&c.includes(x))b=p?85:70;else{const C=c.split(/\s+/).filter(w=>w.length>=3),_=x.split(/\s+/).filter(w=>w.length>=3),M=C.filter(w=>_.some(z=>z===w||z.includes(w)||w.includes(z))).length;M>0&&C.length>0&&(b=p?75+M/C.length*15:55)}b>a&&(a=b,r=g)}if(r&&a>=65)return ye(r),k.action(`🎯 [Show Me Level 1] Found exact/substring match for "${e}" -> <${r.tagName.toLowerCase()}>`,{score:a}),{success:!0,level:1,matchedText:((T=r.textContent)==null?void 0:T.trim().slice(0,50))||r.getAttribute("aria-label")||r.tagName,tag:r.tagName.toLowerCase()};const s=[c,...c.split(/\s+/)].filter(g=>g.length>=3);for(const g of s)for(const[x,p]of Object.entries(je))if(g===x||g.includes(x)||x.includes(g)){const b=[x,...p];for(const C of b)for(const _ of u){const M=t(_);if(M===C||M.includes(C)||C.length>=3&&C.includes(M))return ye(_),k.action(`⚡ [Show Me Level 2] Found synonym match ("${x}" -> "${C}") for "${e}" -> <${_.tagName.toLowerCase()}>`),{success:!0,level:2,matchedText:(($=_.textContent)==null?void 0:$.trim().slice(0,50))||C,tag:_.tagName.toLowerCase()}}}const l=u.filter(g=>{const x=g.tagName.toLowerCase();return x==="button"||x==="a"||x==="input"||x==="select"||x==="textarea"||g.getAttribute("role")==="button"||g.getAttribute("role")==="link"}),f=(l.length>=5?l:u).filter(g=>{var M;const x=((M=g.textContent)==null?void 0:M.trim())||"",p=g.getAttribute("aria-label")||g.getAttribute("title")||"",b=g.placeholder||"",C=g.getAttribute("href")||"",_=g.id||"";return x.length>0||p.length>0||b.length>0||C.length>0||_.length>0}).slice(0,60);return window.__SAVVY_SHOW_ME_CANDIDATES__=f,{success:!1,candidates:f.map((g,x)=>{var p;return{domIndex:x,tag:g.tagName.toLowerCase(),text:(g.textContent||"").trim().replace(/\s+/g," ").slice(0,60),aria:g.getAttribute("aria-label")||g.getAttribute("title")||"",placeholder:g.placeholder||"",href:((p=g.getAttribute("href"))==null?void 0:p.slice(0,50))||void 0,id:g.id?g.id.slice(0,30):void 0}})}}chrome.runtime.onMessage.addListener((e,n,i)=>{var c,o,d,u;if(e.type==="FIND_AND_HIGHLIGHT_ELEMENT"){const t=Re(e.query||"");i(t);return}if(e.type==="HIGHLIGHT_DOM_ELEMENT_BY_INDEX"){const t=e.domIndex,r=window.__SAVVY_SHOW_ME_CANDIDATES__;if(r&&r[t]){const a=r[t];ye(a),i({success:!0,text:(c=a.textContent)==null?void 0:c.trim().slice(0,50)});return}i({success:!1,reason:"Element index not found in cache"});return}if(e.type==="INJECT_VALUE"){const{fieldId:t,fieldName:r,fieldIndex:a,value:s}=e;let l=null;if(typeof a=="number"&&D[a]&&(l=D[a].targetEl),!l&&t&&(l=document.getElementById(t)),!l&&r&&(l=document.querySelector(`[name="${r}"]`)),l&&"value"in l){const y=l;let f=s;const h=`${y.name||""} ${y.id||""} ${G(y)||""}`.toLowerCase();(y.type==="date"||h.includes("tanggal_lahir")||h.includes("date of birth")||h.includes("birth date")||h.includes("dob")||h.includes("tgl_lahir"))&&(f=De(s,y)),y.value=f,l.dispatchEvent(new Event("input",{bubbles:!0})),l.dispatchEvent(new Event("change",{bubbles:!0})),l.dispatchEvent(new Event("blur",{bubbles:!0})),k.action(`⚡ Injected value into field '${t||r||a}'`,{targetTag:l.tagName,formattedValue:f}),i({success:!0});return}i({success:!1,reason:"Element not found"})}if(e.type==="SET_A11Y_FEATURE"){const{feature:t,enabled:r,value:a,level:s}=e;ve(t,r,a),k.action(`👓 A11y feature '${t}' set to: ${a||(r?"ON":"OFF")}`),i({success:!0,feature:t,enabled:r,value:a})}if(e.type==="APPLY_ALL_A11Y_SETTINGS"){const t=e.settings||{};Object.entries(t).forEach(([r,a])=>{a&&ve(r,a.enabled,a.value,a.level)}),i({success:!0,count:Object.keys(t).length})}if(e.type==="CLEAR_ALL_A11Y"){ze(),i({success:!0});return}if(e.type==="SCAN_PAGE_FIELDS"||e.type==="QUERY_PAGE_FIELDS"){const r=le().map(s=>({id:s.id,name:s.name,label:s.label,placeholder:s.placeholder,required:s.required,type:s.type,section:s.section||""})),a={url:window.location.href,domain:window.location.hostname,title:document.title,description:((o=document.querySelector('meta[name="description"]'))==null?void 0:o.getAttribute("content"))||"",keywords:((u=(d=document.querySelector('meta[name="keywords"]'))==null?void 0:d.getAttribute("content"))==null?void 0:u.split(",").map(s=>s.trim()))||[]};k.perception(`🔍 Scanning DOM: Discovered ${r.length} synchronized form fields on ${a.domain}`,{count:r.length,title:a.title,fieldKeys:r.map(s=>s.name||s.id||s.label).slice(0,8)}),i({success:!0,fields:r,count:r.length,meta:a})}if(e.type==="EXTRACT_FORM_AUDIT_DATA"){const t=qe();k.action(`🔍 EXTRACT_FORM_AUDIT_DATA: Scraped ${t.fields.length} active inputs and ${t.pageUploadContext.attachedFilesMetadata.length} attached files for audit.`),i({success:!0,...t});return}if(e.type==="HIGHLIGHT_AUDIT_FIELD"){let t=null,r=null;if(e.fieldId&&(t=document.getElementById(e.fieldId)),!t&&e.fieldName&&(t=document.querySelector(`[name="${e.fieldName}"]`)),!t&&typeof e.fieldIndex=="number"){const s=le();s[e.fieldIndex]&&(t=s[e.fieldIndex].targetEl,r=s[e.fieldIndex].badgeTargetEl)}if(!r&&t instanceof HTMLInputElement&&t.type==="radio"){const s=Ee(t);s.badgeAnchor&&(r=s.badgeAnchor)}const a=r||t;if(a){t==null||t.focus(),a.scrollIntoView({behavior:"smooth",block:"center"}),ne(a),k.action(`🎯 Audit Spotlight highlighted field '${e.fieldLabel||e.fieldName||e.fieldId}'`),i({success:!0});return}i({success:!1,reason:"Field not found"});return}if(e.type==="APPLY_FIELD_VALUE"){let t=null;if(e.fieldId&&(t=document.getElementById(e.fieldId)),!t&&e.fieldName&&(t=document.querySelector(`[name="${e.fieldName}"]`)),t&&typeof e.value=="string"){t.value=e.value,t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.focus(),ne(t),k.action(`⚡ Applied Vault value to field '${e.fieldName||e.fieldId}': "${e.value}"`),i({success:!0});return}i({success:!1,reason:"Field or value invalid"});return}if(e.type==="START_SCAN_ANIMATION"){ue(),i({success:!0});return}if(e.type==="STOP_SCAN_ANIMATION"){Q(),i({success:!0});return}if(e.type==="SHOW_FIELD_NUMBERS"){Pe(),i({success:!0,count:D.length});return}if(e.type==="HIDE_FIELD_NUMBERS"){ge(),i({success:!0});return}if(e.type==="NAVIGATE_TO_FIELD"){let t=null,r=null;const a=typeof e.fieldIndex=="number"?e.fieldIndex:-1;if(a>=0&&D[a]&&(t=D[a].targetEl,r=D[a].badgeTargetEl,D.forEach((l,y)=>{y===a?l.badgeEl.classList.add("active-badge"):l.badgeEl.classList.remove("active-badge")})),!t&&e.fieldId&&(t=document.getElementById(e.fieldId)),!t&&e.fieldName&&(t=document.querySelector(`[name="${e.fieldName}"]`)),!t&&a>=0){const l=le();l[a]&&(t=l[a].targetEl,r=l[a].badgeTargetEl)}const s=r||t;if(s){t==null||t.focus(),s.scrollIntoView({behavior:"smooth",block:"center"}),ne(s),i({success:!0,fieldIndex:a});return}i({success:!1,reason:"Field not found"});return}if(e.type==="START_SNIP_SELECTION"&&(k.action("✂️ Starting Visual Snip selection mode on screen for 'Explain This'"),Ve(),i({success:!0,mode:"active"})),e.type==="SHOW_FIELD_SPOTLIGHT"){let r=document.activeElement;if((!r||r.tagName==="BODY")&&(r=document.querySelector("input:not([type=hidden]), textarea, select")),r){r.focus(),r.scrollIntoView({behavior:"smooth",block:"center"}),ne(r),k.action(`💡 Spotlight Beacon navigated to field '${r.id||r.getAttribute("name")||"input"}'`),i({success:!0});return}i({success:!1,reason:"No target field found"})}if(e.type==="BATCH_AUTOFILL"){const t=e.payload||{},r=Array.isArray(e.items)?e.items:Array.isArray(t.items)?t.items:[],a=Array.from(document.querySelectorAll("input, textarea, select"));window.__SAVVY_UNDO_BACKUP__=a.map(l=>({el:l,prevVal:l.value}));let s=0;return a.forEach(l=>{if(l.type==="hidden"||l.type==="submit"||l.type==="button")return;const f=(G(l)||l.name||l.id||l.placeholder||"").toLowerCase().trim();let h="";const T=l.type==="email"||f.includes("email")||f.includes("surel")||f.includes("e-mail")||f.includes("mail"),$=!T&&(f.includes("alamat")||f.includes("address")||f.includes("domisili")||f.includes("tinggal")||f.includes("residence")),g=f.includes("mother")||f.includes("ibu"),x=l.type==="date"||f.includes("tanggal_lahir")||f.includes("tgl_lahir")||f.includes("dob")||f.includes("birth date")||f.includes("date of birth")||f.includes("birthdate")||f.includes("birth")&&(f.includes("date")||f.includes("day"))||f.includes("lahir")&&(f.includes("tgl")||f.includes("tanggal"));if(r.length>0)for(const p of r){const b=p.name.toLowerCase().trim(),C=p.id||"";if(g&&(b.includes("nama lengkap")||b==="nama"||b==="full name")||!g&&b.includes("ibu")||T&&(C==="alamat"||b.includes("alamat ktp")||b.includes("alamat tinggal")||b==="alamat"||b==="address"||b.includes("domisili"))||$&&(C==="email"||b.includes("email")||b.includes("surel"))||x&&C!=="tanggal_lahir"&&!b.includes("lahir")&&!b.includes("birth"))continue;let _=f.length>1&&b.length>1&&(f===b||f.includes(b)||b.includes(f));if(!_&&Array.isArray(p.aliases)&&(_=p.aliases.some(M=>{const w=M.toLowerCase().trim();return T&&(w==="address"||w.includes("alamat")||w.includes("domisili"))?!1:w.length>1&&(f===w||f.includes(w)||w.includes(f))})),!_&&T&&(C==="email"||b.includes("email")||b.includes("surel"))&&(_=!0),_&&p.value){h=p.value;break}}h||(f.includes("nik")||f.includes("ktp")||f.includes("national id")?h=t.nik||t.NIK||"":g?h=t["Nama Ibu Kandung"]||t.nama_ibu||"":f.includes("nama")||f.includes("name")||f.includes("fullname")?h=t.nama||t["Nama Lengkap"]||"":f.includes("place")||f.includes("tempat")||f.includes("pob")?h=t.tempat_lahir||t["Tempat Lahir"]||"":x?h=t.tanggal_lahir||t["Tanggal Lahir"]||"":T?h=t.email||t.Email||t["Alamat Email"]||t.Surel||"":$?h=t.alamat||t["Alamat KTP"]||t.Alamat||"":(l.type==="tel"||f.includes("hp")||f.includes("phone")||f.includes("telp")||f.includes("whatsapp"))&&(h=t.no_hp||t["No. Handphone"]||"")),h&&(x&&(h=De(h,l)),l.value=h,l.dispatchEvent(new Event("input",{bubbles:!0})),l.dispatchEvent(new Event("change",{bubbles:!0})),s++)}),k.action(`⚡ Batch Autofill executed: ${s} fields populated safely with reversibility snapshot.`,{injectedCount:s,keys:Object.keys(t)}),i({success:!0,count:s}),!0}if(e.type==="UNDO_AUTOFILL"){const t=window.__SAVVY_UNDO_BACKUP__;if(t&&Array.isArray(t)){t.forEach(({el:a,prevVal:s})=>{a&&(a.value=s,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})))});const r=t.length;return delete window.__SAVVY_UNDO_BACKUP__,k.action(`↩️ Undo Autofill executed: Restored previous values across ${r} fields.`),i({success:!0,undone:!0}),!0}i({success:!1,reason:"No backup state found"})}return!0});function Ve(){const e=A.querySelector(".savvy-lightshot-container");e&&e.remove(),k.action("✂️ Activating Lightshot-style visual crop mode on screen.");const n=document.createElement("div");n.className="savvy-lightshot-container",n.style.cssText=`
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483647;
      cursor: crosshair;
      user-select: none;
      -webkit-user-select: none;
      background: rgba(15, 23, 42, 0.45);
      transition: background 0.15s ease-out;
      pointer-events: auto;
    `;const i=document.createElement("div");i.style.cssText=`
      position: fixed;
      top: 18px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(15, 23, 42, 0.92);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #FFFFFF;
      padding: 8px 18px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 2147483647;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const c=B();i.innerHTML=`
      <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; color: #60A5FA;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>
        </svg>
        <span>${c.snipTitle}</span>
      </div>
      <div style="width: 1px; height: 14px; background: rgba(255, 255, 255, 0.2);"></div>
      <span style="color: #E2E8F0; font-size: 12px;">${c.snipInstruction}</span>
    `,n.appendChild(i);const o=document.createElement("div");o.style.cssText=`
      position: fixed;
      display: none;
      border: 2px solid #398CF5;
      box-shadow: 0 0 0 99999px rgba(15, 23, 42, 0.65);
      background: transparent;
      pointer-events: auto;
      z-index: 2147483647;
      box-sizing: border-box;
    `;const d=document.createElement("div");d.style.cssText=`
      position: absolute;
      top: -26px;
      left: -2px;
      background: #0F172A;
      color: #93C5FD;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 4px;
      pointer-events: none;
      white-space: nowrap;
      font-family: monospace, system-ui, sans-serif;
      border: 1px solid rgba(59, 130, 246, 0.4);
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    `,o.appendChild(d),["nw","n","ne","e","se","s","sw","w"].forEach(m=>{const v=document.createElement("div");v.dataset.handle=m;let E="default";m==="nw"||m==="se"?E="nwse-resize":m==="ne"||m==="sw"?E="nesw-resize":m==="n"||m==="s"?E="ns-resize":(m==="e"||m==="w")&&(E="ew-resize"),v.style.cssText=`
        position: absolute;
        width: 8px;
        height: 8px;
        background: #FFFFFF;
        border: 2px solid #398CF5;
        border-radius: 1px;
        z-index: 10;
        cursor: ${E};
        box-sizing: border-box;
      `,m.includes("n")&&(v.style.top="-5px"),m.includes("s")&&(v.style.bottom="-5px"),m.includes("w")&&(v.style.left="-5px"),m.includes("e")&&(v.style.right="-5px"),(m==="n"||m==="s")&&(v.style.left="50%",v.style.transform="translateX(-50%)"),(m==="w"||m==="e")&&(v.style.top="50%",v.style.transform="translateY(-50%)"),o.appendChild(v)});const t=document.createElement("div");t.style.cssText=`
      position: absolute;
      display: none;
      align-items: center;
      gap: 6px;
      padding: 5px 6px;
      background: #0F172A;
      border-radius: 8px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6);
      z-index: 25;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const r=document.createElement("button");r.style.cssText=`
      background: linear-gradient(135deg, #398CF5 0%, #7045ED 100%);
      color: #FFFFFF;
      font-weight: 600;
      font-size: 12px;
      padding: 6px 14px;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      white-space: nowrap;
      transition: all 0.15s ease;
      box-shadow: 0 2px 8px rgba(57, 140, 245, 0.35);
    `,r.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
      </svg>
      <span>${c.snipExplainBtn}</span>
    `;const a=document.createElement("button");a.style.cssText=`
      background: #1E293B;
      color: #CBD5E1;
      font-weight: 500;
      font-size: 12px;
      padding: 6px 11px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      white-space: nowrap;
      transition: all 0.15s ease;
    `,a.innerHTML=`
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
      <span>${c.snipCopyBtn}</span>
    `;const s=document.createElement("button");s.style.cssText=`
      background: #1E293B;
      color: #EF4444;
      font-weight: 700;
      font-size: 13px;
      padding: 6px 10px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      transition: all 0.15s ease;
    `,s.innerHTML="✕",s.title=c.snipCancelTitle,t.appendChild(r),t.appendChild(a),t.appendChild(s),o.appendChild(t),n.appendChild(o),A.appendChild(n);let l=!1,y=!1,f=!1,h="",T=0,$=0,g=0,x=0;const p={left:0,top:0,width:0,height:0};function b(){const m=Math.max(0,p.left),v=Math.max(0,p.top),E=Math.max(0,p.width),q=Math.max(0,p.height);o.style.left=`${m}px`,o.style.top=`${v}px`,o.style.width=`${E}px`,o.style.height=`${q}px`,d.textContent=`${Math.round(E)} × ${Math.round(q)} px`,v+q+50>window.innerHeight?t.style.bottom="8px":t.style.bottom="-48px",m+E<280?(t.style.right="auto",t.style.left="0px"):(t.style.left="auto",t.style.right="0px")}function C(){n.remove(),document.removeEventListener("keydown",_),window.removeEventListener("mousemove",z),window.removeEventListener("mouseup",Y)}function _(m){m.key==="Escape"?C():m.key==="Enter"&&o.style.display!=="none"&&p.width>20&&p.height>20&&w()}document.addEventListener("keydown",_);function M(){var de;const m=[],v=p.left,E=p.top,q=p.left+p.width,ce=p.top+p.height,me=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(P){if(!P.nodeValue||!P.nodeValue.trim())return NodeFilter.FILTER_REJECT;const V=P.parentElement;if(!V||V.closest("#savvy-root"))return NodeFilter.FILTER_REJECT;const Z=window.getComputedStyle(V);return Z.display==="none"||Z.visibility==="hidden"||Z.opacity==="0"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let oe;for(;oe=me.nextNode();)try{const P=document.createRange();P.selectNode(oe);const V=P.getClientRects();for(let Z=0;Z<V.length;Z++){const U=V[Z];if(!(U.right<v||U.left>q||U.bottom<E||U.top>ce)){const se=(de=oe.nodeValue)==null?void 0:de.trim();se&&!m.includes(se)&&m.push(se);break}}}catch{}document.querySelectorAll("input, textarea, select").forEach(P=>{const V=P.getBoundingClientRect();if(!(V.right<v||V.left>q||V.bottom<E||V.top>ce)){const U=P,we=U.value||U.placeholder||"",se=U.getAttribute("aria-label")||U.name||U.id||"";(we||se)&&m.push(`[Field ${se}: ${we}]`)}});let ae=m.join(" ").trim();return ae=ae.replace(/\b[1-9][0-9]{15}\b/g,"[REDACTED_NIK]"),ae}function w(){var E,q,ce,me,oe,xe,ae,de;const m=M();k.action("⚡ Visual crop snip confirmed by user.",{rect:p,extractedLength:m.length,preview:m.slice(0,100)});const v={description:((E=document.querySelector('meta[name="description"]'))==null?void 0:E.getAttribute("content"))||((q=document.querySelector('meta[property="og:description"]'))==null?void 0:q.getAttribute("content"))||"",keywords:((ce=document.querySelector('meta[name="keywords"]'))==null?void 0:ce.getAttribute("content"))||"",ogTitle:((me=document.querySelector('meta[property="og:title"]'))==null?void 0:me.getAttribute("content"))||"",ogDescription:((oe=document.querySelector('meta[property="og:description"]'))==null?void 0:oe.getAttribute("content"))||"",ogType:((xe=document.querySelector('meta[property="og:type"]'))==null?void 0:xe.getAttribute("content"))||"",lang:document.documentElement.lang||navigator.language||"id-ID",author:((ae=document.querySelector('meta[name="author"]'))==null?void 0:ae.getAttribute("content"))||"",canonicalUrl:((de=document.querySelector('link[rel="canonical"]'))==null?void 0:de.getAttribute("href"))||window.location.href};o.style.borderColor="#10B981",o.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65), 0 0 25px rgba(16, 185, 129, 0.6)",d.textContent=B().snipCapturing,d.style.color="#34D399",r.disabled=!0,r.style.opacity="0.7",n.style.visibility="hidden",setTimeout(()=>{chrome.runtime.sendMessage({type:"CAPTURE_VISIBLE_TAB"},P=>{C(),chrome.runtime.sendMessage({type:"SNIP_EXPLAIN_RESULT",fullScreenshot:P!=null&&P.success?P.dataUrl:null,text:m,rect:{left:Math.round(p.left),top:Math.round(p.top),width:Math.round(p.width),height:Math.round(p.height),viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,devicePixelRatio:window.devicePixelRatio||1},portalUrl:window.location.href,portalDomain:window.location.hostname,pageTitle:document.title,meta:v})})},60)}r.addEventListener("click",m=>{m.stopPropagation(),w()}),a.addEventListener("click",m=>{m.stopPropagation();const v=M();if(v){navigator.clipboard.writeText(v);const E=B();a.innerHTML=`✓ ${E.snipCopied}`,setTimeout(()=>{a.innerHTML=`
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            <span>${E.snipCopyBtn}</span>
          `},1500)}}),s.addEventListener("click",m=>{m.stopPropagation(),C()}),n.addEventListener("mousedown",m=>{var E;const v=m.target;if(!t.contains(v)){if((E=v.dataset)!=null&&E.handle){m.preventDefault(),m.stopPropagation(),f=!0,h=v.dataset.handle,T=m.clientX,$=m.clientY,t.style.display="none";return}if(o.contains(v)&&v!==n){m.preventDefault(),m.stopPropagation(),y=!0,g=m.clientX-p.left,x=m.clientY-p.top,o.style.cursor="move",t.style.display="none";return}m.preventDefault(),l=!0,T=m.clientX,$=m.clientY,p.left=T,p.top=$,p.width=0,p.height=0,n.style.background="transparent",o.style.display="block",o.style.borderColor="#398CF5",o.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65)",o.style.cursor="crosshair",t.style.display="none",b()}});function z(m){if(l){const v=m.clientX,E=m.clientY;p.left=Math.min(T,v),p.top=Math.min($,E),p.width=Math.abs(v-T),p.height=Math.abs(E-$),b()}else if(y)p.left=Math.max(0,Math.min(window.innerWidth-p.width,m.clientX-g)),p.top=Math.max(0,Math.min(window.innerHeight-p.height,m.clientY-x)),b();else if(f){const v=m.clientX,E=m.clientY;if(h.includes("e")&&(p.width=Math.max(20,v-p.left)),h.includes("s")&&(p.height=Math.max(20,E-p.top)),h.includes("w")){const q=p.left+p.width;p.left=Math.min(q-20,v),p.width=q-p.left}if(h.includes("n")){const q=p.top+p.height;p.top=Math.min(q-20,E),p.height=q-p.top}b()}}window.addEventListener("mousemove",z);function Y(m){if(l){if(l=!1,p.width<15&&p.height<15){n.style.display="none";const v=document.elementFromPoint(m.clientX,m.clientY);if(n.style.display="block",v&&!v.closest("#savvy-root")){const E=v.getBoundingClientRect();p.left=Math.max(0,E.left-4),p.top=Math.max(0,E.top-4),p.width=E.width+8,p.height=E.height+8}else p.left=Math.max(10,m.clientX-160),p.top=Math.max(10,m.clientY-60),p.width=320,p.height=120;b()}o.style.cursor="move",t.style.display="flex"}y&&(y=!1,o.style.cursor="move",t.style.display="flex"),f&&(f=!1,t.style.display="flex")}window.addEventListener("mouseup",Y)}function ze(){var i,c,o,d;const e=document.documentElement,n=document.body;Q(),ge(),Ce(),ee&&(ee.style.display="none"),e.style.filter="",e.style.fontSize="",n.style.letterSpacing="",n.style.wordSpacing="",n.style.lineHeight="",n.style.textAlign="",n.style.fontFamily="",(i=document.getElementById("savvy-pause-anim"))==null||i.remove(),(c=document.getElementById("savvy-hide-img"))==null||c.remove(),(o=document.getElementById("savvy-highlight-links"))==null||o.remove(),(d=document.getElementById("savvy-big-cursor"))==null||d.remove(),Me();try{window.speechSynthesis&&window.speechSynthesis.cancel()}catch{}try{const u=A.querySelector(".savvy-lightshot-container");u&&u.remove()}catch{}k.action("🧹 All accessibility features and spotlights cleared.")}const _e={en:"Please click or point to the section you want read aloud.",id:"Silakan klik atau arahkan pada bagian yang ingin dibacakan.",ms:"Sila klik atau halakan pada bahagian yang ingin dibacakan.",es:"Por favor, haga clic o señale la sección que desea escuchar.",fr:"Veuillez cliquer ou pointer sur la section que vous souhaitez entendre.",de:"Bitte klicken oder zeigen Sie auf den Bereich, der vorgelesen werden soll.",zh:"请点击或指向您想要朗读的内容。",ja:"読み上げたい部分をクリックするか指定してください。",ko:"소리내어 읽을 부분을 클릭하거나 가리켜 주세요.",ar:"يرجى النقر أو الإشارة إلى الجزء الذي ترغب في قراءته بصوت عالٍ.",pt:"Por favor, clique ou aponte para a seção que deseja ouvir.",ru:"Пожалуйста, нажмите или наведите курсор на раздел, который хотите озвучить.",hi:"कृपया उस भाग पर क्लिक करें या इंगित करें जिसे आप सुनना चाहते हैं।",vi:"Vui lòng nhấp hoặc trỏ vào phần bạn muốn đọc to.",th:"โปรดคลิกหรือชี้ไปที่ส่วนที่คุณต้องการให้อ่านออกเสียง"},Le={en:"Click any section or text to read aloud",id:"Klik teks atau bagian mana saja untuk dibacakan",ms:"Klik mana-mana bahagian atau teks untuk dibacakan",es:"Haga clic en cualquier sección para escucharla",fr:"Cliquez sur une section pour la lire à haute voix",de:"Klicken Sie auf einen Bereich, um ihn vorzulesen",zh:"点击任意内容以朗读",ja:"読み上げたい部分をクリックしてください",ko:"소리내어 읽을 부분을 클릭하세요",ar:"انقر فوق أي جزء لقراءته بصوت عالٍ",pt:"Clique em qualquer seção para ouvir",ru:"Нажмите на любой раздел для озвучивания",hi:"सुनने के लिए किसी भी भाग पर क्लिक करें",vi:"Nhấp vào bất kỳ phần nào để đọc to",th:"คลิกส่วนใดก็ได้เพื่อให้อ่านออกเสียง"};let ie=!1,X=null,K=null;function Fe(e,n,i){if(typeof window>"u"||!("speechSynthesis"in window))return;try{window.speechSynthesis.cancel()}catch{}const c=e.trim();if(!c){i&&i();return}const o=new SpeechSynthesisUtterance(c),u=H[n||I||"en"]||document.documentElement.lang||"en-US";o.lang=u;const r=(()=>{const a=window.speechSynthesis.getVoices()||[],s=u.toLowerCase().replace("_","-"),l=u.split("-")[0].toLowerCase();return a.find(y=>y.lang.toLowerCase().replace("_","-")===s)||a.find(y=>y.lang.toLowerCase().startsWith(l))})();r&&(o.voice=r),o.onend=()=>{i&&i()},o.onerror=()=>{i&&i()};try{window.speechSynthesis.speak(o)}catch(a){console.warn("[TTS Speak Error]",a),i&&i()}}function Ye(e){var c,o,d,u,t;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement){const r=e.closest("label")||document.querySelector(`label[for="${e.id}"]`),a="placeholder"in e?e.placeholder:"",s=((c=r==null?void 0:r.textContent)==null?void 0:c.trim())||e.getAttribute("aria-label")||a||"";let l="";return e instanceof HTMLSelectElement?l=((o=e.options[e.selectedIndex])==null?void 0:o.text)||e.value:l=e.value||a||"",s&&l?`${s}: ${l}`:s||l||(I==="id"?"Kolom isian formulir":"Form input field")}if(e instanceof HTMLImageElement)return e.alt||e.title||e.getAttribute("aria-label")||(I==="id"?"Gambar ilustrasi":"Image illustration");const n=e.tagName.toUpperCase(),i=((d=e.innerText)==null?void 0:d.trim())||((u=e.textContent)==null?void 0:u.trim())||"";if(["DIV","SECTION","ARTICLE","MAIN","ASIDE","BODY","FORM","TABLE"].includes(n)&&i.length>400){const r=e.querySelector("h1, h2, h3, h4, h5, h6, p, li, td, th, span");return r&&((t=r.textContent)!=null&&t.trim())&&(r.innerText||r.textContent)||i.slice(0,300)}return i.slice(0,600)}function Ie(e){if(!ie)return;const n=e.target;if(!n||n.id==="savvy-root"||n.closest("#savvy-root")||n.id==="savvy-tts-banner")return;e.preventDefault(),e.stopPropagation(),K&&(K.classList.remove("savvy-tts-reading"),K=null);const i=Ye(n);i&&(n.classList.add("savvy-tts-reading"),K=n,k.action(`🔊 [TTS Read Section] '${n.tagName}': "${i.slice(0,60)}..."`),Fe(i,I,()=>{K===n&&(n.classList.remove("savvy-tts-reading"),K=null)}))}function Ne(e){if(!ie)return;const n=e.target;!n||n.id==="savvy-root"||n.closest("#savvy-root")||n.id==="savvy-tts-banner"||(X&&X!==n&&X.classList.remove("savvy-tts-hover"),n.classList.add("savvy-tts-hover"),X=n)}function $e(e){if(!ie)return;const n=e.target;n&&n.classList.contains("savvy-tts-hover")&&n.classList.remove("savvy-tts-hover"),X===n&&(X=null)}function Ue(){if(ie)return;if(ie=!0,!document.getElementById("savvy-tts-styles")){const n=document.createElement("style");n.id="savvy-tts-styles",n.textContent=`
        .savvy-tts-hover {
          outline: 2px dashed #3B82F6 !important;
          outline-offset: 3px !important;
          cursor: pointer !important;
          transition: outline 0.15s ease-in-out !important;
        }
        .savvy-tts-reading {
          outline: 3px solid #2563EB !important;
          outline-offset: 3px !important;
          background-color: rgba(59, 130, 246, 0.14) !important;
          border-radius: 6px !important;
          transition: background-color 0.2s ease !important;
        }
        @keyframes savvyTtsPulse {
          0%, 100% { transform: translateX(-50%) scale(1); }
          50% { transform: translateX(-50%) scale(1.02); }
        }
      `,document.head.appendChild(n)}if(document.addEventListener("click",Ie,!0),document.addEventListener("mouseover",Ne,!0),document.addEventListener("mouseout",$e,!0),!document.getElementById("savvy-tts-banner")){const n=document.createElement("div");n.id="savvy-tts-banner",n.style.cssText="position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); z-index: 2147483640; background: #0F172A; color: #FFFFFF; padding: 9px 18px; border-radius: 9999px; font-family: system-ui, -apple-system, sans-serif; font-size: 12px; font-weight: 600; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.15); display: flex; align-items: center; gap: 8px; pointer-events: none; animation: savvyTtsPulse 2s ease-in-out infinite;",n.innerHTML=`<span>🔊</span><span>${Le[I]||Le.en}</span>`,document.body.appendChild(n)}const e=_e[I]||_e.en;k.action(`🔊 [TTS Active] Speaking prompt: "${e}"`),Fe(e,I)}function Me(){var e,n;ie=!1,document.removeEventListener("click",Ie,!0),document.removeEventListener("mouseover",Ne,!0),document.removeEventListener("mouseout",$e,!0),X&&(X.classList.remove("savvy-tts-hover"),X=null),K&&(K.classList.remove("savvy-tts-reading"),K=null),(e=document.getElementById("savvy-tts-styles"))==null||e.remove(),(n=document.getElementById("savvy-tts-banner"))==null||n.remove();try{typeof window<"u"&&"speechSynthesis"in window&&window.speechSynthesis.cancel()}catch{}}function ve(e,n,i,c){var u,t,r,a;const o=document.documentElement,d=document.body;switch(e){case"spotlight":case"reading_spotlight":ee.style.display=n&&i!=="Off"?"block":"none";break;case"contrast":case"high_contrast":!n||i==="Normal"?o.style.filter="":i==="High"?o.style.filter="contrast(180%) brightness(105%)":i==="Invert"?o.style.filter="invert(100%) hue-rotate(180deg)":i==="Monochrome"?o.style.filter="grayscale(100%) contrast(120%)":o.style.filter="contrast(180%) brightness(105%)";break;case"textSize":case"bigger_text":!n||i==="Normal"?o.style.fontSize="":i==="+25%"?o.style.fontSize="125%":i==="+50%"?o.style.fontSize="150%":i==="+75%"?o.style.fontSize="175%":i==="+100%"?o.style.fontSize="200%":o.style.fontSize="125%";break;case"textSpacing":case"text_spacing":!n||i==="Normal"?(d.style.letterSpacing="",d.style.wordSpacing=""):i!=null&&i.includes("+10%")?(d.style.letterSpacing="0.08em",d.style.wordSpacing="0.12em"):i!=null&&i.includes("+25%")?(d.style.letterSpacing="0.16em",d.style.wordSpacing="0.24em"):i!=null&&i.includes("+50%")?(d.style.letterSpacing="0.24em",d.style.wordSpacing="0.36em"):(d.style.letterSpacing="0.14em",d.style.wordSpacing="0.2em");break;case"pauseAnim":case"pause_animations":if(n&&i!=="Normal"){let s=document.getElementById("savvy-pause-anim");s||(s=document.createElement("style"),s.id="savvy-pause-anim",document.head.appendChild(s)),s.textContent="* { animation-play-state: paused !important; transition: none !important; }"}else(u=document.getElementById("savvy-pause-anim"))==null||u.remove();break;case"hideImages":case"hide_images":if(!n||i==="Normal")(t=document.getElementById("savvy-hide-img"))==null||t.remove();else{let s=document.getElementById("savvy-hide-img");s||(s=document.createElement("style"),s.id="savvy-hide-img",document.head.appendChild(s)),i==="Grayscale"?s.textContent="img, svg:not(.savvy-icon), video { filter: grayscale(100%) !important; opacity: 0.65 !important; }":s.textContent="img, svg:not(.savvy-icon), video { visibility: hidden !important; }"}break;case"links":case"highlight_links":if(!n||i==="Off")(r=document.getElementById("savvy-highlight-links"))==null||r.remove();else{let s=document.getElementById("savvy-highlight-links");s||(s=document.createElement("style"),s.id="savvy-highlight-links",document.head.appendChild(s)),i==="Underline"?s.textContent="a { text-decoration: underline 3px solid #2563EB !important; text-underline-offset: 4px !important; }":i==="High Contrast"?s.textContent="a { outline: 3px solid #2563EB !important; background-color: #EFF6FF !important; color: #1D4ED8 !important; text-decoration: underline !important; }":s.textContent="a { background-color: #FEF08A !important; color: #1E3A8A !important; text-decoration: underline !important; }"}break;case"dyslexiaFont":case"dyslexia_font":n&&i!=="Off"?d.style.fontFamily="Comic Sans MS, OpenDyslexic, sans-serif":d.style.fontFamily="";break;case"tts":case"text_to_speech":n&&i!=="Off"?Ue():Me();break;case"bigCursor":case"big_cursor":if(!n||i==="Normal")(a=document.getElementById("savvy-big-cursor"))==null||a.remove();else{let s=document.getElementById("savvy-big-cursor");if(s||(s=document.createElement("style"),s.id="savvy-big-cursor",document.head.appendChild(s)),i==="Large (White)"){const l="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='white' stroke='black' stroke-width='1.5'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${l}") 0 0, auto !important; }`}else if(i==="Highlighter"){const l="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Ccircle cx='24' cy='24' r='20' fill='rgba(254,240,138,0.65)' stroke='%23F59E0B' stroke-width='2.5'/%3E%3Ccircle cx='24' cy='24' r='3' fill='%23D97706'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${l}") 24 24, auto !important; }`}else{const l="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='black' stroke='white' stroke-width='1.5'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${l}") 0 0, auto !important; }`}}break;case"lineHeight":case"line_height":!n||i==="Normal"?d.style.lineHeight="":i==="1.5x"?d.style.lineHeight="1.5":i==="1.8x"?d.style.lineHeight="1.8":i==="2.2x"?d.style.lineHeight="2.2":d.style.lineHeight="1.8";break;case"textAlign":case"text_align":!n||i==="Normal"?d.style.textAlign="":i==="Left"?d.style.textAlign="left":i==="Center"?d.style.textAlign="center":i==="Justify"?d.style.textAlign="justify":d.style.textAlign="left";break;case"colorSat":case"color_saturation":!n||i==="Normal"?o.style.filter="":i!=null&&i.includes("High")?o.style.filter="saturate(200%)":i!=null&&i.includes("Low")?o.style.filter="saturate(40%)":i!=null&&i.includes("Monochrome")?o.style.filter="grayscale(100%)":o.style.filter="saturate(200%)";break;case"liveTooltips":case"live_tooltips":break;default:console.log("[Owly.AI Content] Toggled feature:",e,n,i)}}try{typeof chrome<"u"&&((Oe=chrome.storage)!=null&&Oe.local)&&chrome.storage.local.get(["savvy_sidepanel_open","savvy_a11y_settings"],e=>{e&&e.savvy_sidepanel_open&&e.savvy_a11y_settings&&Object.entries(e.savvy_a11y_settings).forEach(([n,i])=>{i&&i.enabled&&ve(n,i.enabled,i.value,i.level)})})}catch{}})();
