(()=>{var me,ye;if(window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__)return;window.__SAVVY_CONTENT_SCRIPT_INITIALIZED__=!0;try{document.documentElement.dataset.owlyExtension="installed",window.__OWLY_EXTENSION_INSTALLED__=!0}catch{}if(document.addEventListener("click",t=>{var u,i;const o=t.target;if((u=o==null?void 0:o.closest)==null?void 0:u.call(o,"[data-owly-action='open-sidepanel'], #owly-access-btn"))try{typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}},!0),window.addEventListener("message",t=>{var o,n,u;if(((o=t.data)==null?void 0:o.type)==="OWLY_PING"&&window.postMessage({type:"OWLY_PONG",version:"1.0.0",installed:!0},"*"),((n=t.data)==null?void 0:n.type)==="OWLY_OPEN_SIDEPANEL")try{typeof chrome<"u"&&((u=chrome.runtime)!=null&&u.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL_REQUEST"}).catch(()=>{})}catch{}}),window.__SAVVY_OBSERVER__)try{window.__SAVVY_OBSERVER__.disconnect()}catch{}const we={PERCEPTION:{bg:"#398CF5",color:"#FFFFFF",icon:"👁️"},ACTION:{bg:"#F59E0B",color:"#000000",icon:"⚡"}};function ce(t,o,n){var r;const u=new Date().toLocaleTimeString(),i=we[t]||{bg:"#398CF5",color:"#FFFFFF",icon:"🤖"},d=`background: ${i.bg}; color: ${i.color}; font-weight: bold; border-radius: 4px; padding: 2px 6px; font-size: 11px;`,f="color: #64748B; font-size: 10px; margin-left: 4px;",e="color: #0F172A; font-weight: 600; font-size: 12px;";n!==void 0?console.log(`%c${i.icon} [Savvy Agent: ${t}]%c ${u}%c ${o}`,d,f,e,n):console.log(`%c${i.icon} [Savvy Agent: ${t}]%c ${u}%c ${o}`,d,f,e);try{typeof chrome<"u"&&((r=chrome.runtime)!=null&&r.sendMessage)&&chrome.runtime.sendMessage({type:"AGENT_LOG_EVENT",event:{timestamp:u,domain:t,message:o,data:n?JSON.parse(JSON.stringify(n)):null}}).catch(()=>{})}catch{}}const E={perception:(t,o)=>ce("PERCEPTION",t,o),action:(t,o)=>ce("ACTION",t,o)},de={en:{scannerTitle:"This Page is being scanned by Owly.AI",scannerSubtitle:"Please wait until finish...",snipTitle:"Owly Snip",snipInstruction:"Drag cursor over text or section to snip • ESC to cancel",snipExplainBtn:"Explain with Owly.AI",snipCopyBtn:"Copy Text",snipCopied:"Copied!",snipCancelTitle:"Cancel (ESC)",snipCapturing:"✓ Capturing screenshot..."},id:{scannerTitle:"Halaman ini sedang dipindai oleh Owly.AI",scannerSubtitle:"Mohon tunggu hingga selesai...",snipTitle:"Owly Snip",snipInstruction:"Seret kursor untuk memotong area teks • ESC untuk batal",snipExplainBtn:"Jelaskan dengan Owly.AI",snipCopyBtn:"Salin Teks",snipCopied:"Tersalin!",snipCancelTitle:"Batal (ESC)",snipCapturing:"✓ Mengambil tangkapan layar..."}};let ee="en";typeof chrome<"u"&&((me=chrome.storage)!=null&&me.local)&&(chrome.storage.local.get(["owly_preferred_lang","preferred_language"],t=>{const o=t.owly_preferred_lang||t.preferred_language;(o==="id"||o==="en")&&(ee=o)}),chrome.storage.onChanged.addListener((t,o)=>{var n,u;if(o==="local"){const i=((n=t.owly_preferred_lang)==null?void 0:n.newValue)||((u=t.preferred_language)==null?void 0:u.newValue);(i==="id"||i==="en")&&(ee=i)}}));function K(){return de[ee]||de.en}E.perception("Content Script activated. Closed Shadow DOM host initialized on page.");let F,L=null;try{const t=document.getElementById("savvy-root");if(t)try{t.remove()}catch{}L=document.createElement("div"),L.id="savvy-root",L.style.position="absolute",L.style.top="0",L.style.left="0",L.style.width="100%",L.style.height="100%",L.style.pointerEvents="none",L.style.zIndex="2147483647",(document.body||document.documentElement).appendChild(L),F=L.attachShadow({mode:"open"}),window.__SAVVY_SHADOW_ROOT__=F}catch(t){console.warn("[Savvy.AI] Shadow root attachment fallback:",t),F=window.__SAVVY_SHADOW_ROOT__||document.body}const ue=document.createElement("style");ue.textContent=`
    .savvy-spotlight {
      position: absolute;
      pointer-events: none;
      border: 2px solid #2563EB;
      background-color: rgba(37, 99, 235, 0.08);
      border-radius: 8px;
      transition: all 0.2s ease-out;
      box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
      z-index: 10;
    }
    .savvy-spotlight-beacon {
      position: absolute;
      top: -10px;
      right: -10px;
      width: 20px;
      height: 20px;
      background: #2563EB;
      color: white;
      font-size: 11px;
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    /* Virtual AI Ghost Cursor Pointer (Show Me Agent) */
    .savvy-ghost-cursor {
      position: fixed;
      top: 0;
      left: 0;
      pointer-events: none;
      z-index: 2147483647;
      transition: transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease;
      will-change: transform, opacity;
      display: none;
      opacity: 0;
    }
    .savvy-ghost-cursor.visible {
      display: block;
      opacity: 1;
    }
    .savvy-ghost-cursor svg {
      filter: drop-shadow(0 3px 8px rgba(0, 0, 0, 0.45));
      transform: rotate(-10deg);
      transition: transform 0.2s ease;
    }
    .savvy-ghost-cursor.clicking svg {
      transform: rotate(-10deg) scale(0.85);
    }
    .savvy-ghost-label {
      position: absolute;
      left: 22px;
      top: 14px;
      background: linear-gradient(135deg, #1e1b4b 0%, #2563eb 100%);
      color: #ffffff;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 999px;
      border: 1px solid rgba(255, 255, 255, 0.35);
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
      white-space: nowrap;
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .savvy-ghost-pulse {
      position: absolute;
      top: 0px;
      left: 0px;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: rgba(37, 99, 235, 0.45);
      border: 2px solid #60a5fa;
      transform: translate(-30%, -30%) scale(0);
      pointer-events: none;
      opacity: 0;
    }
    @keyframes savvy-ghost-ripple {
      0% { transform: translate(-30%, -30%) scale(0.3); opacity: 0.9; }
      50% { transform: translate(-30%, -30%) scale(2.8); opacity: 0.5; }
      100% { transform: translate(-30%, -30%) scale(4.8); opacity: 0; }
    }
    .savvy-ghost-pulse.active-pulse {
      animation: savvy-ghost-ripple 0.9s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
    }
    .savvy-reading-guide {
      position: fixed;
      left: 0;
      width: 100%;
      height: 48px;
      background: rgba(37, 99, 235, 0.12);
      border-top: 2px solid #2563EB;
      border-bottom: 2px solid #2563EB;
      pointer-events: none;
      z-index: 2147483646;
      display: none;
    }

    /* Scanner Laser Beam Animation */
    .savvy-scanner-overlay {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 2147483646;
      overflow: hidden;
      transition: opacity 0.3s ease;
    }
    .savvy-scanner-overlay.fade-out {
      opacity: 0;
    }
    .savvy-scanner-backdrop {
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at center, rgba(15, 23, 42, 0.18) 0%, rgba(15, 23, 42, 0.45) 100%);
    }
    .savvy-laser-beam {
      position: absolute;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, transparent 0%, rgba(56, 189, 248, 0.8) 15%, #2563EB 50%, rgba(56, 189, 248, 0.8) 85%, transparent 100%);
      box-shadow: 0 0 16px #38BDF8, 0 0 32px #2563EB, 0 0 4px #FFFFFF;
      animation: savvyLaserSweep 2.6s ease-in-out infinite alternate;
    }
    .savvy-laser-trail {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 90px;
      background: linear-gradient(to top, rgba(37, 99, 235, 0.18), transparent);
      pointer-events: none;
    }
    @keyframes savvyLaserSweep {
      0% {
        top: 2%;
      }
      100% {
        top: 98%;
      }
    }
    .savvy-scanner-card {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(15, 23, 42, 0.94);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(56, 189, 248, 0.35);
      border-radius: 18px;
      padding: 20px 32px;
      box-shadow: 0 20px 45px rgba(0, 0, 0, 0.5), 0 0 35px rgba(37, 99, 235, 0.25);
      text-align: center;
      color: #FFFFFF;
      z-index: 2147483647;
      pointer-events: auto;
      animation: savvyCardPop 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes savvyCardPop {
      0% { transform: translate(-50%, -46%) scale(0.95); opacity: 0; }
      100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
    }
    .savvy-scanner-card-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-bottom: 6px;
    }
    .savvy-scanner-spinner {
      width: 18px;
      height: 18px;
      border: 2.5px solid rgba(56, 189, 248, 0.25);
      border-top-color: #38BDF8;
      border-radius: 50%;
      animation: savvySpin 0.8s linear infinite;
    }
    @keyframes savvySpin {
      to { transform: rotate(360deg); }
    }
    .savvy-scanner-title {
      font-size: 15px;
      font-weight: 800;
      color: #FFFFFF;
      letter-spacing: -0.2px;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }
    .savvy-scanner-subtitle {
      font-size: 12px;
      color: #94A3B8;
      font-weight: 500;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
    }

    /* Numbered Field Badges */
    .savvy-field-number-badge {
      position: absolute;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: #2563EB;
      color: #FFFFFF;
      font-size: 11px;
      font-weight: 800;
      font-family: ui-sans-serif, system-ui, -apple-system, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 8px rgba(37, 99, 235, 0.45), 0 0 0 2px #FFFFFF;
      cursor: pointer;
      pointer-events: auto;
      z-index: 2147483647;
      transition: transform 0.15s ease, background 0.15s ease;
      user-select: none;
    }
    .savvy-field-number-badge:hover {
      background: #1D4ED8;
      transform: scale(1.22);
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.55), 0 0 0 2px #FFFFFF;
    }
    .savvy-field-number-badge.active-badge {
      background: #10B981;
      box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.4), 0 0 0 2px #FFFFFF;
      transform: scale(1.22);
    }
  `,F.appendChild(ue);function Ee(){te();const t=K(),o=document.createElement("div");o.className="savvy-scanner-overlay",o.innerHTML=`
      <div class="savvy-scanner-backdrop"></div>
      <div class="savvy-laser-beam">
        <div class="savvy-laser-trail"></div>
      </div>
      <div class="savvy-scanner-card">
        <div class="savvy-scanner-card-header">
          <span class="savvy-scanner-spinner"></span>
          <span class="savvy-scanner-title">${t.scannerTitle}</span>
        </div>
        <div class="savvy-scanner-subtitle">${t.scannerSubtitle}</div>
      </div>
    `,F.appendChild(o),E.action("✨ Laser scanner animation activated on page.")}function te(){const t=F.querySelector(".savvy-scanner-overlay");t&&(t.classList.add("fade-out"),setTimeout(()=>t.remove(),250),E.action("✨ Laser scanner animation stopped."))}function S(t){return t.replace(/[\n\r\t]+/g," ").replace(/\s+/g," ").replace(/[*:]+$/,"").trim()}function N(t){if(!t)return!1;const o=S(t);return!(o.length<2||o.length>70||/^(dd[\/\-\.]mm|yyyy[\/\-\.]mm|mm[\/\-\.]dd|hh:mm|08x|\+62|contoh|e\.g\.|example|\.\.\.|---)/i.test(o))}function q(t){var r;if(t.getAttribute("aria-label")&&N(t.getAttribute("aria-label")))return S(t.getAttribute("aria-label"));const o=t.getAttribute("aria-labelledby");if(o){const a=document.getElementById(o);if(a&&N(a.textContent))return S(a.textContent)}if(t.id){const a=document.querySelector(`label[for="${t.id}"]`);if(a&&N(a.textContent))return S(a.textContent)}const n=t.closest("label");if(n&&N(n.textContent))return S(n.textContent);let u=t.parentElement,i=0;for(;u&&i<5&&u.tagName!=="BODY"&&u.tagName!=="FORM";){const a=u.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(a&&!a.contains(t)&&N(a.textContent))return S(a.textContent);let p=u.previousElementSibling;for(;p;){const c=p.querySelector("label, .form-label, .col-form-label, dt, th, legend, h3, h4, h5, h6, strong, b");if(c&&N(c.textContent))return S(c.textContent);if(N(p.textContent))return S(p.textContent);p=p.previousElementSibling}if(u.tagName==="TR"){const c=u.querySelector("th, td:first-child");if(c&&!c.contains(t)&&N(c.textContent))return S(c.textContent)}u=u.parentElement,i++}let d=t.previousElementSibling;for(;d;){if(["LABEL","H3","H4","H5","H6","P","SPAN","STRONG","B","DIV"].includes(d.tagName)&&N(d.textContent))return S(d.textContent);d=d.previousElementSibling}try{const a=t.getBoundingClientRect();if(a.width>0&&a.height>0){const p=Array.from(document.querySelectorAll("label, .form-label, .col-form-label, dt, th, legend, h4, h5, h6, strong, b, [class*='label']"));let c=null,v=99999;for(const s of p){if(s.contains(t)||t.contains(s)||!N(s.textContent))continue;const m=s.getBoundingClientRect();if(m.width===0||m.height===0)continue;const C=m.right<=a.left+25&&m.left>=a.left-450&&Math.abs((m.top+m.bottom)/2-(a.top+a.bottom)/2)<28,h=m.bottom<=a.top+8&&m.bottom>=a.top-50&&m.left<a.right&&m.right>a.left-30;if(C){const y=a.left-m.right;y>=0&&y<v&&(v=y,c=s)}else if(h){const y=(a.top-m.bottom)*1.5;y>=0&&y<v&&(v=y,c=s)}}if(c&&c.textContent)return S(c.textContent)}}catch{}if(t.tagName==="BUTTON"||t.getAttribute("role")==="button"){const a=(r=t.textContent)==null?void 0:r.trim();if(a&&/^(upload|unggah|browse|pilih file|pilih berkas|choose file)$/i.test(a)){const p=t.closest(".card, .panel, .upload-container, .form-group, [class*='upload'], div");if(p){const c=p.querySelector("h3, h4, h5, h6, label, .title, strong");if(c&&N(c.textContent))return S(c.textContent)}}if(a)return S(a)}const f=t.getAttribute("placeholder");if(f&&N(f))return S(f);const e=t.getAttribute("name")||t.id||"";return e?e==="_username"||e==="username"?"Email":e==="_password"||e==="password"?"Password":S(e.replace(/[_\-]+/g," ")):"Kolom Form"}function j(){const t=[],o=new Set;return Array.from(document.querySelectorAll("input, select, textarea")).forEach(i=>{var r,a;if(i.type==="hidden"||i.type==="submit"||i.type==="reset")return;if(i.type==="file"){const p=i.getBoundingClientRect(),c=p.width>0&&p.height>0&&window.getComputedStyle(i).visibility!=="hidden";let v=i;if(!c){const s=i.id?document.querySelector(`label[for="${i.id}"]`):null,m=i.closest("label"),C=i.closest(".form-group, .upload-container, div"),h=C==null?void 0:C.querySelector("button, .btn, [role='button'], label"),y=[s,m,h].find(w=>{if(!w)return!1;const l=w.getBoundingClientRect();return l.width>0&&l.height>0&&window.getComputedStyle(w).visibility!=="hidden"});if(y)v=y;else return}o.add(i),o.add(v),t.push({targetEl:i,badgeTargetEl:v,id:i.id||i.name||"",name:i.name||"",label:q(v)||q(i)||"Upload File",placeholder:"",required:i.required,type:"file"});return}const d=i.getBoundingClientRect();if(!(d.width>0&&d.height>0&&window.getComputedStyle(i).visibility!=="hidden"))return;o.add(i);let e=q(i);if(i.type==="radio"||i.type==="checkbox"){const p=(a=(r=i.closest("label"))==null?void 0:r.textContent)==null?void 0:a.trim(),c=i.value;p&&!e.includes(p)?e=`${e} (${p})`:c&&c!=="on"&&!e.includes(c)&&(e=`${e} (${c})`)}t.push({targetEl:i,badgeTargetEl:i,id:i.id||i.name||"",name:i.name||"",label:e,placeholder:i.placeholder||"",required:i.required,type:i.type||i.tagName.toLowerCase()})}),Array.from(document.querySelectorAll("button, [role='button'], a.btn, label.btn, .upload-btn")).forEach(i=>{var e;if(o.has(i))return;const d=(i.textContent||"").trim().toLowerCase();if(/^(upload|unggah|browse|pilih file|pilih berkas|choose file)/i.test(d)||((e=i.getAttribute("aria-label"))==null?void 0:e.toLowerCase().includes("upload"))){const r=i.getBoundingClientRect();if(!(r.width>0&&r.height>0&&window.getComputedStyle(i).visibility!=="hidden"))return;o.add(i),t.push({targetEl:i,badgeTargetEl:i,id:i.id||"",name:i.getAttribute("name")||"",label:q(i),placeholder:"",required:!1,type:"file"})}}),t.sort((i,d)=>{const f=i.badgeTargetEl.getBoundingClientRect(),e=d.badgeTargetEl.getBoundingClientRect();return Math.abs(f.top-e.top)>12?f.top-e.top:f.left-e.left}),t}function Ce(){const o=j().map(f=>{var _,D,P;const e=f.targetEl;let r="";if(e)if(e.tagName==="SELECT"){const O=e;r=((_=O.options[O.selectedIndex])==null?void 0:_.text)||O.value||""}else if(e.type==="file")r=((P=(D=e.files)==null?void 0:D[0])==null?void 0:P.name)||"";else if(e.type==="checkbox"||e.type==="radio"){const O=e;r=O.checked?O.value||"checked":""}else r=e.value||"";const a=e.closest(".form-group, .mb-3, .form-row, tr, div")||e.parentElement,p=(a==null?void 0:a.textContent)||"",v=(f.label||"").includes("*")||p.includes("*")||e.getAttribute("aria-required")==="true",s=p.match(/\(([^)]+)\)/),m=s?s[0]:"",C="minLength"in e&&typeof e.minLength=="number"&&e.minLength>0?e.minLength:void 0,h="maxLength"in e&&typeof e.maxLength=="number"&&e.maxLength>0?e.maxLength:void 0,y=e.getAttribute("pattern")||void 0,w=e.getAttribute("data-mask")||e.getAttribute("data-inputmask")||void 0,l=e.getAttribute("accept")||void 0;return{fieldId:f.id||e.id||f.name,name:f.name||e.name||f.id,label:f.label,currentValue:r.trim(),surroundingContext:m,rules:{isRequired:e.required||v,placeholder:f.placeholder||e.placeholder||"",pattern:y,minLength:C,maxLength:h,type:f.type||e.type||"text",inputMaskDetected:w,accept:l}}}),n=[],u=Array.from(document.querySelectorAll("aside, .alert, .note, .keterangan, .sidebar, .info, footer, small, p, li")).map(f=>{var e;return((e=f.textContent)==null?void 0:e.trim())||""}).filter(f=>{const e=f.toLowerCase();return(e.includes("mb")||e.includes("kb")||e.includes("pdf")||e.includes("jpg")||e.includes("png"))&&(e.includes("maksimal")||e.includes("ukuran")||e.includes("file")||e.includes("berkas")||e.includes("format"))}).slice(0,5);n.push(...u);const i=[];return Array.from(document.querySelectorAll('input[type="file"]')).forEach(f=>{var e;if(f.files&&f.files.length>0){const r=f.files[0],a=r.name.includes(".")&&((e=r.name.split(".").pop())==null?void 0:e.toLowerCase())||"";i.push({fieldName:f.name||f.id||"file",fileName:r.name,fileSizeKb:Math.round(r.size/1024),fileExtension:a})}}),{fields:o,pageUploadContext:{pageWideFileInstructions:n,attachedFilesMetadata:i},meta:{url:window.location.href,domain:window.location.hostname,title:document.title}}}let T=[];function J(){const t=window.scrollY||document.documentElement.scrollTop,o=window.scrollX||document.documentElement.scrollLeft;T.forEach(({badgeEl:n,badgeTargetEl:u,targetEl:i})=>{const d=u||i;if(!document.body.contains(d)){n.style.display="none";return}const f=d.getBoundingClientRect();if(f.width===0&&f.height===0){n.style.display="none";return}n.style.display="flex",n.style.top=`${f.top+t-10}px`,n.style.left=`${f.right+o-12}px`})}function _e(){ne();const t=j(),o=window.scrollY||document.documentElement.scrollTop,n=window.scrollX||document.documentElement.scrollLeft;t.forEach((u,i)=>{const d=i+1,f=u.badgeTargetEl.getBoundingClientRect(),e=document.createElement("div");e.className="savvy-field-number-badge",e.textContent=`${d}`,e.title=`Kolom #${d}: ${u.label} (Klik untuk panduan)`,e.style.top=`${f.top+o-10}px`,e.style.left=`${f.right+n-12}px`,e.addEventListener("click",r=>{r.stopPropagation(),r.preventDefault(),u.targetEl.focus(),u.badgeTargetEl.scrollIntoView({behavior:"smooth",block:"center"}),Y(u.badgeTargetEl),T.forEach((a,p)=>{p===i?a.badgeEl.classList.add("active-badge"):a.badgeEl.classList.remove("active-badge")});try{chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:i,fieldId:u.id||"",fieldName:u.name||"",label:u.label}).catch(()=>{})}catch{}}),F.appendChild(e),T.push({badgeEl:e,targetEl:u.targetEl,badgeTargetEl:u.badgeTargetEl,index:i})}),window.addEventListener("scroll",J,{passive:!0}),window.addEventListener("resize",J,{passive:!0}),E.action(`🔢 Rendered numbered badges for ${t.length} interactive fields.`)}function ne(){T.forEach(({badgeEl:t})=>t.remove()),T=[],window.removeEventListener("scroll",J),window.removeEventListener("resize",J)}const M=document.createElement("div");M.className="savvy-spotlight",M.style.display="none",M.innerHTML='<div class="savvy-spotlight-beacon">O</div>',F.appendChild(M);const I=document.createElement("div");I.className="savvy-ghost-cursor",I.innerHTML=`
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
      <path d="M4 3L11 20L14 13L21 10L4 3Z" fill="#2563EB" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    <div class="savvy-ghost-pulse"></div>
    <div class="savvy-ghost-label">
      <span>✨</span> Owly
    </div>
  `,F.appendChild(I);let ie={x:window.innerWidth*.7,y:window.innerHeight*.3};window.addEventListener("mousemove",t=>{ie={x:t.clientX,y:t.clientY}},{passive:!0});let Q=null;function oe(t){Q&&clearTimeout(Q),t.scrollIntoView({behavior:"smooth",block:"center"}),setTimeout(()=>{const o=t.getBoundingClientRect(),n=o.left+Math.min(Math.max(o.width*.5,12),o.width-8),u=o.top+Math.min(Math.max(o.height*.5,12),o.height-8);I.style.transition="none",I.style.transform=`translate(${ie.x}px, ${ie.y}px)`,I.classList.remove("clicking");const i=I.querySelector(".savvy-ghost-pulse");i&&i.classList.remove("active-pulse"),I.classList.add("visible"),requestAnimationFrame(()=>{I.style.transition="transform 0.85s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.4s ease",I.style.transform=`translate(${n}px, ${u}px)`,Q=setTimeout(()=>{I.classList.add("clicking"),i&&i.classList.add("active-pulse"),Y(t),Q=setTimeout(()=>{I.classList.remove("visible"),I.classList.remove("clicking"),i&&i.classList.remove("active-pulse")},1800)},850)})},150)}let z=null;function pe(){M&&(M.style.display="none"),z&&(clearTimeout(z),z=null)}function Y(t){const o=t.getBoundingClientRect(),n=window.scrollY||document.documentElement.scrollTop,u=window.scrollX||document.documentElement.scrollLeft;M.style.display="block",M.style.top=`${o.top+n-4}px`,M.style.left=`${o.left+u-4}px`,M.style.width=`${o.width+8}px`,M.style.height=`${o.height+8}px`,z&&clearTimeout(z),z=setTimeout(()=>{M.style.display="none"},4e3)}const H=document.createElement("div");H.className="savvy-reading-guide",F.appendChild(H),window.addEventListener("mousemove",t=>{H.style.display==="block"&&(H.style.top=`${t.clientY-24}px`)}),document.addEventListener("focusin",t=>{var n;const o=t.target;if(o&&(o.tagName==="INPUT"||o.tagName==="SELECT"||o.tagName==="TEXTAREA"||o.tagName==="BUTTON")){const u=q(o);E.perception(`🎯 Field focused: '${o.id||o.getAttribute("name")||o.tagName.toLowerCase()}' (${u})`,{fieldId:o.id||"",tagName:o.tagName,inputType:o.type||"text",hasValue:!!o.value});try{if(typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&(chrome.runtime.sendMessage({type:"FIELD_FOCUSED",fieldId:o.id||"",fieldName:o.getAttribute("name")||"",label:u,tagName:o.tagName,inputType:o.type||"text",value:o.value||""}).catch(()=>{}),T.length>0)){const i=T.findIndex(d=>d.targetEl===o||d.badgeTargetEl===o);i!==-1&&(T.forEach((d,f)=>{f===i?d.badgeEl.classList.add("active-badge"):d.badgeEl.classList.remove("active-badge")}),chrome.runtime.sendMessage({type:"FIELD_SELECTED_FROM_PAGE",fieldIndex:i,fieldId:o.id||"",fieldName:o.getAttribute("name")||"",label:u}).catch(()=>{}))}}catch{}}}),document.addEventListener("focusout",()=>{pe()});let ge=null,fe="";function Se(){return Array.from(document.querySelectorAll("input, select, textarea")).filter(n=>n.type!=="hidden"&&n.type!=="submit"&&n.offsetParent!==null).map(n=>{const u="placeholder"in n?n.placeholder:"";return`${n.name||n.id||u}:${n.type||n.tagName.toLowerCase()}`}).join("|")}function ae(){clearTimeout(ge),ge=setTimeout(()=>{const t=Se();if(t!==fe){fe=t;const o=t?t.split("|").length:0;E.perception(`🕵️ Dynamic DOM Mutation detected (${o} visible fields)`,{fieldCount:o,signature:t.substring(0,80)+(t.length>80?"...":"")}),chrome.runtime.sendMessage({type:"FORM_DOM_MUTATED",signature:t,fieldCount:o}).catch(()=>{})}},400)}const he=new MutationObserver(t=>{t.some(n=>L?n.target!==L&&!L.contains(n.target):!0)&&ae()});window.__SAVVY_OBSERVER__=he,he.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["hidden","disabled","aria-hidden","style","class"]}),window.addEventListener("popstate",ae),window.addEventListener("hashchange",ae);const Te={"bikin akun":["sign up","signup","register","daftar","registrasi","buat akun","create account","join"],"buat akun":["sign up","signup","register","daftar","registrasi","create account","join"],daftar:["sign up","signup","register","registrasi","buat akun","apply","pendaftaran"],masuk:["login","log in","sign in","signin","masuk"],login:["log in","sign in","signin","masuk"],signup:["sign up","register","daftar","registrasi","buat akun"],keluar:["logout","log out","sign out","keluar"],unggah:["upload","unggah","pilih berkas","pilih file","choose file","browse"],upload:["unggah","pilih berkas","pilih file","choose file","browse"],unduh:["download","unduh","unduh berkas","ambil file"],download:["unduh","unduh berkas","ambil file"],syarat:["persyaratan","kriteria","ketentuan","eligibility","terms","requirement"],persyaratan:["syarat","kriteria","ketentuan","eligibility","terms","requirement"],bantuan:["help","bantuan","faq","panduan","hubungi kami","contact","support"],biaya:["tarif","harga","biaya","fee","cost","pembayaran","payment"],kirim:["submit","kirim","send","ajukan","lanjut","next"],submit:["kirim","send","ajukan","simpan","save"],simpan:["save","simpan","submit"],batal:["cancel","batal","reset"]};function Ae(t){var m,C;const o=t.toLowerCase().trim();if(!o)return{success:!1};const n=o.replace(/\b(tombol|button|bagian|seksi|kolom|field|link|halaman|menu)\b/gi,"").trim(),u=n.length>=2?n:o,d=Array.from(document.querySelectorAll("button, a, input, select, textarea, [role='button'], [role='link'], [role='tab'], h1, h2, h3, h4, h5, h6, section, [id], label, dt, th")),f=[];for(const h of d){if(h.id==="savvy-root"||h.closest("#savvy-root"))continue;const y=h.getBoundingClientRect();if(y.width<=4||y.height<=4)continue;const w=window.getComputedStyle(h);w.visibility==="hidden"||w.display==="none"||w.opacity==="0"||f.push(h)}const e=h=>{var P;const y=h.getAttribute("aria-label")||"",w=h.placeholder||"",l=((P=h.textContent)==null?void 0:P.trim())||"",_=h.getAttribute("title")||"",D=h.value||"";return`${l} ${y} ${w} ${_} ${D}`.toLowerCase().replace(/\s+/g," ").trim()};let r=null,a=0;for(const h of f){const y=e(h);if(!y)continue;const w=/^(button|a|input|select|textarea)$/i.test(h.tagName)||h.getAttribute("role")==="button"||h.getAttribute("role")==="link";let l=0;y===u||y===o?l=w?100:85:y.includes(u)&&(l=w?80:65),l>a&&(a=l,r=h)}if(r&&a>=65)return oe(r),E.action(`🎯 [Show Me Level 1] Found exact/substring match for "${t}" -> <${r.tagName.toLowerCase()}>`,{score:a}),{success:!0,level:1,matchedText:((m=r.textContent)==null?void 0:m.trim().slice(0,50))||r.getAttribute("aria-label")||r.tagName,tag:r.tagName.toLowerCase()};for(const[h,y]of Object.entries(Te))if(u.includes(h)||h.includes(u)){for(const w of y)for(const l of f)if(e(l).includes(w))return oe(l),E.action(`⚡ [Show Me Level 2] Found synonym match ("${h}" -> "${w}") for "${t}" -> <${l.tagName.toLowerCase()}>`),{success:!0,level:2,matchedText:((C=l.textContent)==null?void 0:C.trim().slice(0,50))||w,tag:l.tagName.toLowerCase()}}const p=f.filter(h=>{const y=h.tagName.toLowerCase();return y==="button"||y==="a"||y==="input"||h.getAttribute("role")==="button"||h.getAttribute("role")==="link"}),v=(p.length>=5?p:f).slice(0,20);return window.__SAVVY_SHOW_ME_CANDIDATES__=v,{success:!1,candidates:v.map((h,y)=>({domIndex:y,tag:h.tagName.toLowerCase(),text:(h.textContent||"").trim().replace(/\s+/g," ").slice(0,60),aria:h.getAttribute("aria-label")||"",placeholder:h.placeholder||""})).filter(h=>h.text.length>0||h.aria.length>0||h.placeholder.length>0)}}chrome.runtime.onMessage.addListener((t,o,n)=>{var u,i,d,f;if(t.type==="FIND_AND_HIGHLIGHT_ELEMENT"){const e=Ae(t.query||"");n(e);return}if(t.type==="HIGHLIGHT_DOM_ELEMENT_BY_INDEX"){const e=t.domIndex,r=window.__SAVVY_SHOW_ME_CANDIDATES__;if(r&&r[e]){const a=r[e];oe(a),n({success:!0,text:(u=a.textContent)==null?void 0:u.trim().slice(0,50)});return}n({success:!1,reason:"Element index not found in cache"});return}if(t.type==="INJECT_VALUE"){const{fieldId:e,fieldName:r,fieldIndex:a,value:p}=t;let c=null;if(typeof a=="number"&&T[a]&&(c=T[a].targetEl),!c&&e&&(c=document.getElementById(e)),!c&&r&&(c=document.querySelector(`[name="${r}"]`)),c&&"value"in c){c.value=p,c.dispatchEvent(new Event("input",{bubbles:!0})),c.dispatchEvent(new Event("change",{bubbles:!0})),c.dispatchEvent(new Event("blur",{bubbles:!0})),E.action(`⚡ Injected value into field '${e||r||a}'`,{targetTag:c.tagName}),n({success:!0});return}n({success:!1,reason:"Element not found"})}if(t.type==="SET_A11Y_FEATURE"){const{feature:e,enabled:r,value:a,level:p}=t;se(e,r,a),E.action(`👓 A11y feature '${e}' set to: ${a||(r?"ON":"OFF")}`),n({success:!0,feature:e,enabled:r,value:a})}if(t.type==="APPLY_ALL_A11Y_SETTINGS"){const e=t.settings||{};Object.entries(e).forEach(([r,a])=>{a&&se(r,a.enabled,a.value,a.level)}),n({success:!0,count:Object.keys(e).length})}if(t.type==="CLEAR_ALL_A11Y"){Le(),n({success:!0});return}if(t.type==="SCAN_PAGE_FIELDS"||t.type==="QUERY_PAGE_FIELDS"){const r=j().map(p=>({id:p.id,name:p.name,label:p.label,placeholder:p.placeholder,required:p.required,type:p.type})),a={url:window.location.href,domain:window.location.hostname,title:document.title,description:((i=document.querySelector('meta[name="description"]'))==null?void 0:i.getAttribute("content"))||"",keywords:((f=(d=document.querySelector('meta[name="keywords"]'))==null?void 0:d.getAttribute("content"))==null?void 0:f.split(",").map(p=>p.trim()))||[]};E.perception(`🔍 Scanning DOM: Discovered ${r.length} synchronized form fields on ${a.domain}`,{count:r.length,title:a.title,fieldKeys:r.map(p=>p.name||p.id||p.label).slice(0,8)}),n({success:!0,fields:r,count:r.length,meta:a})}if(t.type==="EXTRACT_FORM_AUDIT_DATA"){const e=Ce();E.action(`🔍 EXTRACT_FORM_AUDIT_DATA: Scraped ${e.fields.length} active inputs and ${e.pageUploadContext.attachedFilesMetadata.length} attached files for audit.`),n({success:!0,data:e});return}if(t.type==="HIGHLIGHT_AUDIT_FIELD"){let e=null,r=null;if(t.fieldId&&(e=document.getElementById(t.fieldId)),!e&&t.fieldName&&(e=document.querySelector(`[name="${t.fieldName}"]`)),!e&&typeof t.fieldIndex=="number"){const p=j();p[t.fieldIndex]&&(e=p[t.fieldIndex].targetEl,r=p[t.fieldIndex].badgeTargetEl)}const a=r||e;if(a){e==null||e.focus(),a.scrollIntoView({behavior:"smooth",block:"center"}),Y(a),E.action(`🎯 Audit Spotlight highlighted field '${t.fieldLabel||t.fieldName||t.fieldId}'`),n({success:!0});return}n({success:!1,reason:"Field not found"});return}if(t.type==="APPLY_FIELD_VALUE"){let e=null;if(t.fieldId&&(e=document.getElementById(t.fieldId)),!e&&t.fieldName&&(e=document.querySelector(`[name="${t.fieldName}"]`)),e&&typeof t.value=="string"){e.value=t.value,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus(),Y(e),E.action(`⚡ Applied Vault value to field '${t.fieldName||t.fieldId}': "${t.value}"`),n({success:!0});return}n({success:!1,reason:"Field or value invalid"});return}if(t.type==="START_SCAN_ANIMATION"){Ee(),n({success:!0});return}if(t.type==="STOP_SCAN_ANIMATION"){te(),n({success:!0});return}if(t.type==="SHOW_FIELD_NUMBERS"){_e(),n({success:!0,count:T.length});return}if(t.type==="HIDE_FIELD_NUMBERS"){ne(),n({success:!0});return}if(t.type==="NAVIGATE_TO_FIELD"){let e=null,r=null;const a=typeof t.fieldIndex=="number"?t.fieldIndex:-1;if(a>=0&&T[a]&&(e=T[a].targetEl,r=T[a].badgeTargetEl,T.forEach((c,v)=>{v===a?c.badgeEl.classList.add("active-badge"):c.badgeEl.classList.remove("active-badge")})),!e&&t.fieldId&&(e=document.getElementById(t.fieldId)),!e&&t.fieldName&&(e=document.querySelector(`[name="${t.fieldName}"]`)),!e&&a>=0){const c=j();c[a]&&(e=c[a].targetEl,r=c[a].badgeTargetEl)}const p=r||e;if(p){e==null||e.focus(),p.scrollIntoView({behavior:"smooth",block:"center"}),Y(p),n({success:!0,fieldIndex:a});return}n({success:!1,reason:"Field not found"});return}if(t.type==="START_SNIP_SELECTION"&&(E.action("✂️ Starting Visual Snip selection mode on screen for 'Explain This'"),ke(),n({success:!0,mode:"active"})),t.type==="SHOW_FIELD_SPOTLIGHT"){let r=document.activeElement;if((!r||r.tagName==="BODY")&&(r=document.querySelector("input:not([type=hidden]), textarea, select")),r){r.focus(),r.scrollIntoView({behavior:"smooth",block:"center"}),Y(r),E.action(`💡 Spotlight Beacon navigated to field '${r.id||r.getAttribute("name")||"input"}'`),n({success:!0});return}n({success:!1,reason:"No target field found"})}if(t.type==="BATCH_AUTOFILL"){const e=t.payload||{},r=Array.isArray(t.items)?t.items:Array.isArray(e.items)?e.items:[],a=Array.from(document.querySelectorAll("input, textarea, select"));window.__SAVVY_UNDO_BACKUP__=a.map(c=>({el:c,prevVal:c.value}));let p=0;return a.forEach(c=>{if(c.type==="hidden"||c.type==="submit"||c.type==="button")return;const s=(q(c)||c.name||c.id||c.placeholder||"").toLowerCase().trim();let m="";if(r.length>0){const C=s.includes("mother")||s.includes("ibu");for(const h of r){const y=h.name.toLowerCase().trim();if(C&&(y.includes("nama lengkap")||y==="nama"||y==="full name")||!C&&y.includes("ibu"))continue;let w=s.length>1&&y.length>1&&(s===y||s.includes(y)||y.includes(s));if(!w&&Array.isArray(h.aliases)&&(w=h.aliases.some(l=>{const _=l.toLowerCase().trim();return _.length>1&&(s===_||s.includes(_)||_.includes(s))})),w&&h.value){m=h.value;break}}}m||(s.includes("nik")||s.includes("ktp")||s.includes("national id")?m=e.nik||e.NIK||"":s.includes("mother")||s.includes("ibu")?m=e["Nama Ibu Kandung"]||e.nama_ibu||"":s.includes("nama")||s.includes("name")||s.includes("fullname")?m=e.nama||e["Nama Lengkap"]||"":s.includes("place")||s.includes("tempat")||s.includes("pob")?m=e.tempat_lahir||e["Tempat Lahir"]||"":c.type==="date"||s.includes("tanggal_lahir")||s.includes("tgl_lahir")||s.includes("dob")||s.includes("birth")&&(s.includes("date")||s.includes("day"))||s.includes("lahir")&&s.includes("tgl")?m=e.tanggal_lahir||e["Tanggal Lahir"]||"":s.includes("alamat")||s.includes("address")||s.includes("domisili")?m=e.alamat||e["Alamat KTP"]||"":c.type==="email"||s.includes("email")||s.includes("mail")||s.includes("surel")?m=e.email||e.Email||"":(c.type==="tel"||s.includes("hp")||s.includes("phone")||s.includes("telp")||s.includes("whatsapp"))&&(m=e.no_hp||e["No. Handphone"]||"")),m&&(c.value=m,c.dispatchEvent(new Event("input",{bubbles:!0})),c.dispatchEvent(new Event("change",{bubbles:!0})),p++)}),E.action(`⚡ Batch Autofill executed: ${p} fields populated safely with reversibility snapshot.`,{injectedCount:p,keys:Object.keys(e)}),n({success:!0,count:p}),!0}if(t.type==="UNDO_AUTOFILL"){const e=window.__SAVVY_UNDO_BACKUP__;if(e&&Array.isArray(e)){e.forEach(({el:a,prevVal:p})=>{a&&(a.value=p,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})))});const r=e.length;return delete window.__SAVVY_UNDO_BACKUP__,E.action(`↩️ Undo Autofill executed: Restored previous values across ${r} fields.`),n({success:!0,undone:!0}),!0}n({success:!1,reason:"No backup state found"})}return!0});function ke(){const t=F.querySelector(".savvy-lightshot-container");t&&t.remove(),E.action("✂️ Activating Lightshot-style visual crop mode on screen.");const o=document.createElement("div");o.className="savvy-lightshot-container",o.style.cssText=`
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      z-index: 2147483647;
      cursor: crosshair;
      user-select: none;
      -webkit-user-select: none;
      background: rgba(15, 23, 42, 0.45);
      transition: background 0.15s ease-out;
      pointer-events: auto;
    `;const n=document.createElement("div");n.style.cssText=`
      position: fixed;
      top: 18px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(15, 23, 42, 0.92);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #FFFFFF;
      padding: 8px 18px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.35);
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 10px;
      z-index: 2147483647;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const u=K();n.innerHTML=`
      <div style="display: flex; align-items: center; gap: 6px; font-weight: 700; color: #60A5FA;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>
        </svg>
        <span>${u.snipTitle}</span>
      </div>
      <div style="width: 1px; height: 14px; background: rgba(255, 255, 255, 0.2);"></div>
      <span style="color: #E2E8F0; font-size: 12px;">${u.snipInstruction}</span>
    `,o.appendChild(n);const i=document.createElement("div");i.style.cssText=`
      position: fixed;
      display: none;
      border: 2px solid #398CF5;
      box-shadow: 0 0 0 99999px rgba(15, 23, 42, 0.65);
      background: transparent;
      pointer-events: auto;
      z-index: 2147483647;
      box-sizing: border-box;
    `;const d=document.createElement("div");d.style.cssText=`
      position: absolute;
      top: -26px;
      left: -2px;
      background: #0F172A;
      color: #93C5FD;
      font-size: 11px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 4px;
      pointer-events: none;
      white-space: nowrap;
      font-family: monospace, system-ui, sans-serif;
      border: 1px solid rgba(59, 130, 246, 0.4);
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    `,i.appendChild(d),["nw","n","ne","e","se","s","sw","w"].forEach(g=>{const b=document.createElement("div");b.dataset.handle=g;let x="default";g==="nw"||g==="se"?x="nwse-resize":g==="ne"||g==="sw"?x="nesw-resize":g==="n"||g==="s"?x="ns-resize":(g==="e"||g==="w")&&(x="ew-resize"),b.style.cssText=`
        position: absolute;
        width: 8px;
        height: 8px;
        background: #FFFFFF;
        border: 2px solid #398CF5;
        border-radius: 1px;
        z-index: 10;
        cursor: ${x};
        box-sizing: border-box;
      `,g.includes("n")&&(b.style.top="-5px"),g.includes("s")&&(b.style.bottom="-5px"),g.includes("w")&&(b.style.left="-5px"),g.includes("e")&&(b.style.right="-5px"),(g==="n"||g==="s")&&(b.style.left="50%",b.style.transform="translateX(-50%)"),(g==="w"||g==="e")&&(b.style.top="50%",b.style.transform="translateY(-50%)"),i.appendChild(b)});const e=document.createElement("div");e.style.cssText=`
      position: absolute;
      display: none;
      align-items: center;
      gap: 6px;
      padding: 5px 6px;
      background: #0F172A;
      border-radius: 8px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6);
      z-index: 25;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;const r=document.createElement("button");r.style.cssText=`
      background: linear-gradient(135deg, #398CF5 0%, #7045ED 100%);
      color: #FFFFFF;
      font-weight: 600;
      font-size: 12px;
      padding: 6px 14px;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      white-space: nowrap;
      transition: all 0.15s ease;
      box-shadow: 0 2px 8px rgba(57, 140, 245, 0.35);
    `,r.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
      </svg>
      <span>${u.snipExplainBtn}</span>
    `;const a=document.createElement("button");a.style.cssText=`
      background: #1E293B;
      color: #CBD5E1;
      font-weight: 500;
      font-size: 12px;
      padding: 6px 11px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      white-space: nowrap;
      transition: all 0.15s ease;
    `,a.innerHTML=`
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
      <span>${u.snipCopyBtn}</span>
    `;const p=document.createElement("button");p.style.cssText=`
      background: #1E293B;
      color: #EF4444;
      font-weight: 700;
      font-size: 13px;
      padding: 6px 10px;
      border-radius: 6px;
      border: 1px solid #334155;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      transition: all 0.15s ease;
    `,p.innerHTML="✕",p.title=u.snipCancelTitle,e.appendChild(r),e.appendChild(a),e.appendChild(p),i.appendChild(e),o.appendChild(i),F.appendChild(o);let c=!1,v=!1,s=!1,m="",C=0,h=0,y=0,w=0;const l={left:0,top:0,width:0,height:0};function _(){const g=Math.max(0,l.left),b=Math.max(0,l.top),x=Math.max(0,l.width),A=Math.max(0,l.height);i.style.left=`${g}px`,i.style.top=`${b}px`,i.style.width=`${x}px`,i.style.height=`${A}px`,d.textContent=`${Math.round(x)} × ${Math.round(A)} px`,b+A+50>window.innerHeight?e.style.bottom="8px":e.style.bottom="-48px",g+x<280?(e.style.right="auto",e.style.left="0px"):(e.style.left="auto",e.style.right="0px")}function D(){o.remove(),document.removeEventListener("keydown",P),window.removeEventListener("mousemove",xe),window.removeEventListener("mouseup",ve)}function P(g){g.key==="Escape"?D():g.key==="Enter"&&i.style.display!=="none"&&l.width>20&&l.height>20&&be()}document.addEventListener("keydown",P);function O(){var W;const g=[],b=l.left,x=l.top,A=l.left+l.width,G=l.top+l.height,Z=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(k){if(!k.nodeValue||!k.nodeValue.trim())return NodeFilter.FILTER_REJECT;const B=k.parentElement;if(!B||B.closest("#savvy-root"))return NodeFilter.FILTER_REJECT;const V=window.getComputedStyle(B);return V.display==="none"||V.visibility==="hidden"||V.opacity==="0"?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let R;for(;R=Z.nextNode();)try{const k=document.createRange();k.selectNode(R);const B=k.getClientRects();for(let V=0;V<B.length;V++){const $=B[V];if(!($.right<b||$.left>A||$.bottom<x||$.top>G)){const X=(W=R.nodeValue)==null?void 0:W.trim();X&&!g.includes(X)&&g.push(X);break}}}catch{}document.querySelectorAll("input, textarea, select").forEach(k=>{const B=k.getBoundingClientRect();if(!(B.right<b||B.left>A||B.bottom<x||B.top>G)){const $=k,le=$.value||$.placeholder||"",X=$.getAttribute("aria-label")||$.name||$.id||"";(le||X)&&g.push(`[Field ${X}: ${le}]`)}});let U=g.join(" ").trim();return U=U.replace(/\b[1-9][0-9]{15}\b/g,"[REDACTED_NIK]"),U}function be(){var x,A,G,Z,R,re,U,W;const g=O();E.action("⚡ Visual crop snip confirmed by user.",{rect:l,extractedLength:g.length,preview:g.slice(0,100)});const b={description:((x=document.querySelector('meta[name="description"]'))==null?void 0:x.getAttribute("content"))||((A=document.querySelector('meta[property="og:description"]'))==null?void 0:A.getAttribute("content"))||"",keywords:((G=document.querySelector('meta[name="keywords"]'))==null?void 0:G.getAttribute("content"))||"",ogTitle:((Z=document.querySelector('meta[property="og:title"]'))==null?void 0:Z.getAttribute("content"))||"",ogDescription:((R=document.querySelector('meta[property="og:description"]'))==null?void 0:R.getAttribute("content"))||"",ogType:((re=document.querySelector('meta[property="og:type"]'))==null?void 0:re.getAttribute("content"))||"",lang:document.documentElement.lang||navigator.language||"id-ID",author:((U=document.querySelector('meta[name="author"]'))==null?void 0:U.getAttribute("content"))||"",canonicalUrl:((W=document.querySelector('link[rel="canonical"]'))==null?void 0:W.getAttribute("href"))||window.location.href};i.style.borderColor="#10B981",i.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65), 0 0 25px rgba(16, 185, 129, 0.6)",d.textContent=K().snipCapturing,d.style.color="#34D399",r.disabled=!0,r.style.opacity="0.7",o.style.visibility="hidden",setTimeout(()=>{chrome.runtime.sendMessage({type:"CAPTURE_VISIBLE_TAB"},k=>{D(),chrome.runtime.sendMessage({type:"SNIP_EXPLAIN_RESULT",fullScreenshot:k!=null&&k.success?k.dataUrl:null,text:g,rect:{left:Math.round(l.left),top:Math.round(l.top),width:Math.round(l.width),height:Math.round(l.height),viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,devicePixelRatio:window.devicePixelRatio||1},portalUrl:window.location.href,portalDomain:window.location.hostname,pageTitle:document.title,meta:b})})},60)}r.addEventListener("click",g=>{g.stopPropagation(),be()}),a.addEventListener("click",g=>{g.stopPropagation();const b=O();if(b){navigator.clipboard.writeText(b);const x=K();a.innerHTML=`✓ ${x.snipCopied}`,setTimeout(()=>{a.innerHTML=`
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            <span>${x.snipCopyBtn}</span>
          `},1500)}}),p.addEventListener("click",g=>{g.stopPropagation(),D()}),o.addEventListener("mousedown",g=>{var x;const b=g.target;if(!e.contains(b)){if((x=b.dataset)!=null&&x.handle){g.preventDefault(),g.stopPropagation(),s=!0,m=b.dataset.handle,C=g.clientX,h=g.clientY,e.style.display="none";return}if(i.contains(b)&&b!==o){g.preventDefault(),g.stopPropagation(),v=!0,y=g.clientX-l.left,w=g.clientY-l.top,i.style.cursor="move",e.style.display="none";return}g.preventDefault(),c=!0,C=g.clientX,h=g.clientY,l.left=C,l.top=h,l.width=0,l.height=0,o.style.background="transparent",i.style.display="block",i.style.borderColor="#398CF5",i.style.boxShadow="0 0 0 99999px rgba(15, 23, 42, 0.65)",i.style.cursor="crosshair",e.style.display="none",_()}});function xe(g){if(c){const b=g.clientX,x=g.clientY;l.left=Math.min(C,b),l.top=Math.min(h,x),l.width=Math.abs(b-C),l.height=Math.abs(x-h),_()}else if(v)l.left=Math.max(0,Math.min(window.innerWidth-l.width,g.clientX-y)),l.top=Math.max(0,Math.min(window.innerHeight-l.height,g.clientY-w)),_();else if(s){const b=g.clientX,x=g.clientY;if(m.includes("e")&&(l.width=Math.max(20,b-l.left)),m.includes("s")&&(l.height=Math.max(20,x-l.top)),m.includes("w")){const A=l.left+l.width;l.left=Math.min(A-20,b),l.width=A-l.left}if(m.includes("n")){const A=l.top+l.height;l.top=Math.min(A-20,x),l.height=A-l.top}_()}}window.addEventListener("mousemove",xe);function ve(g){if(c){if(c=!1,l.width<15&&l.height<15){o.style.display="none";const b=document.elementFromPoint(g.clientX,g.clientY);if(o.style.display="block",b&&!b.closest("#savvy-root")){const x=b.getBoundingClientRect();l.left=Math.max(0,x.left-4),l.top=Math.max(0,x.top-4),l.width=x.width+8,l.height=x.height+8}else l.left=Math.max(10,g.clientX-160),l.top=Math.max(10,g.clientY-60),l.width=320,l.height=120;_()}i.style.cursor="move",e.style.display="flex"}v&&(v=!1,i.style.cursor="move",e.style.display="flex"),s&&(s=!1,e.style.display="flex")}window.addEventListener("mouseup",ve)}function Le(){var n,u,i,d;const t=document.documentElement,o=document.body;te(),ne(),pe(),H&&(H.style.display="none"),t.style.filter="",t.style.fontSize="",o.style.letterSpacing="",o.style.wordSpacing="",o.style.lineHeight="",o.style.textAlign="",o.style.fontFamily="",(n=document.getElementById("savvy-pause-anim"))==null||n.remove(),(u=document.getElementById("savvy-hide-img"))==null||u.remove(),(i=document.getElementById("savvy-highlight-links"))==null||i.remove(),(d=document.getElementById("savvy-big-cursor"))==null||d.remove();try{window.speechSynthesis&&window.speechSynthesis.cancel()}catch{}try{const f=F.querySelector(".savvy-lightshot-container");f&&f.remove()}catch{}E.action("🧹 All accessibility features and spotlights cleared.")}function se(t,o,n,u){var f,e,r,a,p,c,v;const i=document.documentElement,d=document.body;switch(t){case"spotlight":case"reading_spotlight":H.style.display=o&&n!=="Off"?"block":"none";break;case"contrast":case"high_contrast":!o||n==="Normal"?i.style.filter="":n==="High"?i.style.filter="contrast(180%) brightness(105%)":n==="Invert"?i.style.filter="invert(100%) hue-rotate(180deg)":n==="Monochrome"?i.style.filter="grayscale(100%) contrast(120%)":i.style.filter="contrast(180%) brightness(105%)";break;case"textSize":case"bigger_text":!o||n==="Normal"?i.style.fontSize="":n==="+25%"?i.style.fontSize="125%":n==="+50%"?i.style.fontSize="150%":n==="+75%"?i.style.fontSize="175%":n==="+100%"?i.style.fontSize="200%":i.style.fontSize="125%";break;case"textSpacing":case"text_spacing":!o||n==="Normal"?(d.style.letterSpacing="",d.style.wordSpacing=""):n!=null&&n.includes("+10%")?(d.style.letterSpacing="0.08em",d.style.wordSpacing="0.12em"):n!=null&&n.includes("+25%")?(d.style.letterSpacing="0.16em",d.style.wordSpacing="0.24em"):n!=null&&n.includes("+50%")?(d.style.letterSpacing="0.24em",d.style.wordSpacing="0.36em"):(d.style.letterSpacing="0.14em",d.style.wordSpacing="0.2em");break;case"pauseAnim":case"pause_animations":if(o&&n!=="Normal"){let s=document.getElementById("savvy-pause-anim");s||(s=document.createElement("style"),s.id="savvy-pause-anim",document.head.appendChild(s)),s.textContent="* { animation-play-state: paused !important; transition: none !important; }"}else(f=document.getElementById("savvy-pause-anim"))==null||f.remove();break;case"hideImages":case"hide_images":if(!o||n==="Normal")(e=document.getElementById("savvy-hide-img"))==null||e.remove();else{let s=document.getElementById("savvy-hide-img");s||(s=document.createElement("style"),s.id="savvy-hide-img",document.head.appendChild(s)),n==="Grayscale"?s.textContent="img, svg:not(.savvy-icon), video { filter: grayscale(100%) !important; opacity: 0.65 !important; }":s.textContent="img, svg:not(.savvy-icon), video { visibility: hidden !important; }"}break;case"links":case"highlight_links":if(!o||n==="Off")(r=document.getElementById("savvy-highlight-links"))==null||r.remove();else{let s=document.getElementById("savvy-highlight-links");s||(s=document.createElement("style"),s.id="savvy-highlight-links",document.head.appendChild(s)),n==="Underline"?s.textContent="a { text-decoration: underline 3px solid #2563EB !important; text-underline-offset: 4px !important; }":n==="High Contrast"?s.textContent="a { outline: 3px solid #2563EB !important; background-color: #EFF6FF !important; color: #1D4ED8 !important; text-decoration: underline !important; }":s.textContent="a { background-color: #FEF08A !important; color: #1E3A8A !important; text-decoration: underline !important; }"}break;case"dyslexiaFont":case"dyslexia_font":o&&n!=="Off"?d.style.fontFamily="Comic Sans MS, OpenDyslexic, sans-serif":d.style.fontFamily="";break;case"tts":case"text_to_speech":if(o&&n!=="Off"){(a=window.speechSynthesis)==null||a.cancel();const s=document.title+". "+(document.body.innerText||"").slice(0,400),m=new SpeechSynthesisUtterance(s);m.lang=document.documentElement.lang||"id-ID",(p=window.speechSynthesis)==null||p.speak(m)}else(c=window.speechSynthesis)==null||c.cancel();break;case"bigCursor":case"big_cursor":if(!o||n==="Normal")(v=document.getElementById("savvy-big-cursor"))==null||v.remove();else{let s=document.getElementById("savvy-big-cursor");if(s||(s=document.createElement("style"),s.id="savvy-big-cursor",document.head.appendChild(s)),n==="Large (White)"){const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='white' stroke='black' stroke-width='1.5'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${m}") 0 0, auto !important; }`}else if(n==="Highlighter"){const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48' viewBox='0 0 48 48'%3E%3Ccircle cx='24' cy='24' r='20' fill='rgba(254,240,138,0.65)' stroke='%23F59E0B' stroke-width='2.5'/%3E%3Ccircle cx='24' cy='24' r='3' fill='%23D97706'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${m}") 24 24, auto !important; }`}else{const m="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='44' height='44' viewBox='0 0 24 24'%3E%3Cpolygon points='0,0 0,20 5.5,15 9.5,23 12.5,21.5 8.5,13.5 15,13.5' fill='black' stroke='white' stroke-width='1.5'/%3E%3C/svg%3E";s.textContent=`* { cursor: url("${m}") 0 0, auto !important; }`}}break;case"lineHeight":case"line_height":!o||n==="Normal"?d.style.lineHeight="":n==="1.5x"?d.style.lineHeight="1.5":n==="1.8x"?d.style.lineHeight="1.8":n==="2.2x"?d.style.lineHeight="2.2":d.style.lineHeight="1.8";break;case"textAlign":case"text_align":!o||n==="Normal"?d.style.textAlign="":n==="Left"?d.style.textAlign="left":n==="Center"?d.style.textAlign="center":n==="Justify"?d.style.textAlign="justify":d.style.textAlign="left";break;case"colorSat":case"color_saturation":!o||n==="Normal"?i.style.filter="":n!=null&&n.includes("High")?i.style.filter="saturate(200%)":n!=null&&n.includes("Low")?i.style.filter="saturate(40%)":n!=null&&n.includes("Monochrome")?i.style.filter="grayscale(100%)":i.style.filter="saturate(200%)";break;case"liveTooltips":case"live_tooltips":break;default:console.log("[Savvy.AI Content] Toggled feature:",t,o,n)}}try{typeof chrome<"u"&&((ye=chrome.storage)!=null&&ye.local)&&chrome.storage.local.get(["savvy_sidepanel_open","savvy_a11y_settings"],t=>{t&&t.savvy_sidepanel_open&&t.savvy_a11y_settings&&Object.entries(t.savvy_a11y_settings).forEach(([o,n])=>{n&&n.enabled&&se(o,n.enabled,n.value,n.level)})})}catch{}})();
